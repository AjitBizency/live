<?php

    return [
        "logo_path" => "includes/image/main-logo.png",
        "favicon_path" => "includes/image/bizency-fav-icon.png",
        "contact_number" => "+91 8700089235",
        "email" => "info@bizency.com",
        "email_2" => "firoz@bizency.com",
        "compnay_name" => "Bizency",
        "company_address" => "Unit No. JA0220, 2nd Floor, DLF Tower-A Plot No.10, Jasola District Centre,
        New Delhi-110025, India", 
    ];