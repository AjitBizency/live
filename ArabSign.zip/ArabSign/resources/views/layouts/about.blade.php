@extends('default')
@section('content')
    <div class="aboutUs-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">About Us</h1>
                    <ul class="breadcrumb">
                        <li>Home</li>
                        <li class="active">About Us</li>
                    </ul>
                </div>
            </div>     
        </div>   
        
		<section class="section aboutUs">
			<div class="container">
				<h1 class="heading underline"><b>About </b>Us</h1>

				<div class="row align-items-center">
					<div class="col-md-8 col-sm-12 order-2 order-sm-1">
						<p>Arab Sign stands out as a premier player in the Sign and Graphics industry, boasting a strong presence in Dubai and an additional branch in Abu Dhabi, UAE. Our journey began back in 1998, and since then, we've consistently delivered top-notch internal and external signage solutions, encompassing a wide range of offerings such as 3D LED Signs, Neon Signs, and LED Display panels for digital signage, catering to clients throughout Dubai and the entire UAE.</p>

						<p>When it comes to Digital Signs and LED Display panels, Arab Sign has forged a strategic partnership with Dahua Technology, a globally renowned manufacturer of LED Display panels. This partnership ensures that we can provide you with the utmost quality and dependable LED Digital Display panel solutions, all conveniently accessible right at your doorstep.</p>

						<p>To execute our sign projects with excellence, Arab Sign has assembled a dedicated team of highly qualified and experienced professionals who are committed to delivering successful outcomes.</p>

						<p>We take great pride in being recognized as the distinguished Signage Supplier in Dubai, a testament to our commitment to excellence and customer satisfaction.</p>
					</div>

					<div class="col-md-4 col-sm-12 order-1 order-sm-2">
						<div class="img">
							<img src="{{ secure_asset('includes/image/no-image.png') }}" style=" width: 70%; display: flex; margin: auto; ">
						</div>
					</div>
				</div>
			</div>
		</section>

    
	</div>
@endsection