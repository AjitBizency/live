@extends('default')
@section('content')
    <div class="contact-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">Contact Us</h1>
                    <ul class="breadcrumb">
                        <li>Home</li>
                        <li class="active">Contact Us</li>
                    </ul>
                </div>
            </div>     
        </div>

        <div class="section1">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
                        <div class="bg-img">
                            <section class="section map">
                                <iframe class="gmap_iframe" width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=406&amp;height=400&amp;hl=en&amp;q=Riyadh&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
                            </section>
                        </div>
                    </div>

                    <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
                        <div class="right">
                            <h1 class="heading">Get in touch</h1>

                            <p class="content">Have an inquiry or some feedback for us?</p>
                            <p class="content">Fill out the form below to contact our team.</p>

                            <form>
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">First name *</label>                            
                                            <input type="text" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Last name *</label>                            
                                            <input type="text" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Email address *</label>                            
                                            <input type="email" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Message</label>                            
                                            <textarea class="form-control" rows="5"></textarea>
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <a type="submit" class="has-btn">
                                            Get in touch
                                            
                                            <i class="fal fa-long-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
@endsection