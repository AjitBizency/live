<footer class="footer-section">
        <div class="container">
            <div class="footer-content pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 mb-50 mx-auto text-center">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="index.html">
                                    <img src="{{ secure_asset('includes/image/traingle-logo.png') }}" class="img-fluid" alt="logo"/>
                                </a>
                            </div>
                            <div class="footer-text mb-5">
                                <p>Arab Sign is committed to executing sign projects with utmost precision and finesse, ensuring customer satisfaction throughout our operations in Dubai and the UAE.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <a href="javascript:void(0)"><i class="fab fa-facebook-f facebook-bg"></i></a>
                                <a href="javascript:void(0)"><i class="fab fa-twitter twitter-bg"></i></a>
                                <a href="javascript:void(0)"><i class="fab fa-google-plus-g google-bg"></i></a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-sm-12">
                        <div class="copyright-text">
                            <p>Copyright &copy; 2018, All Right Reserved</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-sm-12">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="javascript:void(0)">Home</a></li>
                                <li><a href="javascript:void(0)">Terms & Condition</a></li>
                                <li><a href="javascript:void(0)">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>