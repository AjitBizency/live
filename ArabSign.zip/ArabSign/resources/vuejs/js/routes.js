import PersonalProfileComponent from './components/profile/personal-profile/PersonalProfileComponent.vue';
import MyDesignsComponent from './components/profile/my-design/MyDesignsComponent.vue';

export default{
    mode: 'history',
    routes: [
        {
            path: '/personal-profile',
            component: PersonalProfileComponent
        },
        {
            path: '/my-designs',
            component: MyDesignsComponent
        }

    ]
};