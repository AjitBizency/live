<template>
    <div class="section-padding">
        <div class="page-title-container">
            <h2 class="home-page-head">How It Works</h2>
            <p class="home-page-subhead">Print your product in 3 steps</p>
        </div>
        <div class="container">
            <div class="row justify-content-around">
                <div class="col-sm-3 step-box">
                    <div class="icon-container">
                        <img src="website/images/icons/product-type.png" alt="product-type" />
                    </div>
                    <div class="step-container">
                        <span class="step-no-box">1</span>
                        <span class="step-text"><strong>Select the product type</strong></span>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
                <div class="col-sm-3 step-box">
                    <div class="icon-container">
                        <img src="website/images/icons/design.png" alt="product-type" />
                    </div>
                    <div class="step-container left-line">
                        <span class="step-no-box">2</span>
                        <span class="step-text"><strong>Do you have a design?</strong></span>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
                <div class="col-sm-3 step-box">
                    <div class="icon-container">
                        <img src="website/images/icons/customized.png" alt="product-type" />
                    </div>
                    <div class="step-container left-line">
                        <span class="step-no-box">3</span>
                        <span class="step-text"><strong>Customize your order</strong></span>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        
    };
</script>