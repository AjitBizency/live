<template>
    <div class="container-fluid">
        <carousel :data="slider" :controls="true" :indicators="true" :interval="300000" indicator-type="disc">
            
        </carousel>
    </div>
</template>

<script>
    import Vue from 'vue';
    import VueCarousel from '@chenfengyuan/vue-carousel';
    Vue.use(VueCarousel);
    export default {
        data() {
            return {
                    slider:[]
                   
            };
        },
        mounted() {
           this.getSlider();
        },
        methods:{
            getSlider(){
                axios.get('/webapi/slider').then(response=>{
                var arr = [];
                $.each(response.data, function(key, value) {
                        arr.push(value);
                   }); 
                   this.slider = arr;
                })
            }
        }
    };
</script>