<template>
    <div class="section-padding stay-in-touch">
        <div class="page-title-container">
            <h2 class="home-page-head">Stay in touch</h2>
            <p class="home-page-subhead">Talk to us! whether you have feedback, a request or just wanna say hi</p>
        </div>
        <div class="container">
            <form class="form">
                <div class="row justify-content-center">
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control" name="full_name">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Mobile Number</label>
                                    <input type="phone" class="form-control" name="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Your message</label>
                                <textarea name="message" class="form-control" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="row justify-content-end align-items-center">
                            <div class="col-sm-3">
                                <button type="button" class="btn btn-deep-orange">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
</template>

<script>

    export default {
        
    };
</script>