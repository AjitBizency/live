<template>
    <div class="section-padding">
        <div class="page-title-container">
            <h2 class="home-page-head">Join Our Designers Marketplace</h2>
        </div>
        <section class="designer-marketplace" style="background: url('website/images/bg.jpg') bottom">
            <div class="marketplace-text">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.
                </p>
            </div>
        </section>
        <div class="container">
            <div class="row justify-content-center">
                <div class="btn-container col-sm-4">
                    <a href="javascript:void(0);" class="btn btn-deep-orange">Go to Marketplace</a>
                </div>
            </div>
            <!--/row-->
        </div>
    </div>
</template>

<script>

    export default {
        
    };
</script>