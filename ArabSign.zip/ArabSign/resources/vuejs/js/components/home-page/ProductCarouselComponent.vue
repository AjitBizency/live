<template>
    <div class="product-carousel-conatiner section-padding">
        <div class="page-title-container"><h2 class="home-page-head">Made with ZeejPrint</h2></div>
        <carousel :data="data" :controls="false" :indicators="false" :interval="20000"></carousel>
    </div>
</template>

<script>

    import Vue from 'vue';
    import VueCarousel from '@chenfengyuan/vue-carousel';
    Vue.use(VueCarousel);
    export default {
        data() {
            return {
                data: [
                    '<div class="home-product-slider d-flex align-items-center">' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '    </div>',
                    '<div class="home-product-slider d-flex align-items-center">' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '        <div class="slider-img-box">' +
                    '            <img  src="website/images/products/business-card-1.png" alt="zeej-product"/>' +
                    '            <div class="hover-testimonial-box">' +
                    '                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' +
                    '                </p>' +
                    '                <div class="author-container">' +
                    '                    <div class="author-name">' +
                    '                        <p>Rabih Khaled</p>' +
                    '                        <p class="text-uppercase"><strong>Live Hude</strong></p>' +
                    '                    </div>' +
                    '                    <div class="author-image"><img width="90px" src="website/images/icons/dummy.png" alt="author-image"/></div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <!--/slider-img-box-->' +
                    '    </div>',
                ],
            };
        },
    };
</script>