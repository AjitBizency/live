<template>
    <div v-html="HTMLcontent"></div>
</template>

<script>
    import Vue from 'vue';
    export default {
        data() {
            return {
                    HTMLcontent: null,
                   
            };
        },
        mounted() {
           this.getFamilies();
        },
        methods:{
            getFamilies(){
                axios.get('/webapi/headingfamiliesapi').then(response=>{
                var arr = [];
console.log(response.data);
                $.each(response.data, function(key, value) {
                        arr.push(value);
                   }); 
                   this.HTMLcontent = response.data.val;
                   
                   
                   
                })
            }
        }
    };
</script>