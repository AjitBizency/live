<script>
    import UploadStartPopupComponent from '../common/UploadStartPopupComponent.vue';
    import AddToCartComponent from '../cart/AddToCartComponent.vue';

    export default {
        components:{
            UploadStartPopupComponent,
            AddToCartComponent
        },
        data(){
            return{
                spotUV:false,
                lamination:false,
                lamination_service_checked:false,
                spotUV_service_checked:false,
                lamination_side_checked:false,
                spotUV_side_checked:false,
                material_checked:false,
                side1_st_checked:'CMYK',
                side2_st_checked:'CMYK',
                side1_sp_checked:[],
                side2_sp_checked:[],
                side_checked:'two_sided',
                pickProductIcon:'images/icons/product-type.png',
                pickDesignIcon:'images/icons/design.png',
                customizeProductIcon:'images/icons/customized.png',
                rightArrowIcon:'images/icons/right-arrow.png',
                iceWhiteIcon:'images/icons/ice-white.png',
                iceGoldIcon:'images/icons/ice-gold.png',
                sideIcon:'images/icons/side-card.png',
                size_type :{
                    selected :1 ,
                    value: { name: '-- select --', id: ' ' },
                    input_id : 'product-id',
                    options: [
                        { name: '-- select --', id: ' ' ,$isDisabled: true },
                        { name: 'size-1', id: '1' },
                        { name: 'size-2', id: '2'  },
                        { name: 'size-3', id: '3'  },
                        { name: 'size-4', id: '4'  }
                    ],
                },
                side_1_standard_color :[
                        { name: 'CMYK', id: '1' },
                        { name: 'Color-1', id: '2' },
                        { name: 'Color-2', id: '3' },
                        { name: 'Color-3', id: '4' }
                ],
                side_1_special_color : [
                        { name: 'white', id: '1' },
                        { name: 'Color-1', id: '2' },
                        { name: 'Color-2', id: '3' },
                        { name: 'Color-3', id: '4' }
                    ],
                side_2_standard_color : [
                        { name: 'CMYK', id: '1' },
                        { name: 'Color-1', id: '2' },
                        { name: 'Color-2', id: '3' },
                        { name: 'Color-3', id: '4' }
                    ],
                side_2_special_color : [
                        { name: 'white', id: '1' },
                        { name: 'Color-1', id: '2' },
                        { name: 'Color-2', id: '3' },
                        { name: 'Color-3', id: '4' }
                    ],
                designDataList:[
                    {id:1, designName:'Panda - Executive Team', designImg:'business-card-1.png', tags:['panda','marketing']},
                    {id:2, designName:'Almaria - Marketing Team', designImg:'t-shirt-printing.png', tags:['panda','marketing','business card']},
                ],
                previewImage:[
                    {id:1, prevImg:'b-card1.png', side:'Side 1', dimension:[{width:9.0, height:5.5, unit:'cm'}]},
                    {id:2, prevImg:'b-card.png', side:'Side 1', dimension:[]}
                ],

            }
        },
        methods:{
          mouseOver() {

                  $('#ice_gold_info_box').toggle();
                  //console.log(e_val);

              //console.log(e_val);
          },
            openModal(){
              $('#upload_design').modal({
                  backdrop: 'static',
                keyboard: false
              });
            },
            selectColor(checkedValue){
                return this.side1_sp_checked.includes(checkedValue)
            },
            selectColor1(checkedValue1){
                return this.side2_sp_checked.includes(checkedValue1)
            },
        },
        mounted() {
//            console.log('Component mounted.')
        },
    }
</script>