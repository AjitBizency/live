<template>
    <div class="product-category-container">
        <div class="page-title-container"><h1 class="page-title">Business Card</h1></div>
        <!--order-step-box-->
        <div class="order-step-box">
            <div class="row justify-content-around">
                <div class="icon-container col-md-2">
                    <img :src="pickProductIcon" alt="pickProductIcon"/>
                    <p class="home-page-subhead">
                        Pick the <br/>product type
                    </p>
                </div>
                <div class="icon-container col-md-1">
                    <img :src="rightArrowIcon" alt="rightArrowIcon"/>
                </div>
                <div class="icon-container col-md-3">
                    <img :src="pickDesignIcon" alt="pickDesignIcon"/>
                    <p class="home-page-subhead">
                        Do you have a design? <br/>Don't worry we can help you
                    </p>
                </div>
                <div class="icon-container col-md-1">
                    <img :src="rightArrowIcon" alt="rightArrowIcon"/>
                </div>
                <div class="icon-container col-md-2">
                    <img :src="customizeProductIcon" alt="customizeProductIcon">
                    <p class="home-page-subhead">
                        Customize <br/> your product
                    </p>
                </div>
            </div>
        </div>
        <!--/order-step-box-->

        <form method="post" class="product-specs-form">
            <!--product-list-box-->
            <div class="section-padding product-list-box">
                <div class="page-title-container"><h1 class="page-title">Pick the product type</h1></div>
                <div class="text-container">
                    <p>
                        Product type differs in the way Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                        Product type differs in the way Lorem ipsum dolor sit amet, consectetur adipiscing elit,sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </p>
                </div>
                <!--<input type="radio" name="spotUV_20" id="spotUV_20" v-model="spotUV_service_checked" value="spotUV_20">-->
                <!--<div class="icon-container" :class="{img_selected: spotUV_service_checked === 'spotUV_20'}">-->
                    <!--<img :src="iceWhiteIcon" :alt="iceWhiteIcon"/>-->
                <!--</div>-->
                <div class="row">
                    <div class="col-sm-3" v-for="product in productDataList">
                        <label :for="`p_`+product.id">
                            <input type="radio" name="product" :id="`p_`+product.id" :value="product.productName" v-model="product_checked">
                            <div class="product-category-box" :id="`selected_`+product.id" :class="{img_selected: product_checked === product.productName}">
                                <div class="special-offer-product" v-if="product.spclOffer=='yes'">
                                    <div class="offer-tag"><span>%</span></div>
                                    <strong>Special Offer</strong>
                                </div>
                                <img :src="`images/products/`+product.imgName" :alt="product.imgName"/>
                                <div class="img-caption">
                                    <span class="product-name-span">{{ product.productName }}</span>
                                    <span class="price-sapn">Starts from {{ product.price }} SAR</span>
                                </div>
                            </div>
                        </label>

                    </div>
                </div>
                <!--/row-->
            </div>
            <!--/product-list-box-->
            <!--product specification section-->
            <product-specs-component></product-specs-component>
            <!--/product specification section-->
        </form>
    </div>

</template>

<script>
    import ProductSpecsComponent from './ProductSpecsComponent.vue'
    export default {
        components:{
            ProductSpecsComponent
        },
        data(){
            return{
                product_checked:false,
                pickProductIcon:'images/icons/product-type.png',
                pickDesignIcon:'images/icons/design.png',
                customizeProductIcon:'images/icons/customized.png',
                rightArrowIcon:'images/icons/right-arrow.png',
                productDataList:[
                    {id:1, productName:'Digital Print', price:100, imgName:'business-card-1.png', spclOffer:'no'},
                    {id:2, productName:'Digital Print1', price:100, imgName:'t-shirt-printing.png', spclOffer:'yes'},
                    {id:3, productName:'Digital Print2', price:100, imgName:'business-card-1.png', spclOffer:'no'},
                    {id:4, productName:'Digital Print3', price:100, imgName:'t-shirt-printing.png', spclOffer:'no'},
                    {id:5, productName:'Digital Print4', price:100, imgName:'business-card-1.png', spclOffer:'no'},
                    {id:6, productName:'Digital Print5', price:100, imgName:'t-shirt-printing.png', spclOffer:'no'},
                ],

            }
        },
        methods:{
            addClass(id){
                // console.log(id);
                if($('#p_'+id).prop('checked')== true){
                    $('#selected_'+id).addClass('selected-product');
                    $('#selected_'+id).siblings().removeClass('selected-product');
                    //console.log($('input[name="product"]:checked').val());
                }
            }
        }
    }
</script>