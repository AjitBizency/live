
<template>
    <div class="tabs-container">
        <div class="page-title-container">
            <h1 class="page-title">My Account</h1>
        </div>
        <ul class="nav nav-tabs md-tabs zeej-tabs" id="myTabMD" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="personal_profile" data-toggle="tab" href="#personal_profile_content" role="tab" aria-controls="personal_profile_content"
                   aria-selected="true">Personal profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="my_designs" data-toggle="tab" href="#my_designs_content" role="tab" aria-controls="my_designs_content"
                   aria-selected="false">My designs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="order_history" data-toggle="tab" href="#order_history_content" role="tab" aria-controls="order_history_content"
                   aria-selected="false">Order history</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="shipping_address" data-toggle="tab" href="#shipping_address_content" role="tab" aria-controls="shipping_address_content"
                   aria-selected="false">Shipping address</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="payment" data-toggle="tab" href="#payment_content" role="tab" aria-controls="payment_content"
                   aria-selected="false">Payment</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContentMD">
            <personal-profile-component></personal-profile-component>
            <my-designs-component></my-designs-component>
            <shipping-address-component></shipping-address-component>
            <hr>
            <div class="row justify-content-center">
                <a href="javascript:void(0)" class="custom-link">Logout</a>
            </div>

        </div>
    </div>
</template>

<script>
    export default {

    }
</script>