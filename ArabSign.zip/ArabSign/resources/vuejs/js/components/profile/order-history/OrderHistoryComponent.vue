
<template>
    <div class="tab-pane fade show" id="order_history" role="tabpanel" aria-labelledby="order_history">
        <div class="tab-name">
            Invoices History
        </div>
        <div class="text-container row">
            <div class="col-sm-12">
                <p>Here will appear the orders you made through the website</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="table-responsive text-nowrap">
                    <!--Table-->
                    <table class="table data-box-table order-history-table">
                        <!--Table head-->
                        <thead>
                        <tr>
                            <th width="35%"><h4>Products</h4></th>
                            <th><h4>Order date</h4></th>
                            <th><h4>Shipped to</h4></th>
                            <th><h4>Order number</h4></th>
                        </tr>
                        </thead>
                        <!--Table head-->

                        <!--Table body-->
                        <tbody>
                        <tr>
                            <td colspan="4">
                                <div class="data-box-head">
                                    <h4>Current orders</h4>
                                </div>
                                <div class="data-box">
                                    <table width="100%">
                                        <tr>
                                            <td width="35%" class="right-border">
                                                <div class="order-history-product">
                                                    <div class="product-img-box">
                                                        <img :src="productImgUrl" alt="Business Card" width="100px"/>
                                                    </div>
                                                    <div class="product-box">
                                                        <h4>Business card</h4>
                                                        <ul class="list-unstyled">
                                                            <li>Double sided</li>
                                                            <li>Lamination</li>
                                                            <li>Digital print</li>
                                                            <li>Ice gold paper</li>
                                                        </ul>
                                                        <div class="custom-note">
                                                            <a href="#">
                                                                <strong>Panda - Executive Team.psd</strong>
                                                            </a>
                                                        </div>
                                                            <a href="#" class="custom-btn-outline">
                                                            <strong>Re-order</strong>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="order-history-product">
                                                    <div class="product-img-box">
                                                        <img :src="productImgUrl" alt="Business Card" width="100px"/>
                                                    </div>
                                                    <div class="product-box">
                                                        <h4>Business card</h4>
                                                        <ul class="list-unstyled">
                                                            <li>Double sided</li>
                                                            <li>Lamination</li>
                                                            <li>Digital print</li>
                                                            <li>Ice gold paper</li>
                                                        </ul>
                                                        <div class="custom-note">
                                                            <a href="#">
                                                                <strong>Panda - Executive Team.psd</strong>
                                                            </a>
                                                        </div>
                                                        <a href="#" class="custom-btn-outline">
                                                            <strong>Re-order</strong>
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>12/09/2018
                                            </td>
                                            <td width="10%">
                                                <div class="shipping-address">
                                                    <p class="text-uppercase">Client Address</p>
                                                   <span class="address">AIHamra, Riyadh -</span>
                                                   <span class="address">Kingdom of Saudi Arabia 34873</span>
                                                   <span class="address"> 34873</span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="custom-note">
                                                    <a href="#">
                                                        <strong>ZP-098765432123456</strong>
                                                    </a>
                                                </div>
                                                <span class="order-status under-process">Under preparation</span>
                                            </td>
                                        </tr>
                                    </table>
                                    <div class="table-footer">
                                        <div class="data-content-box">
                                            <p><a href="#">View order details</a></p>
                                            <p><a href="#" class="btn btn-deep-orange">Contact us</a></p>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <div class="data-box-head">
                                    <h4>Past orders</h4>
                                </div>
                                <div class="data-box">
                                    <table width="100%">
                                        <tr>
                                            <td width="35%" class="right-border">
                                                <div class="order-history-product">
                                                    <div class="product-img-box">
                                                        <img :src="productImgUrl" alt="Business Card" width="100px"/>
                                                    </div>
                                                    <div class="product-box">
                                                        <h4>Business card</h4>
                                                        <ul class="list-unstyled">
                                                            <li>Double sided</li>
                                                            <li>Lamination</li>
                                                            <li>Digital print</li>
                                                            <li>Ice gold paper</li>
                                                        </ul>
                                                        <div class="custom-note">
                                                            <a href="#">
                                                                <strong>Panda - Executive Team.psd</strong>
                                                            </a>
                                                        </div>
                                                        <a href="#" class="custom-btn-outline">
                                                            <strong>Re-order</strong>
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>12/09/2018
                                            </td>
                                            <td width="10%">
                                                <div class="shipping-address">
                                                    <p class="text-uppercase">Client Address</p>
                                                    <span class="address">AIHamra, Riyadh -</span>
                                                    <span class="address">Kingdom of Saudi Arabia 34873</span>
                                                    <span class="address"> 34873</span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="custom-note">
                                                    <a href="#">
                                                        <strong>ZP-098765432123456</strong>
                                                    </a>
                                                </div>
                                                <span class="order-status delivered">Delivered</span>
                                            </td>
                                        </tr>
                                    </table>
                                    <div class="table-footer">
                                        <div class="data-content-box">
                                            <p><a href="#">View order details</a></p>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                        <!--Table body-->
                    </table>
                    <!--Table-->
                </div>
            </div>
        </div>
        <div class="row justify-content-center no-content-box">
            <div class="col-sm-4 text-center">
                <img v-bind:src="noDataFoundIcon" alt="user-address">
                <div class="text-container">
                    <p>You haven't haven't ordered anything yet.</p>
                    <button class="btn btn-deep-orange" type="button">{{ buttonText }}</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                noDataFoundIcon:"images/icons/product-type.png",
                buttonText:'Make a New Order',
                productImgUrl: 'images/products/business-card-1.png'
            }
        },
    }
</script>