<template>
    <div class="tab-pane fade show payment-tab" id="payment" role="tabpanel" aria-labelledby="payment">
        <div class="tab-name">
            Payment & Billing
        </div>
        <div class="text-container">
            <div class="balance-status-box">
                Your current balance is:<strong>50 SAR</strong>
            </div>
            <div class="balance-btn-container">
                <button class="z-depth-0 btn custom-btn-outline" type="button" data-toggle="modal" data-target="#send_gift">Send Gift</button>
                <button class="btn btn-deep-orange" type="button" data-toggle="modal" data-target="#topup_credit">Top Up Balance</button>
            </div>
        </div>
        <hr>
        <form class="form">
            <div class="select-design-box">
                <h1>Let your friends know about Zeej</h1>
                <p class="home-page-subhead">Share Zeej with your friends and earn more credit in your balance</p>
            </div>
            <div class="form-container">
                <div class="form-group">
                    <label>Invite your friends via email</label>
                    <div class="form-inline">
                        <input type="email" class="form-control" name="email">
                        <button class="btn btn-deep-orange" type="button">Send Invitation</button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Or copy and share your link</label>
                    <div class="form-inline">
                        <input type="text" class="form-control" name="sharable_link">
                        <button class="btn btn-deep-orange" type="button">Copy Link</button>
                    </div>
                </div>
            </div>
            <div class="row upload-and-earn">
                <div class="design-icon-img">
                    <img :src="noDataFoundIcon" alt="upload-design-icon"/>
                </div>
                <div class="banner-text">
                    <h1>Upload your design now and earn 30 SAR</h1>
                    <div class="sub-text">
                        <p>Uploaded designs can be re-used later</p>
                        <button class="btn btn-grey" type="button">Upload Your Designs</button>
                    </div>

                </div>
            </div>
        </form>
        <topup-credit-popup-component></topup-credit-popup-component>
        <send-gift-popup-component></send-gift-popup-component>
    </div>
</template>

<script>
    import TopupCreditPopupComponent from './TopupCreditPopupComponent.vue';
    import SendGiftPopupComponent from './SendGiftPopupComponent.vue';
    export default {
        components:{
            TopupCreditPopupComponent,
            SendGiftPopupComponent
        },
        data(){
            return{
                noDataFoundIcon:"images/icons/design1.png",
            }
        },
    }
</script>