
<template>
    <div class="modal fade" id="send_gift" tabindex="-1" role="dialog" aria-labelledby="send_gift"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <div class="topup-credit-head">
                        <h2 class="modal-title">Send Gift</h2>
                    </div>
                    <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
                        <!--<span aria-hidden="true">&times;</span>-->
                    <!--</button>-->
                </div>
                <div class="modal-body">
                    <form class="form">
                        <div class="row form-container">
                            <div class="form-group">
                                <p class="mb-0">Enter the recepient's email(Make sure the recepient is a Zeej user)</p>
                            </div>
                            <div class="form-group">
                                <label>Recepient Email</label>
                                <input type="email" class="form-control" name="email" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <p class="mb-0">Enter the amount</p>
                            </div>
                            <div class="form-group">
                                <label>Amount</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="amount_value" placeholder="eg. 50" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="basic-addon2">SAR</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row payment-method-box">
                            <p>Select payment method</p>
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="wallet_balance" name="payment_method">
                                <label class="custom-control-label" for="wallet_balance">Balance: 400 SAR</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="paypal" name="payment_method">
                                <label class="custom-control-label" for="paypal">PayPal <i class="fab fa-paypal"></i></label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="creidt_debit_card" name="payment_method">
                                <label class="custom-control-label" for="creidt_debit_card">Credit Card/Mada <i class="fab fa-cc-mastercard"></i>
                                    <i class="fab fa-cc-visa"></i></label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="sadad" name="payment_method">
                                <label class="custom-control-label" for="sadad">Sadad </label>
                            </div>
                        </div>

                        <div class="row justify-content-end align-items-center mt-5 button-container">
                            <a href="javascript:void(0)" data-dismiss="modal"><strong>Cancel</strong></a>
                            <button type="button" class="z-depth-0 btn custom-btn-outline" ><strong>Send Gift</strong></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
       

    }
</script>