
<template>
    <div class="wrapper">
        <div class="container tabs-container">
            <div class="page-title-container">
                <h1 class="page-title">My Account</h1>
            </div>
            <vue-tabs>
                <v-tab title="Personal profile" class="nav-item">
                    <personal-profile-component></personal-profile-component>
                </v-tab>
                <v-tab title="My designs">
                    <my-designs-component></my-designs-component>
                </v-tab>

                <v-tab title="Order history">
                    Third tab content
                </v-tab>
                <v-tab title="Shipping address">
                    <shipping-address-component></shipping-address-component>
                </v-tab>
                <v-tab title="Payment">
                    payment tab
                </v-tab>
                <hr>
                <div class="row justify-content-center">
                    <a href="javascript:void(0)" class="custom-link">Logout</a>
                </div>
            </vue-tabs>
        </div>
    </div>

</template>

<script>
    import Tabs from 'vue-nav-tabs/dist/vue-tabs.js';
    import PersonalProfileComponent from './personal-profile/PersonalProfileComponent.vue';
    import MyDesignsComponent from './my-design/MyDesignsComponent.vue';
    import ShippingAddressComponent from './shipping-address/ShippingAddressComponent.vue';

    export default {

        type: {
            type: String,
            default: 'tabs'
        },
        components: {
            PersonalProfileComponent,
            MyDesignsComponent,
            ShippingAddressComponent
        },

    }
</script>