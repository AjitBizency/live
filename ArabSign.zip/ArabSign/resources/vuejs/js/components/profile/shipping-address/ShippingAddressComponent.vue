
<template>
    <div class="tab-pane fade show" id="shipping_address_content" role="tabpanel" aria-labelledby="shipping_address_content">
        <div class="tab-name">
            Shipping Address
        </div>
        <div class="text-container row">
            <div class="col-sm-12 col-md-9">
                <p>You can add different shipping address here e.g. Work, Home, Client address, etc.</p>
            </div>
            <div class="col-sm-12 col-md-3">
                <button class="btn btn-deep-orange" data-toggle="modal" data-target="#shipping_address_form"  type="button">Add new address</button>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <!--Table-->
            <table class="table data-box-table">
                <!--Table head-->
                <thead>
                <tr>
                    <th width="30%"><h4>Address Title</h4></th>
                    <th><h4>Address</h4></th>
                    <th></th>
                </tr>
                </thead>
                <!--Table head-->

                <!--Table body-->
                <tbody>
                    <tr>
                        <td colspan="3">
                            <div class="data-box">
                                <table width="100%">
                                    <tr>
                                        <td width="30%">Panda HQ</td>
                                        <td><strong>Street:</strong> Unit-803, Tower-1, ABC building, 135 <strong>City:</strong> Noida
                                            <strong>Country:</strong> India
                                            <div>
                                                <strong class="green-text">Default address</strong>
                                            </div>
                                        </td>
                                        <td><a href="javascript:void(0)" data-toggle="modal" data-target="#shipping_address_form"><i class="far fa-edit"></i></a> &nbsp;
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#shipping_address_delete"><i class="far fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <div class="data-box">
                                <table width="100%">
                                    <tr>
                                        <td width="30%">Panda HQ</td>
                                        <td><strong>Street:</strong> Unit-803, Tower-1, ABC building, 135 <strong>City:</strong> Noida
                                            <strong>Country:</strong> India
                                        </td>
                                        <td><a href="javascript:void(0)" data-toggle="modal" data-target="#shipping_address_form"><i class="far fa-edit"></i></a> &nbsp;
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#shipping_address_delete"><i class="far fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                </tbody>
                <!--Table body-->


            </table>
            <!--Table-->
        </div>
        <div class="row justify-content-center no-content-box">
            <div class="col-sm-4 text-center">
                <img v-bind:src="imgUrl" alt="user-address">
                <div class="text-container">
                    <p>You haven't added any shipping addresses yet.</p>
                    <button class="btn btn-deep-orange" data-toggle="modal" data-target="#shipping_address_form" type="button">Add new address</button>

                </div>
            </div>
        </div>
        <shipping-address-popup-component></shipping-address-popup-component>
        <delete-popup-component></delete-popup-component>
    </div>

</template>

<script>
    import ShippingAddressPopupComponent from '../shipping-address/ShippingAddressPopupComponent.vue';
    import DeletePopupComponent from '../shipping-address/DeletePopupComponent.vue';

    export default {
        components:{
            ShippingAddressPopupComponent,
            DeletePopupComponent
        },
        data(){
            return{
                imgUrl:"website/images/icons/address.png",
            }

        },
    }
</script>