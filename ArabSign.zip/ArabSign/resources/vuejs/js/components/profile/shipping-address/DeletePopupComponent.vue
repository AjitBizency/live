
<template>
    <div class="modal fade" id="shipping_address_delete" tabindex="-1" role="dialog" aria-labelledby="shipping_address_delete"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Delete Address</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mx-3">
                    <form class="form">
                        <p>Are you sure you want to delete following address:</p>
                        <p><strong>Panda HQ - </strong><strong>Street:</strong> Unit-803, Tower-1, ABC building, 135 <strong>City:</strong> Noida
                            <strong>Country:</strong> India</p>

                        <div class="row justify-content-end align-items-center mt-5">
                            <div class="button-container">
                                <a href="javascript:void(0);" class="z-depth-0 text-danger font-small">Delete</a>
                            </div>
                            <div class="button-container">
                                <button type="button" class="z-depth-0 btn custom-btn-outline" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
       

    }
</script>