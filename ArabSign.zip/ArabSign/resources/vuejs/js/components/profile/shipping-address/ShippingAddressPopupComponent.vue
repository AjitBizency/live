
<template>
    <div class="modal fade" id="shipping_address_form" tabindex="-1" role="dialog" aria-labelledby="shipping_address_form"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">New Address</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mx-3">
                    <form class="form">
                        <div class="row">
                            <img src="website/images/map.png" alt="map" style="margin-bottom: 20px;">
                        </div>
                        <div class="row">
                           <div class="col-md-12">
                               <h3 class="clearfix">Address Details</h3>
                           </div>
                            <div class="col-sm-6">
                                <label>Address Title</label>
                                <input type="text" class="form-control" name="address_title" placeholder="eg. Work, Home, Client address, etc." required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Address 1</label>
                                <input type="text" class="form-control" name="address_1" placeholder="eg. unit-803, Tower-1, ABC building, 135 Noida" required>
                            </div>
                            <div class="col-sm-12">
                                <label>Address 2 (Optional)</label>
                                <input type="text" class="form-control" name="address_2">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label>Address Type</label>
                            </div>
                            <div class="col-md-12">
                                <!-- House -->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="address_type_house" name="address_type">
                                    <label class="custom-control-label" for="address_type_house">House</label>
                                </div>

                                <!-- Apartment -->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="address_type_apartment" name="address_type">
                                    <label class="custom-control-label" for="address_type_apartment">Apartment</label>
                                </div>

                                <!-- Commercial Building -->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="address_type_commercial" name="address_type">
                                    <label class="custom-control-label" for="address_type_commercial">Commercial Building</label>
                                </div>
                            </div>
                        </div>

                        <div class="row pt-5">
                            <div class="col-md-12">
                                <h3 class="clearfix">Contact Person</h3>
                            </div>
                            <div class="col-sm-6">
                                <label>Contact Person Name</label>
                                <input type="text" class="form-control" name="contact_person_name" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <label>Mobile Number</label>
                                <input type="phone" class="form-control" name="phone" placeholder="eg. 966 5XX XXX XXX" required>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email" placeholder="eg. example@example.com" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Notes (Optional)</label>
                                <textarea name="notes" class="form-control" placeholder="e.g. Sixth floor, second office, ring the bell."></textarea>
                            </div>
                        </div>
                        <div class="row justify-content-end align-items-center">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" id="default_address" class="custom-control-input">
                                <label for="default_address" class="custom-control-label">Set as default address</label>
                            </div>
                            <div class="button-container">
                                <button type="button" class="btn btn-deep-orange">Save Address</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {


    }
</script>