
<template>
    <div class="row justify-content-center no-content-box">
            <div class="col-sm-4 text-center">
                <img v-bind:src="imgUrl" alt="user-address">
                <div class="text-container">
                    <p>You haven't added any shipping addresses yet.</p>
                    <button class="btn btn-deep-orange" data-toggle="modal" data-target="#shipping_address_form" type="button">{{ buttonText }}</button>

                </div>
            </div>
        </div>
</template>

<script>
    export default {
        data(){
            return{
                imgUrl:"images/icons/address.png",
                buttonText:'Add new address'
            }

        }
    }
</script>