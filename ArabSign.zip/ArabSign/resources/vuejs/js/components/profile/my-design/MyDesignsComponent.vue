
<template>
    <div class="tab-pane fade show" id="my_designs_content" role="tabpanel" aria-labelledby="my_designs_content">
        <div class="tab-name">
            Uploaded designs
        </div>
        <div class="text-container row">
            <div class="col-sm-12 col-md-9">
                <p>Any design you have used in an order will appear here so it would be easy for you to re-order it.You can also upload designs to keep them here just in case</p>
            </div>
            <div class="col-sm-12 col-md-3">
                <button class="btn btn-deep-orange" @click="openModal()" type="button">Upload new design</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2 col-sm-12">
                <div class="tag-side-bar">
                    <h4>Tags</h4>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="panda">
                        <label class="custom-control-label" for="panda">Panda</label>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="business-cards">
                        <label class="custom-control-label" for="business-cards">Business Cards</label>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="brochures">
                        <label class="custom-control-label" for="brochures">Brochures</label>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="clients">
                        <label class="custom-control-label" for="clients">Clients</label>
                    </div>
                </div>
            </div>
            <div class="col-md-10 col-sm-12">
                <div class="table-responsive text-nowrap">
                    <!--Table-->
                    <table class="table data-box-table">
                        <!--Table head-->
                        <thead>
                        <tr>
                            <th width="48%"><h4>Design Information</h4></th>
                            <th colspan="2"><h4>Product</h4></th>
                        </tr>
                        </thead>
                        <!--Table head-->

                        <!--Table body-->
                        <tbody>
                        <tr>
                            <td colspan="3">
                                <div class="data-box">
                                    <table width="100%">
                                        <tr>
                                            <td width="48%">
                                                <div class="product-img-box">
                                                    <img :src="productImgUrl" alt="Business Card" width="100px"/>
                                                </div>
                                                <div class="product-box">
                                                    <p><strong>Panda - Executive Team</strong></p>
                                                    <p>PSD 24MB</p>
                                                    <a href="javascript:void(0)" class="product-tag">Panda</a>
                                                    <a href="javascript:void(0)" class="product-tag">Marketing</a>
                                                    <a href="javascript:void(0)" class="product-tag">Business card</a>
                                                </div>
                                            </td>
                                            <td width="30%">Business Card
                                            </td>
                                            <td><a href="javascript:void(0)"><i class="far fa-edit"></i></a> &nbsp;<a href="javascript:void(0)" class="custom-btn-outline">Create new order</a> </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <div class="data-box">
                                    <table width="100%">
                                        <tr>
                                            <td width="48%">
                                                <div class="product-img-box">
                                                    <img :src="productImgUrl" alt="Business Card" width="100px"/>
                                                </div>
                                                <div class="product-box">
                                                    <p><strong>Panda - Executive Team</strong></p>
                                                    <p>PSD 24MB</p>
                                                    <a href="javascript:void(0)" class="product-tag">Panda</a>
                                                    <a href="javascript:void(0)" class="product-tag">Marketing</a>
                                                    <a href="javascript:void(0)" class="product-tag">Business card</a>
                                                </div>
                                            </td>
                                            <td width="30%">Business Card
                                            </td>
                                            <td><a href="javascript:void(0)"><i class="far fa-edit"></i></a> &nbsp;<a href="javascript:void(0)" class="custom-btn-outline">Create new order</a> </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                        <!--Table body-->
                    </table>
                    <!--Table-->
                </div>
            </div>
        </div>
        <div class="row justify-content-center no-content-box">
            <div class="col-sm-4 text-center">
                <img v-bind:src="noDataFoundIcon" alt="user-address">
                <div class="text-container">
                    <p>You haven't added any shipping addresses yet.</p>
                    <button class="btn btn-deep-orange" @click="openModal()" type="button">{{ buttonText }}</button>
                </div>
            </div>
        </div>
        <upload-start-popup-component></upload-start-popup-component>
    </div>
</template>

<script>
    import UploadStartPopupComponent from '../../common/UploadStartPopupComponent.vue';
    export default {
        components:{
            UploadStartPopupComponent
        },
        data(){
            return{
                noDataFoundIcon:"website/images/icons/design1.png",
                buttonText:'Upload new design',
                productImgUrl: 'images/products/business-card-1.png'
            }
        },
        methods:{
            openModal(){
                $('#upload_design').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            },
        }
    }
</script>