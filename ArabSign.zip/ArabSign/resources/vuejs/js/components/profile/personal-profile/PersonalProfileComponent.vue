
<template>
        <div class="tab-pane fade show active" id="personal_profile_content" role="tabpanel" aria-labelledby="personal_profile_content">
           <div class="tab-name">
               Personal Profile
           </div>
            <form class="form">
                <div class="row">
                    <div class="col-sm-6">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="first_name" placeholder="eg. Ahmed" required>
                    </div>
                    <div class="col-sm-6">
                        <label>Family Name</label>
                        <input type="text" class="form-control" name="family_name" placeholder="eg. Khaled" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" placeholder="eg. example@example.com" required>
                        <label>Mobile Number</label>
                        <input type="phone" class="form-control" name="phone" placeholder="eg. 966 5XX XXX XXX" required>
                    </div>
                </div>
                <div class="row justify-content-end">
                    <div class="button-container">
                        <button type="button" class="btn btn-deep-orange">Save Info</button>
                    </div>
                </div>
            </form>
            <hr>
            <div class="tab-name">
                Change Password
            </div>
            <form class="form">
                <div class="row">
                    <div class="col-sm-6">
                        <label>Current Password</label>
                        <input type="password" class="form-control" name="first_name">
                        <label>New Password</label>
                        <input type="password" class="form-control" name="last_name">
                    </div>
                </div>
                <div class="row justify-content-end">
                    <div class="button-container">
                        <button type="button" class="btn btn-deep-orange">Update Password</button>
                    </div>
                </div>
            </form>
        </div>
</template>

