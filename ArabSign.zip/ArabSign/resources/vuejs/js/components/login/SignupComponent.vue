<template>
    <div>
    <!-- Modal -->
    <div class="modal fade" id="signUpForm" tabindex="-1" role="dialog" aria-labelledby="signUpForm"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <!--Content-->
            <div class="modal-content form-elegant">
                <form class="signin-signup-form" method="post" action="/register">
                <!--Header-->
                
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Sign Up</h2>
                    
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body mx-4">
                    <!--Body-->
                    <div class="row">
                        <div class="col-sm-6">
                            <label data-error="wrong" data-success="right"> First name </label><span class="required-class">*</span>
                            <input type="text" class="form-control" name="First_name" required>
                        </div>
                        <div class="col-sm-6">
                            <label data-error="wrong" data-success="right"> Last name</label>
                            <input type="text"  class="form-control" name="Last_name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label data-error="wrong" data-success="right"> Phone</label>
                        <input type="text" class="form-control" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label data-error="wrong" data-success="right"> Email </label><span class="required-class">*</span>
                        <input type="email" class="form-control" name="email" required>
                    </div>

                    <div class="form-group">
                        <label data-error="wrong" data-success="right" for="Form-pass1"> password </label><span class="required-class">*</span>
                        <input type="password" id="Form-pass1" class="form-control" name="password" required>
                    </div>

                    <div class="text-center form-group">
                        <button type="submit" class="btn blue-gradient btn-block btn-rounded z-depth-1a mx-0">Sign Up</button>
                    </div>
                    <p class="font-small dark-grey-text text-right d-flex justify-content-center mb-3 pt-5"> <strong>or Sign up
                        with:</strong></p>

                    <div class="row my-3 justify-content-center">
                        <div class="button-container">
                            <!--Facebook-->
                            <button type="button" class="btn btn-blue btn-block z-depth-0"><i class="fab fa-facebook-f text-center"></i></button>
                        </div>
                        <div class="button-container">
                            <!--Google +-->
                            <button type="button" class="btn btn-red btn-block z-depth-0"><i class="fab fa-google-plus-g"></i></button>
                        </div>

                    </div>
                </div>
                <!--Footer-->
                <div class="modal-footer mx-5 pt-3 mb-1">
                    <p class="font-small grey-text d-flex justify-content-end">Already a member?
                        <a href="#" class="blue-text ml-1" data-toggle="modal" data-target="#signInForm" data-dismiss="modal">
                        Sign In</a>
                    </p>
                </div>
                </form>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!-- Modal -->

    <div class="text-center">
        <a href="" class="btn btn-deep-orange" data-toggle="modal" data-target="#signUpForm">Sign Up</a>
    </div>

    </div>
</template>

<script>
    import SignInComponent from './SignInComponent.vue';
    export default {
        components:{
            SignInComponent
        }
    }
</script>