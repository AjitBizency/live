<template>
    <div>
    <!-- Modal -->
    <div class="modal fade" id="forgotPasswordForm" tabindex="-1" role="dialog" aria-labelledby="signUpForm"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <!--Content-->
            <div class="modal-content form-elegant">
                <form class="signin-signup-form" method="post" action="">
                <!--Header-->
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Reset Password</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body mx-4">
                    <!--Body-->
                    <div class="form-group">
                        <label data-error="wrong" data-success="right" for="Form-email1">Email</label>
                        <input type="email" id="Form-email1" class="form-control" name="email" required>
                    </div>

                    <div class="text-center form-group">
                        <button type="button" class="btn blue-gradient btn-block btn-rounded z-depth-1a mx-0">Send mail</button>
                    </div>
                </div>
                <!--Footer-->
                <div class="modal-footer mx-5 pt-3 mb-1">
                    <p class="font-small grey-text d-flex justify-content-end">
                        <a href="#" class="blue-text ml-1" data-toggle="modal" data-target="#signInForm" data-dismiss="modal">
                        Sign In</a>
                    </p>
                </div>
                </form>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!-- Modal -->

<sign-in-component></sign-in-component>
    </div>
</template>

<script>
    import SignInComponent from './SignInComponent.vue';
    export default {
        components:{
            SignInComponent
        }
    }
</script>