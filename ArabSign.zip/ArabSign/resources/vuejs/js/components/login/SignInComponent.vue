<template>
    <div>
        <!-- Modal -->
        <div class="modal fade" id="signInForm" tabindex="-1" role="dialog" aria-labelledby="signInForm"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <!--Content-->
                <div class="modal-content form-elegant">
                    <!--Header-->
                    <div class="modal-header text-center">
                        <h2 class="modal-title w-100 font-weight-bold">Sign in</h2>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!--Body-->
                    <div class="modal-body mx-4">
                        <!--Body-->
                        <form method="post" action="/authenticate">
                            <div class="form-group">
                                <label data-error="wrong" data-success="right" for="Form-email1">Email</label>
                                <input type="email" name="email" id="Form-email1" class="form-control validate">

                            </div>

                            <div class="form-group">
                                <label data-error="wrong" data-success="right" for="Form-pass1">Password</label>
                                <input type="password" name="password" id="Form-pass1" class="form-control validate">

                                <p class="font-small blue-text d-flex justify-content-end">
                                    <a href="#" class="blue-text ml-1" data-toggle="modal"
                                        data-target="#forgotPasswordForm" data-dismiss="modal">
                                        Forgot Password?</a>
                                </p>
                            </div>

                            <div class="text-center form-group">
                                <button type="submit" class="btn blue-gradient btn-block btn-rounded z-depth-1a">Sign
                                    in</button>
                            </div>
                            <input type="hidden" value="" id="url" name="url"/>
                        </form>
                        <p class="font-small dark-grey-text text-right d-flex justify-content-center mb-3 pt-5"><strong>
                                or Sign in
                                with:</strong></p>
                        
                        <div class="row my-3 justify-content-center">
                            <!--Facebook-->
                            <button type="button" class="btn btn-blue btn-block z-depth-0"><i
                                    class="fab fa-facebook-f text-center"></i></button>
                            <!--Google +-->
                            <button type="button" class="btn btn-red btn-block z-depth-0"><i
                                    class="fab fa-google-plus-g"></i></button>
                        </div>
                    </div>
                    <!--Footer-->
                    <div class="modal-footer mx-5 pt-3 mb-1">
                        <p class="font-small grey-text d-flex justify-content-end">Not a member?
                            <a href="#" class="blue-text ml-1" data-toggle="modal" data-target="#signUpForm"
                                data-dismiss="modal">
                                Sign Up</a></p>
                    </div>
                </div>
                <!--/.Content-->
            </div>
        </div>
        <!-- Modal -->

        <div class="text-center">
            <a href="" class="btn btn-deep-orange" data-toggle="modal" data-target="#signInForm">Sign In</a>
        </div>
        <forgot-password-component></forgot-password-component>
    </div>
    
</template>

<script>
    import SignupComponent from './SignupComponent.vue';
    import ForgotPasswordComponent from './ForgotPasswordComponent.vue';
    export default {
        components: {
            SignupComponent,
            ForgotPasswordComponent
        },
        methods:{
        toggleSelected: function(value) {
                alert(window.location.pathname);
            $("#url").val(window.location.pathname);
                  
	}
        },
        created: function () { 

       
    this.toggleSelected();
  },
    }
</