<template>
    <div class="home-page-layout">
       <home-slider-component></home-slider-component>
        <product-carousel-component></product-carousel-component>
        <how-it-works-component></how-it-works-component>
        <like-to-print></like-to-print>
        <designers-market-place-component></designers-market-place-component>
        <stay-in-touch-component></stay-in-touch-component>
    </div>

</template>

<script>

    import HomeSliderComponent from './home-page/HomeSliderComponent.vue';
    import ProductCarouselComponent from './home-page/ProductCarouselComponent.vue';
    import HowItWorksComponent from './home-page/HowItWorksComponent.vue';
    import LikeToPrint from './home-page/LikeToPrintComponent.vue';
    import DesignersMarketPlaceComponent from './home-page/DesignersMarketPlaceComponent.vue';
    import StayInTouchComponent from './home-page/StayInTouchComponent.vue';

    export default {
        components: {
            HomeSliderComponent,
            ProductCarouselComponent,
            HowItWorksComponent,
            LikeToPrint,
            DesignersMarketPlaceComponent,
            StayInTouchComponent
        },
        mounted() {
            console.log('Haroon.')
        }
    }
</script>