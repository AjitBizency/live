<template>
    <div class="row justify-content-end top-bar mx-0">
        <ul class="list-group list-group-horizontal topbar-list">
            <li class="list-group-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">English
                </a>
                <div class="dropdown-menu z-depth-1">
                    <a class="dropdown-item" href="javascript:void(0)">Arabic</a>
                </div>
            </li>

            <li class="list-group-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="zeej-icons-container"><img src="website/images/header-images/flag-saudi.png"/></span>Saudi Arabia
                </a>
                <div class="dropdown-menu z-depth-1">
                    <a class="dropdown-item" href="javascript:void(0)">
                        <span class="zeej-icons-container"><img src="website/images/header-images/flag-india.png"/>India</span>
                    </a>
                </div>
            </li>
            <li class="list-group-item"><a href="javascript:void(0)"><span class="zeej-icons-container"><i class="fas fa-sign-in-alt"></i></span>Login</a></li>
            <li class="list-group-item"><a href="javascript:void(0)"><span class="zeej-icons-container"><i class="fa fa-shopping-cart"></i></span>My Cart</a></li>

        </ul>
    </div>
</template>

<script>
    export default{

    };
</script>