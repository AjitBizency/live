<template>
    <nav class="navbar navbar-expand-lg zeej-menu">
        <!-- Navbar brand -->
        <a class="navbar-brand" href="#"><img src="website/images/header-images/zeejlogo.png" class="logo"/> </a>
        <!-- Collapse button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
                aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Collapsible content -->
        <div class="collapse navbar-collapse" id="basicExampleNav">
            <!-- Links -->
            <ul class="navbar-nav m-auto">
                <li class="nav-item dropdown active">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Our Products
                        <span class="sr-only">(current)</span>
                    </a>
                    <div class="dropdown-menu custom-mega-menu">
                       <ul class="vertical-nav list-unstyled">
                           
                           <li class="has-dropdown">
                               <a href="javascript:void(0)" class="dropdown-item">Flyers</a>
                               <div class="vertical-tab-content">
                                   <div class="row">
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Flyers</h1>
                                               </div>
                                           </a>
                                       </div>
                                   </div>
                                   <div class="row justify-content-end">
                                       <a href="#" class="see-all-link btn btn-deep-orange">
                                           See all
                                       </a>
                                   </div>
                               </div>
                           </li>
                           <li class="has-dropdown">
                               <a href="javascript:void(0)" class="dropdown-item">Category-1</a>
                               <div class="vertical-tab-content">
                                   <div class="row">
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                   </div>
                                   <div class="row justify-content-end">
                                       <a href="#" class="see-all-link btn btn-deep-orange">
                                           See all
                                       </a>
                                   </div>
                               </div>
                           </li>
                           <li class="has-dropdown">
                               <a href="javascript:void(0)" class="dropdown-item">Category-2</a>
                               <div class="vertical-tab-content">
                                   <div class="row">
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                   </div>
                                   <div class="row justify-content-end">
                                       <a href="#" class="see-all-link btn btn-deep-orange">
                                           See all
                                       </a>
                                   </div>
                               </div>
                           </li>
                           <li class="has-dropdown">
                               <a href="javascript:void(0)" class="dropdown-item">Category-3</a>
                               <div class="vertical-tab-content">
                                   <div class="row">
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                   </div>
                                   <div class="row justify-content-end">
                                       <a href="#" class="see-all-link btn btn-deep-orange">
                                           See all
                                       </a>
                                   </div>
                               </div>
                           </li>
                           <li class="has-dropdown">
                               <a href="javascript:void(0)" class="dropdown-item">Category-4</a>
                               <div class="vertical-tab-content">
                                   <div class="row">
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>
                                       <div class="col-sm-2 product-category-box">
                                           <a href="#" class="sub-menu-image">
                                               <img src="website/images/products/business-card-1.png" alt="zeej-product business-card">
                                               <div class="img-caption"><h1>Business Cards</h1>
                                               </div>
                                           </a>
                                       </div>

                                   </div>
                                   <div class="row justify-content-end">
                                       <a href="#" class="see-all-link btn btn-deep-orange">
                                           See all
                                       </a>
                                   </div>
                               </div>
                           </li>
                       </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blog</a>
                </li>
            </ul>
            <!-- Links -->
            <form class="form-inline">
                <div class="md-form my-0">
                    <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
                </div>
            </form>
        </div>
        <!-- Collapsible content -->

    </nav>
</template>

<script>
    export default{
     data() {
            return {
                step: 0,
                
                nav_top: []
            }
        },
        methods: {
           
            fetchData: function () {
                const my = this;
                
                my.product_type.options =[];
                axios({
                  url: 'http://localhost/bizmis/public/list_family',
                  method: 'get'
                })
                .then(function (response) {
                  console.log(response)
                  
                  for(var prop in response.data.data) {
                  console.log(prop);
                  
                   }
                }) 
                .catch(function (error) {
                  console.log(error)
                  my.product_type = error
                })
              },
            
               
  
        },
        
created: function () { 

       
    this.fetchData();
  },
    }
</script>