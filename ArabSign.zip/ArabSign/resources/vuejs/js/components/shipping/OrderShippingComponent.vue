<template>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>1. How would you like to receive your order?</h4>
            </div>
            <div class="col-sm-4">
                <button type="button" id="pickup_from_branch" class="btn large-btn" :class="{active_address: addressValue === 'pickup_from_branch'}" @click="selectAddress('pickup_from_branch')">Pickup from branch</button>
            </div>
            <div class="col-sm-4">
                <button type="button" id="delivery_address" class="btn large-btn" :class="{active_address: addressValue === 'delivery_address'}" @click="selectAddress('delivery_address')">Delivery</button>
            </div>
        </div>
        <!--pickup-from-branch-->
        <div class="pickup-from-branch" v-if="addressValue === 'pickup_from_branch'">
            <h5>Select the branch</h5>
            <div class="row">
                <div class="col-sm-6">
                    <label>City</label>
                    <select name="city" class="form-control">
                        <option>Select the city</option>
                    </select>
                </div>
                <div class="col-sm-6">
                    <label>Branch</label>
                    <select name="branch" class="form-control">
                        <option>Select the branch</option>
                    </select>
                </div>
            </div>
        </div>
        <!--/pickup-from-branch-->

        <!--delivery-address-->
        <div class="delivery-address" v-if="addressValue === 'delivery_address'">
            <h5>Select your shipping address</h5>
            <div class="row">
                <div class="col-sm-9">
                    <div class="custom-control custom-radio">
                        <input type="radio" class="custom-control-input" id="shipping_1" name="shipping_address">
                        <label class="custom-control-label" for="shipping_1">Panda HQ, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</label>
                    </div>
                    <div class="custom-control custom-radio">
                        <input type="radio" class="custom-control-input" id="shipping_2" name="shipping_address">
                        <label class="custom-control-label" for="shipping_2">Office, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</label>
                    </div>
                    <div class="custom-control custom-radio">
                        <input type="radio" class="custom-control-input" id="shipping_3" name="shipping_address">
                        <label class="custom-control-label" for="shipping_3">House, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</label>
                    </div>
                </div>
            </div>
            <div class="row modal-footer">
                <div class="button-container">
                    <a href="#"><strong>View all 5 addresses</strong></a>
                    <button type="button" class="btn custom-btn-outline">Add New Address</button>
                </div>
            </div>
        </div>
        <!--/delivery-address-->

        <!--contact details-->
        <div class="contact-details">
            <div class="row">
                <div class="col-md-12">
                    <h5>Contact details</h5>
                </div>
                <div class="col-sm-6">
                    <label>Full Name</label>
                    <input type="text" class="form-control" name="full_name">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="eg. example@example.com">
                </div>
                <div class="col-md-6 col-sm-12">
                    <label>Mobile Number</label>
                    <input type="phone" class="form-control" name="phone" placeholder="eg. 966 5XX XXX XXX">
                </div>
            </div>
        </div>
        <!--/contact details-->

        <!--select preference-->
        <div class="contact-details">
            <div class="row">
                <div class="col-md-12">
                    <h4>Select your pick up preference</h4>
                    <div class="custom-control custom-radio">
                        <input type="radio" class="custom-control-input" id="standard" name="preferred_address">
                        <label class="custom-control-label" for="standard">Panda HQ, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</label>
                    </div>
                    <div class="custom-control custom-radio">
                        <input type="radio" class="custom-control-input" id="urgent" name="preferred_address">
                        <label class="custom-control-label" for="urgent">
                            Office, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            <span class="custom-note yellow-text"><strong>Note:</strong> Extra fees may apply</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <!--/select preference-->

        <!--pick up instruction-->
        <div class="pick-up-instruction">
            <div class="important-note-box">
                <h4>Pick up instructions</h4>
                <p>
                    Don't forget to show your digital receipt when you pick the order.Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit, sed do eiusmod tempor.Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit, sed do eiusmod tempor
                </p>
            </div>
        </div>
        <!--/pick up instruction-->

        <!--payment details-->
        <div class="payment-details">
            <h4>2. Payment Details</h4>
            <div class="payment-method-box">
                <h5>Payment Methods:</h5>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="wallet_balance" name="payment_method">
                    <label class="custom-control-label" for="wallet_balance">Balance: 400 SAR</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="paypal" name="payment_method">
                    <label class="custom-control-label" for="paypal">PayPal
                        <i class="img-icon"><img :src="payPalIcon" alt="paypal icon" /></i>
                    </label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="sadad" name="payment_method">
                    <label class="custom-control-label" for="sadad">Sadad
                        <i class="img-icon"><img :src="sadadCardIcon" alt="sadad icon" /></i>
                    </label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="creidt_debit_card" name="payment_method">
                    <label class="custom-control-label" for="creidt_debit_card">Credit Card/Mada
                        <i class="img-icon">
                            <img :src="madaCardIcon" alt="credit card/mada" />
                            <img :src="masterCardIcon" alt="credit card/mada" />
                            <img :src="visaCardIcon" alt="credit card/mada" />
                        </i>
                    </label>
                </div>
            </div>
        </div>
        <!--/payment details-->

        <!--order-total-container-->
        <div class="order-total-container cart-container">
            <!--cart total-->
            <div class="cart-total">
                <div class="total-amount-box">
                    <table class="table">
                        <tr>
                            <td><strong>Order total</strong></td>
                            <td>200 SAR</td>
                        </tr>
                        <tr>
                            <td><strong>Shipping fees</strong></td>
                            <td>50 SAR</td>
                        </tr>
                        <tr>
                            <td><strong>Urgent pickup</strong></td>
                            <td>Not applicable</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="top-margin">
                                    <strong class="total-head">Your Total</strong>
                                </div>
                            </td>
                            <td>
                                <div class="top-margin">
                                    <strong class="total-amount">250 SAR</strong>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <!--/cart total-->
            <div class="review-btn-container">
                <button type="button" class="btn custom-btn-outline z-depth-0">
                    Review Order
                </button>
            </div>
        </div>
        <!--/order-total-container-->

        <!--order-btn-container-->
        <div class="order-btn-container">
            <div class="msg-box">You can pickup your order in 4 days(24 July 2019)</div>
            <div class="review-btn-container">
                <button class="btn btn-deep-orange" type="button" @click.prevent="next()">Place Order</button>
            </div>
        </div>
        <!--/order-btn-container-->
    </div>
</template>

<script>

    export default {
        data() {
            return {
                addressValue:'pickup_from_branch',
                payPalIcon:'images/icons/paypal.png',
                madaCardIcon:'images/icons/mada-card.png',
                masterCardIcon:'images/icons/mastercard.png',
                visaCardIcon:'images/icons/visa.png',
                sadadCardIcon:'images/icons/sadad-card.png',
            }
        },
        methods:{
            selectAddress(selected_address) {
                this.addressValue = selected_address;
//                console.log($('#'+selected_address));
            }
        }
    }
</script>