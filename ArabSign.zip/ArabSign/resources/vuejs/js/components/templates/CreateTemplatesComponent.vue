<template>
    <div class="container templates-container" id="upload_design">
        <div class="page-title-container">
            <h1 class="page-title">Create new template</h1>
        </div>
        <div class="template-form-container">
            <div class="profile-container">
                <div class="profile-pic">
                    <img :src="businessIcon" alt="profile-pic"/>
                </div>
                <div class="profile-name">
                    <h4>
                        Blesson John
                    </h4>
                    <label>blessonjohn@zeejprint.com</label>
                </div>
            </div>

                <div class="form-container">
                    <form class="form">
                        <div class="row">
                            <div class="col-sm-6">
                                <label>Product type</label>
                                <select class="form-control" name="product_type">
                                    <option value="">Select</option>
                                    <option value="type-1">type-1</option>
                                    <option value="type-2">type-2</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>Product</label>
                                <select class="form-control" name="product_name">
                                    <option value="">Select</option>
                                    <option value="product-1">product-1</option>
                                    <option value="product-2">product-2</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-3">
                                <label>Size</label>
                                <select class="form-control" name="product_size">
                                    <option value="">Select</option>
                                    <option value="size-1">size-1</option>
                                    <option value="size-2">size-2</option>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <label>Side</label>
                                <select class="form-control" name="product_side">
                                    <option value="">Select</option>
                                    <option value="side-1">side-1</option>
                                    <option value="side-2">side-2</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>No. of pages</label>
                                <input type="text" name="no_of_pages" class="form-control">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <label>Category</label>
                                <select class="form-control" name="product_category">
                                    <option value="">Select</option>
                                    <option value="category-1">category-1</option>
                                    <option value="category-2">category-2</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                    <option value="">Select</option>
                                    <option value="status-1">status-1</option>
                                    <option value="status-2">status-2</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <label>Template Name</label>
                                <input type="text" name="template_name" class="form-control">
                            </div>
                            <div class="col-sm-6">
                                <label>Template name in Arabic</label>
                                <input type="text" name="template_name_arabic" class="form-control">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <label>Designer</label>
                                <select class="form-control" name="designer_name">
                                    <option value="">Select</option>
                                    <option value="designer-1">designer-1</option>
                                    <option value="designer-2">designer-2</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>PSD</label>
                                <input type="file" name="template_file" class="form-control">
                            </div>
                        </div>
                        <div class="row">

                        </div>
                        <div class="row justify-content-end">
                            <div class="button-container">
                                <button type="button" class="btn btn-deep-orange">Save Template</button>
                            </div>
                        </div>
                    </form>
                </div>

        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                businessIcon:'images/icons/dummy.png',

            }
        },
    }
</script>