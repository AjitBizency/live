<template>
    <div class="container templates-container">
        <div class="page-title-container">
            <h1 class="page-title">Use our templates</h1>
        </div>
        <div class="product-list-box">
            <div class="template-banner">
                <img :src="templateBanner" alt="templates-banner"/>
            </div>
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Business Cards</a>
                    </li>
                    <li class="breadcrumb-item active">Templates</li>
                </ol>
            </nav>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-5">
                    <h3>Price Range</h3>
                    <div class="price-range-slider">
                        <div class="track-container">
                            <span class="range-value min">${{ minValue}} </span> <span class="range-value max">${{ maxValue }}</span>
                            <div class="track" ref="_vpcTrack"></div>
                            <div class="track-highlight" ref="trackHighlight"></div>
                            <button class="track-btn track1" ref="track1"></button>
                            <button class="track-btn track2" ref="track2"></button>
                        </div>
                    </div>
                    <!--/price range--->

                    <div class="category-sidebar">
                        <h3>Categories</h3>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="panda">
                            <label class="custom-control-label" for="panda">Panda</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="business-cards">
                            <label class="custom-control-label" for="business-cards">Business Cards</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="brochures">
                            <label class="custom-control-label" for="brochures">Brochures</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="clients">
                            <label class="custom-control-label" for="clients">Clients</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="photography">
                            <label class="custom-control-label" for="photography">Photography</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="technology">
                            <label class="custom-control-label" for="technology">Technology</label>
                        </div>
                    </div>
                    <!--/categories-->

                    <div class="category-sidebar">
                        <h3>Business Sectors</h3>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="sector-1">
                            <label class="custom-control-label" for="sector-1">Sector-1</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="sector-2">
                            <label class="custom-control-label" for="sector-2">Sector-2</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="sector-3">
                            <label class="custom-control-label" for="sector-3">Sector-3</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="sector-4">
                            <label class="custom-control-label" for="sector-4">Sector-4</label>
                        </div>
                    </div>
                    <!--/Business Sectors-->

                    <div class="category-sidebar">
                        <h3>Designed By</h3>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="designer-1">
                            <label class="custom-control-label" for="designer-1">Designer-1</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="designer-2">
                            <label class="custom-control-label" for="designer-2">Designer-2</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="designer-3">
                            <label class="custom-control-label" for="designer-3">Designer-3</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="designer-4">
                            <label class="custom-control-label" for="designer-4">Designer-4</label>
                        </div>
                    </div>
                    <!--/Designed By-->
                </div>
                <!--/left-side-->
                <div class="col-lg-9 col-md-9 col-sm-7">
                    <div class="row">
                        <div class="col-sm-4" v-for="templateItem in templatesList">
                            <a href="#" class="link-box">
                                <div class="product-category-box">
                                    <img :src="`images/products/`+templateItem.imgName" :alt="templateItem.templateName">

                                    <div class="hover-box">
                                       <button type="button" class="btn btn-white">Select Template</button>
                                    </div>
                                </div>
                                <div class="template-caption">
                                    <div class="name-price">
                                        <span class="product-name-span">{{ templateItem.templateName }}</span>
                                        <span class="price-span">${{ templateItem.price }}</span>
                                    </div>
                                    <div><span class="designedBy-span">{{ templateItem.designedBy }}</span></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                min: 0,
                max: 1000,
                minValue: 50,
                maxValue: 350,
                step: 10,
                totalSteps: 0,
                percentPerStep: 1,
                trackWidth: null,
                isDragging: false,
                pos: {
                    curTrack: null
                },
                templateBanner:'images/templates-page-banner.jpg',
                businessIcon:'images/icons/b-card1.png',
                templatesList:[
                    {id:1, templateName:'ZP Templates',  designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                    {id:2, templateName:'ZP Templates1', designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                    {id:3, templateName:'ZP Templates2', designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                    {id:4, templateName:'ZP Templates3', designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                    {id:5, templateName:'ZP Templates4', designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                    {id:6, templateName:'ZP Templates5', designedBy:'By Panda HQ', imgName:'business-card-1.png', price:10},
                ],
            }
        },
        methods: {
            moveTrack(track, ev){

                let percentInPx = this.getPercentInPx();

                let trackX = Math.round(this.$refs._vpcTrack.getBoundingClientRect().left);
                let clientX = ev.clientX;
                let moveDiff = clientX-trackX;

                let moveInPct = moveDiff / percentInPx
                // console.log(moveInPct)

                if(moveInPct<1 || moveInPct>100) return;
                let value = ( Math.round(moveInPct / this.percentPerStep) * this.step ) + this.min;
                if(track==='track1'){
                    if(value >= (this.maxValue - this.step)) return;
                    this.minValue = value;
                }

                if(track==='track2'){
                    if(value <= (this.minValue + this.step)) return;
                    this.maxValue = value;
                }

                this.$refs[track].style.left = moveInPct + '%';
                this.setTrackHightlight()

            },
            mousedown(ev, track){

                if(this.isDragging) return;
                this.isDragging = true;
                this.pos.curTrack = track;
            },

            touchstart(ev, track){
                this.mousedown(ev, track)
            },

            mouseup(ev, track){
                if(!this.isDragging) return;
                this.isDragging = false
            },

            touchend(ev, track){
                this.mouseup(ev, track)
            },

            mousemove(ev, track){
                if(!this.isDragging) return;
                this.moveTrack(track, ev)
            },

            touchmove(ev, track){
                this.mousemove(ev.changedTouches[0], track)
            },

            valueToPercent(value){
                return ((value - this.min) / this.step) * this.percentPerStep
            },

            setTrackHightlight(){
                this.$refs.trackHighlight.style.left = this.valueToPercent(this.minValue) + '%'
                this.$refs.trackHighlight.style.width = (this.valueToPercent(this.maxValue) - this.valueToPercent(this.minValue)) + '%'
            },

            getPercentInPx(){
                let trackWidth = this.$refs._vpcTrack.offsetWidth;
                let oneStepInPx = trackWidth / this.totalSteps;
                // 1 percent in px
                let percentInPx = oneStepInPx / this.percentPerStep;

                return percentInPx;
            },

            setClickMove(ev){
                let track1Left = this.$refs.track1.getBoundingClientRect().left;
                let track2Left = this.$refs.track2.getBoundingClientRect().left;
                // console.log('track1Left', track1Left)
                if(ev.clientX < track1Left){
                    this.moveTrack('track1', ev)
                }else if((ev.clientX - track1Left) < (track2Left - ev.clientX) ){
                    this.moveTrack('track1', ev)
                }else{
                    this.moveTrack('track2', ev)
                }
            }
        },
        mounted() {
            // calc per step value
            this.totalSteps = (this.max - this.min) / this.step;

            // percent the track button to be moved on each step
            this.percentPerStep = 100 / this.totalSteps;
            // console.log('percentPerStep', this.percentPerStep)

            // set track1 initilal
            document.querySelector('.track1').style.left = this.valueToPercent(this.minValue) + '%'
            // track2 initial position
            document.querySelector('.track2').style.left = this.valueToPercent(this.maxValue) + '%'
            // set initila track highlight
            this.setTrackHightlight()

            var self = this;

            ['mouseup', 'mousemove'].forEach( type => {
                document.body.addEventListener(type, (ev) => {
                    // ev.preventDefault();
                    if(self.isDragging && self.pos.curTrack){
                        self[type](ev, self.pos.curTrack)
                    }
                })
            });

            ['mousedown', 'mouseup', 'mousemove', 'touchstart', 'touchmove', 'touchend'].forEach( type => {
                document.querySelector('.track1').addEventListener(type, (ev) => {
                    ev.stopPropagation();
                    self[type](ev, 'track1')
                })

                document.querySelector('.track2').addEventListener(type, (ev) => {
                    ev.stopPropagation();
                    self[type](ev, 'track2')
                })
            })

            // on track clik
            // determine direction based on click proximity
            // determine percent to move based on track.clientX - click.clientX
            document.querySelector('.track').addEventListener('click', function(ev) {
                ev.stopPropagation();
                self.setClickMove(ev)

            })

            document.querySelector('.track-highlight').addEventListener('click', function(ev) {
                ev.stopPropagation();
                self.setClickMove(ev)

            })
        }
    }
</script>