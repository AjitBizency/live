<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<template>
    <div class="modal fade" id="select_product_type" tabindex="-1" role="dialog" aria-labelledby="select_product_type"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Upload Design</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body select-product-box">
                    <form class="form" method="post" action="">
                        <div class="row justify-content-center">
                            <div class="col-md-11">
                                <h4>Select the product type</h4>
                                <div class="form-group">
                                    <label>Product Type</label>
                                    <multiselect v-model="product_type.value" :options="product_type.options"  placeholder="Select one" label="name" track-by="name" ></multiselect>
                                </div>
                                <h4>Product Design Specifications</h4>
                                <!--div to show when no option is selected-->
                                <div class="no-content-box">
                                    <div class="row justify-content-center">
                                        <div class="col-sm-7 text-center">
                                            <img v-bind:src="noDataFoundIcon" alt="user-address">
                                            <p class="home-page-subhead">The design guide will appear here based on the selected product</p>
                                        </div>
                                    </div>
                                </div>
                                <!--/no-content-box-->

                                <!--div to show when any option is selected-->
                                <div class="data-content-box">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <img :src="productDesignImg" alt="product-type"/>
                                        </div>
                                        <div class="col-md-5">
                                            <ol>
                                                <li>
                                                    <strong>Set the dimensions of your design to: 3.75" X 2.25"</strong>
                                                    <ul class="list-unstyled">
                                                        <li><strong>The final trim size will be:</strong> 3.5" X 2"</li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <strong>Design Area:</strong> 0.125" within the trim line. As trim line may vary slightly, keep any text or graphics
                                                    that you want to preserve within design area.
                                                </li>
                                                <li>
                                                    <strong>Bleed:</strong> 0.125" beyond trim edge. If you want your background to print to the edge of your design,
                                                    extend any background images or color beyond the trim line.
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
                                    <!--/data-content-box-->
                                    <div class="row">
                                        <div class="col-md-7">
                                            <p><a href="javascript:void(0)"><i class="fas fa-question-circle"></i> Additional design help?</a> </p>
                                        </div>
                                        <div class="col-md-5 px-0">
                                            <p><a href="javascript:void(0)"><i class="fas fa-arrow-alt-circle-down"></i> Download our design template</a> </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <div class="button-container"><button type="button" class="z-depth-0 btn custom-btn-outline">Previous</button></div>
                            <div class="button-container"><button type="button" data-toggle="modal" data-target="#upload_design_file" class="z-depth-0 btn custom-btn-outline">Next</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <design-file-upload-popup-component></design-file-upload-popup-component>
    </div>
</template>

<script>
    import DesignFileUploadPopupComponent from './DesignFileUploadPopupComponent.vue';
    export default {
        components:{
            DesignFileUploadPopupComponent
        },
        data(){
            return{
                noDataFoundIcon:"website/images/icons/design1.png",
               productDesignImg:"website/images/icons/business-card-specification.png",
                product_type :{
                    selected :1 ,
                    value: { name: '-- select --', id: ' ' },
                    input_id : 'product-id',
                    options: [
                        { name: '-- select --', id: ' ' ,$isDisabled: true },
                        { name: 'Business Cards', id: '1' },
                        { name: 'Letterheads', id: '2'  },
                        { name: 'Brochures', id: '3'  },
                        { name: 'Mugs', id: '4'  }
                    ],
                },
            }
        },

    }
</script>