<template>
        <div class="modal fade" id="upload_design_file" tabindex="-1" role="dialog" aria-labelledby="upload_design_file"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Upload Design</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body select-product-box">
                    <form class="form" method="post" action="">
                        <div class="row justify-content-center">
                            <div class="col-md-11">
                                <h4>Upload your design</h4>
                                <div class="row">
                                    <div class="col-sm-5">
                                        <div class="form-group design-upload-box">
                                            <div class="button-container">
                                                <label class="z-depth-0 btn custom-btn-outline upload-button" for="design_upload">
                                                    <input type="file" name="upload_deasign" id="design_upload">
                                                    Choose file
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-7">
                                        <div class="file-type-box">
                                            <div class="file-type-size">
                                                <p class="font-small">You can upload the following types</p>
                                                <p class="font-small"><strong>Max file size: 100MB</strong></p>
                                            </div>
                                            <div class="file-type-preview">
                                                <img v-bind:src="psdIcon" alt="psd-file-type"/>
                                                <img v-bind:src="pdfIcon" alt="pdf-file-type"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-between">
                                    <div class="col-sm-6">
                                        <div class="design-link-box">
                                          <span><img :src="psdIcon" alt="file-name" width="20px"/></span>
                                          <label class="font-small">business_card.psd</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <span class="success-status">File uploaded <i class="fas fa-check"></i></span>
                                    </div>
                                </div>
                                <hr class="my-2"/>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="form-group design-link-box">
                                            <label class="font-small">or copy and paste a link to your dropbox file here:</label>
                                            <input type="text" name="product_design_link" class="form-control" placeholder="Copy and paste a link to your image">
                                        </div>
                                    </div>
                                </div>
                                <hr class="my-2"/>
                                <!--div to show when any option is selected-->
                                <div class="data-content-box">
                                    <!--important-note-box-->
                                    <div class="important-note-box">
                                        <p class="font-small">
                                            <strong>Important Note: </strong>
                                            If you selected 2 sided business card, make sure your PSD file contains that based on our template.
                                            Our customer service will contact you if your template is corrupted or doesn't match the specs.
                                            We recommend you to use our <a href="javascript:void(0)">design template</a> if you haven't.
                                        </p>
                                    </div>
                                    <!--/important-note-box-->

                                    <!--design-preview-box-->
                                    <h4>Design preview</h4>
                                    <div class="design-preview-box row">
                                        <div class="col-sm-4 px-2" v-for="previewIconLink in previewIcon">
                                            <img :src="`images/icons/${previewIconLink}`" :alt="`${previewIconLink}`"/>
                                        </div>
                                    </div>
                                    <!--/design-preview-box-->

                                    <!--design-preview-box-->
                                    <div class="design-info-box">
                                        <h4>Design information</h4>
                                        <div class="form-group">
                                            <label>Design Title</label>
                                            <input type="text" name="design_title" class="form-control" placeholder="e.g. Panda Business Card">
                                        </div>
                                        <div class="form-group">
                                            <label>Tags</label>
                                            <textarea class="form-control my-1" name="design_tags" rows="4" placeholder="e.g. Marketing, Business Cards etc.">
                                            </textarea>
                                            <div class="d-flex justify-content-end">
                                                <span class="yellow-text font-small">Enter tags seperated by comma</span>
                                            </div>
                                        </div>

                                    </div>
                                    <!--/design-preview-box-->
                                </div>
                                <!--/div to show when any option is selected-->

                                <!--div to show when no option is selected-->
                                <div class="no-content-box">
                                    <div class="row justify-content-center">
                                        <div class="col-sm-7 text-center">
                                            <img v-bind:src="linkUploadIcon" alt="user-address">
                                            <p class="home-page-subhead">You file option will appear here after you upload the file</p>
                                        </div>
                                    </div>
                                </div>
                                <!--/no-content-box-->
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <div class="button-container"><button type="button" class="z-depth-0 btn custom-btn-outline">Previous</button></div>
                            <div class="button-container"><button type="button" class="z-depth-0 btn custom-btn-outline" data-dismiss="modal" name="save_user_design">Save</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
   // import FileUploadComponent from './FileUploadComponent.vue';
    export default {
//        components:{
//            FileUploadComponent,
//        },
        data(){
            return{
                linkUploadIcon:"website/images/icons/design1.png",
                pdfIcon:"website/images/icons/pdf.png",
                psdIcon:"website/images/icons/psd.png",
                previewIcon:['b-card1.png', 'b-card.png'],
            }
        },
    }
</script>