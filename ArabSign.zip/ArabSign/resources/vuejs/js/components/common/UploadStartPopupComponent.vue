<template>
    <div class="modal fade" id="upload_design" tabindex="-1" role="dialog" aria-labelledby="upload_design"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title w-100 font-weight-bold">Upload Design</h2>
                    <button type="button" class="close" @click="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="/design" enctype="multipart/form-data">
                    <input type="hidden" name="family_id" id="fid" value="" />
                    <input type="hidden" name="url" id="url" value="" />
                    <div class=" modal-body">
                        <div id="upload_button_box" v-show="step === 0">
                            <div class="row justify-space-around justify-content-center">

                                <div class="col-sm-5 text-center upload-option-box">
                                    <a href="javascript:void(0)" @click.prevent="next()">
                                        <div class="icon-container">
                                            <img v-bind:src="cloudUploadIcon" alt="upload-from-pc">
                                        </div>
                                        <div class="text-container">
                                            <p><strong>Upload from your PC</strong></p>
                                            <p class="yellow-text">You can only upload PSD files</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="select-product-box" id="select_product_type" v-show="step === 1">
                            <div class="row justify-content-center">
                                <div class="col-md-11">
                                    <h4>Select the product type</h4>
                                    <div class="form-group">
                                        <label>Product Type</label>
                                        <multiselect v-model="product_type.value"  :options="product_type.options" @input="toggleSelected(product_type.value)"
                                            placeholder="Select one" label="name"  name="" track-by="id" ></multiselect>
                                    </div>
                                    <h4>Product Design Specifications</h4>
                                    <!--div to show when no option is selected-->
                                    <div class="no-content-box">
                                        <div class="row justify-content-center">
                                            <div class="col-sm-7 text-center">
                                                <img v-bind:src="noDataFoundIcon" alt="user-address">
                                                <p class="home-page-subhead">The design guide will appear here based on
                                                    the
                                                    selected product</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/no-content-box-->

                                    <!--div to show when any option is selected-->
                                    <div class="data-content-box">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img :src="productDesignImg" alt="product-type" />
                                            </div>
                                            <div class="col-md-5">
                                                <ol>
                                                    <li>
                                                        <strong>Set the dimensions of your design to: 3.75" X
                                                            2.25"</strong>
                                                        <ul class="list-unstyled">
                                                            <li><strong>The final trim size will be:</strong> 3.5" X 2"
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <strong>Design Area:</strong> 0.125" within the trim line. As
                                                        trim
                                                        line may vary slightly, keep any text or graphics
                                                        that you want to preserve within design area.
                                                    </li>
                                                    <li>
                                                        <strong>Bleed:</strong> 0.125" beyond trim edge. If you want
                                                        your
                                                        background to print to the edge of your design,
                                                        extend any background images or color beyond the trim line.
                                                    </li>
                                                </ol>
                                            </div>
                                        </div>
                                        <!--/data-content-box-->
                                        <div class="row">
                                            <div class="col-md-7">
                                                <p><a href="javascript:void(0)"><i class="fas fa-question-circle"></i>
                                                        Additional design help?</a> </p>
                                            </div>
                                            <div class="col-md-5 px-0">
                                                <p><a href="javascript:void(0)"><i
                                                            class="fas fa-arrow-alt-circle-down"></i>
                                                        Download our design template</a> </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer justify-content-between">
                                <div class="button-container"><button type="button"
                                        class="z-depth-0 btn custom-btn-outline"
                                        @click.prevent="prev()">Previous</button></div>
                                <div class="button-container"><button type="button"
                                        class="z-depth-0 btn custom-btn-outline" @click.prevent="next()">Next</button>
                                </div>
                            </div>
                        </div>
                        <div class="select-product-box" id="design_file_upload" v-show="step === 2">
                            <div class="row justify-content-center">
                                <div class="col-md-11">
                                    <h4>Upload your design</h4>
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <div class="form-group design-upload-box">
                                                <div class="button-container">
                                                    <label class="z-depth-0 btn custom-btn-outline upload-button"
                                                        for="design_upload">
                                                        <input type="file" name="file_name" id="design_upload">
                                                        Choose file
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-7">
                                            <div class="file-type-box">
                                                <div class="file-type-size">
                                                    <p class="font-small">You can upload the following types</p>
                                                    <p class="font-small"><strong>Max file size: 100MB</strong></p>
                                                </div>
                                                <div class="file-type-preview">
                                                    <img v-bind:src="psdIcon" alt="psd-file-type" />
                                                    <img v-bind:src="pdfIcon" alt="pdf-file-type" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-between">
                                        <div class="col-sm-6">
                                            <div class="design-link-box">
                                                <span><img :src="psdIcon" alt="file-name" width="20px" /></span>
                                                <label class="font-small">business_card.psd</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <span class="success-status">File uploaded <i
                                                    class="fas fa-check"></i></span>
                                        </div>
                                    </div>
                                    <hr class="my-2" />
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <div class="form-group design-link-box">
                                                <label class="font-small">or copy and paste a link to your dropbox file
                                                    here:</label>
                                                <input type="text" name="product_design_link" class="form-control"
                                                    placeholder="Copy and paste a link to your image">
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="my-2" />
                                    <!--div to show when any option is selected-->
                                    <div class="data-content-box">
                                        <!--important-note-box-->
                                        <div class="important-note-box">
                                            <p class="font-small">
                                                <strong>Important Note: </strong>
                                                If you selected 2 sided business card, make sure your PSD file contains
                                                that
                                                based on our template.
                                                Our customer service will contact you if your template is corrupted or
                                                doesn't match the specs.
                                                We recommend you to use our <a href="javascript:void(0)">design
                                                    template</a>
                                                if you haven't.
                                            </p>
                                        </div>
                                        <!--/important-note-box-->

                                        <!--design-preview-box-->
                                        <h4>Design preview</h4>
                                        <div class="design-preview-box row">
                                            <div class="col-sm-4 px-2" v-for="previewIconLink in previewIcon">
                                                <img :src="`images/icons/${previewIconLink}`"
                                                    :alt="`${previewIconLink}`" />
                                            </div>
                                        </div>
                                        <!--/design-preview-box-->

                                        <!--design-preview-box-->
                                        <div class="design-info-box">
                                            <h4>Design information</h4>
                                            <div class="form-group">
                                                <label>Design Title</label>
                                                <input type="text" name="design_title" class="form-control"
                                                    placeholder="e.g. Panda Business Card">
                                            </div>
                                            <div class="form-group">
                                                <label>Tags</label>
                                                <textarea class="form-control my-1" name="design_tags" rows="4"
                                                    placeholder="e.g. Marketing, Business Cards etc.">
                                            </textarea>
                                                <div class="d-flex justify-content-end">
                                                    <span class="yellow-text font-small">Enter tags seperated by
                                                        comma</span>
                                                </div>
                                            </div>

                                        </div>
                                        <!--/design-preview-box-->
                                    </div>
                                    <!--/div to show when any option is selected-->

                                    <!--div to show when no option is selected-->
                                    <div class="no-content-box">
                                        <div class="row justify-content-center">
                                            <div class="col-sm-7 text-center">
                                                <img v-bind:src="linkUploadIcon" alt="user-address">
                                                <p class="home-page-subhead">You file option will appear here after you
                                                    upload the file</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/no-content-box-->
                                </div>
                            </div>
                            
                            <div class="modal-footer justify-content-between">
                                <div class="button-container">
<button type="button" class="z-depth-0 btn custom-btn-outline"
                                        @click.prevent="prev()">Previous</button></div>
                                <div class="button-container"><button type="submit"
                                        class="z-depth-0 btn custom-btn-outline" @click="closeModal()"
                                        name="save_user_design">Save</button></div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>

    </div>
</template>

<script>
    import SelectProductTypePopupComponent from './SelectProductTypePopupComponent.vue';
    export default {
        components: {
            SelectProductTypePopupComponent
        },
        data() {
            return {
                step: 0,
                linkUploadIcon: "website/images/icons/design1.png",
                cloudUploadIcon: "website/images/icons/upload.png",
                noDataFoundIcon: "website/images/icons/design1.png",
                productDesignImg: "website/images/icons/business-card-specification.png",
                pdfIcon: "website/images/icons/pdf.png",
                psdIcon: "website/images/icons/psd.png",
                previewIcon: ['b-card1.png', 'b-card.png'],
                product_type: {
                    selected: 1,
                    value: { name: '-- select --', id: ' ' },
                    input_id: 'product-id',
                    options: [
                        { name: '-- select --', id: ' ', $isDisabled: true },
                        { name: 'AVC family', id: '6' },
                        { name: 'anorher testing', id: '7' },
                        { name: 'flyer new', id: '8' }
                       
                    ],
                },
            }
        },
        methods: {
            prev() {
                this.step--;
            },
            next() {
                this.step++;
            },
            closeModal() {
                this.step = 0;
                $("#upload_design").modal("hide");
            },
            fetchData: function () {
                const my = this;
                
                my.product_type.options =[];
                axios({
                  url: 'http://localhost/bizmis/public/list_family',
                  method: 'get'
                })
                .then(function (response) {
                  console.log(response)
                  
                  for(var prop in response.data.data) {
                  console.log(prop);
                  my.product_type.options.push({ name : response.data.data[prop].name, id:response.data.data[prop].id });
                   }
                })
                .catch(function (error) {
                  console.log(error)
                  my.product_type = error
                })
              },
              toggleSelected: function(value) {
			  $("#fid").val(value.id); 
			  $("#url").val(window.location.pathname);
                  
			},
               
  
        },
        
created: function () { 

       
    this.fetchData();
  },
    }
</script>