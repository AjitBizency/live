<template>
    <div class="wrapper info-page careers-page">
        <!--our values-->
        <div class="common-section-padding pt-0">
            <div class="container">
                <h1 class="page-title">Feedback</h1>
                <div class="form-container">
                    <h3 class="info-page-subhead">Your feedback is highly appreciated and will help us to improve our ability to serve you and other users of our web sites.
                        <br/>Thanks for your time</h3>
                    <form class="form application-form">
                    <!--personal details-->
                    <div class="personal-details">
                        <div class="row">
                           <div class="col-lg-4 col-md-12 col-sm-12">
                               <div class="form-group">
                                   <label>Full Name</label>
                                   <input type="text" class="form-control" name="full_name">
                               </div>
                           </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Email<span class="required-class">*</span></label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Mobile</label>
                                    <input type="tel" class="form-control" name="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Designation</label>
                                    <input type="text" class="form-control" name="designation">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Company Name</label>
                                    <input type="text" class="form-control" name="comapny_name">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4 rating-box">
                                <label>Feedback</label>
                                <star-rating v-bind:increment="0.5" v-bind:max-rating="5" inactive-color="#98aab9" active-color="#f37920" v-bind:star-size="40"></star-rating>
                            </div>
                            <div class="col-sm-12">
                                <label>Message</label>
                               <textarea name="message" class="form-control" row="7"></textarea>
                            </div>
                        </div>
                    </div>
                    <!--/personal details-->
                    <div class="row justify-content-end align-items-center">
                        <div class="button-container">
                            <button type="button" class="btn btn-deep-orange">Send Feedback</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
        <!--/our values-->
    </div>
</template>

<script>
    import StarRating from 'vue-star-rating';
    export default {

        components: {
            StarRating,
        },
        data(){
            return{

            }
        },
    }
</script>