<template>
    <div class="wrapper info-page careers-page">
        <div class="common-section-padding pt-0">
                <div class="container">
                    <h1 class="page-title">Visit Me</h1>
                    <h3 class="info-page-subhead">Would you like meet an expert at your office.<br/> Please provide your contact details and our representative will visit you asap.</h3>
                    <div class="row location-search">
                        <div class="col-sm-8">
                            <form role="form" class="location-search-form">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <div class="input-group-append">
                                        <button class="input-group-text btn-deep-orange" type="button">Get My Location</button>
                                    </div>
                                </div>
                                <span class="custom-note"><strong>Note:</strong> Google address will help us to send your queries to our nearest branch for faster response.</span>
                            </form>
                        </div>
                    </div>
                    <div class="form-container">
                        <form class="form application-form">
                        <div class="map">
                            <img :src="mapIcon" alt="network-map"/>
                        </div>
                        <!--personal details-->
                        <div class="personal-details">
                            <div class="row">
                               <div class="col-lg-6 col-md-12 col-sm-12">
                                   <div class="form-group">
                                       <label>Contact Person</label>
                                       <input type="text" class="form-control" name="contact_person" required>
                                   </div>
                               </div>
                               <div class="col-lg-6 col-md-12 col-sm-12">
                                   <div class="form-group">
                                       <label>Company Name</label>
                                       <input type="text" class="form-control" name="company_name" required>
                                   </div>
                               </div>

                            </div>
                            <div class="row">
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Mobile No.</label>
                                        <input type="tel" class="form-control" name="mobile_num">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Phone No. </label>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="tel" class="form-control" name="std_code" placeholder="eg: +111">
                                                </div>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="form-group">
                                                    <input type="tel" class="form-control" name="phone_num" placeholder="eg: 0012345">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Country</label>
                                        <input type="text" class="form-control" name="country" required>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>State or Province</label>
                                        <input type="text" class="form-control" name="state">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>City</label>
                                        <input type="text" class="form-control" name="city">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Street </label>
                                        <input type="tel" class="form-control" name="street">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Postal Code</label>
                                        <input type="email" class="form-control" name="pin_code" required>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Message</label>
                                        <textarea class="form-control" rows="4" name="message"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/personal details-->

                        <div class="row justify-content-end align-items-center">
                            <div class="button-container">
                                <button type="button" class="btn btn-deep-orange">Submit</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
    </div>
</template>

<script>
    export default {

        data(){
            return{
                mapIcon:'images/map.png',
            }
        },
    }
</script>