<template>
    <div class="wrapper info-page">
        <div class="container">
            <div class="page-title-container"><h1 class="page-title">About Us</h1></div>
            <!--Who are we?-->
            <div class="common-section-padding">
                <h2 class="page-sub-title">Who are we?</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                    in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
                    qui officia deserunt mollit anim id est laborum.
                    Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                    eque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,
                    adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.
                    adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem ipsum quia dolor sit amet, consectetur.
                </p>
            </div>
            <!--/Who are we?-->

            <!--The Network-->
            <div class="common-section-padding">
                <h2 class="page-sub-title">The Network</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                    in reprehenderit.
                </p>
                <div class="map">
                    <img :src="mapIcon" alt="network-map"/>
                </div>
            </div>
            <!--/The Network-->

            <!--Best Printing Technology-->
            <div class="common-section-padding">
                <h2 class="page-sub-title">Best Printing Technology</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                    in reprehenderit. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione .
                </p>

                <div class="row">
                    <div class="technology-slider col-sm-10">
                        <!--Carousel Wrapper-->
                        <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
                            <!--Slides-->
                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item active">
                                    <img class="d-block" :src="aboutSlide1" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block" :src="aboutSlide2" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block" :src="aboutSlide3" alt="Third slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block" :src="aboutSlide4" alt="Fourth slide">
                                </div>
                            </div>
                            <!--/.Slides-->
                            <!--Controls-->
                            <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                            <!--/.Controls-->
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-thumb" data-slide-to="0" class="active">
                                </li>
                                <li data-target="#carousel-thumb" data-slide-to="1">
                                </li>
                                <li data-target="#carousel-thumb" data-slide-to="2">
                                </li>
                                <li data-target="#carousel-thumb" data-slide-to="3">
                                </li>
                            </ol>
                        </div>
                        <!--/.Carousel Wrapper-->
                    </div>


                    <div class="col-sm-2 slider-thumbnail m-hide">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-thumb" data-slide-to="0" class="active" alt="slider-thumbnail-1">
                                <img :src="aboutSlide1">
                            </li>
                            <li data-target="#carousel-thumb" data-slide-to="1" class="active" alt="slider-thumbnail-2">
                                <img :src="aboutSlide2">
                            </li>
                            <li data-target="#carousel-thumb" data-slide-to="2" class="active" alt="slider-thumbnail-3">
                                <img :src="aboutSlide3">
                            </li>
                            <li data-target="#carousel-thumb" data-slide-to="2" class="active" alt="slider-thumbnail-4">
                                <img :src="aboutSlide4">
                            </li>
                        </ol>
                    </div>
                </div>
                </div>

            <!--/Best Printing Technology-->
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                mapIcon:'images/map.png',
                aboutSlide1:'images/slider-images/about-slide-1.jpg',
                aboutSlide2:'images/slider-images/about-slide-2.jpg',
                aboutSlide3:'images/slider-images/about-slide-3.jpg',
                aboutSlide4:'images/slider-images/about-slide-4.jpg',

            }
        },
    }
</script>