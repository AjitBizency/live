<template>
    <div class="wrapper info-page careers-page">
        <div class="common-section-padding pt-0">
            <div class="container">
                <h1 class="page-title">Get a Quote</h1>
               <div class="form-container">
                   <h3 class="info-page-subhead">Most of the prices can be found within the products. <br/>Please use this form if the required product or its prices couldn't find in the product list.</h3>
                   <form class="form application-form">
                       <!--personal details-->
                       <div class="personal-details">
                           <div class="row">
                               <div class="col-lg-4 col-md-12 col-sm-12">
                                   <div class="form-group">
                                       <label>Full Name<span class="required-class">*</span></label>
                                       <input type="text" class="form-control" name="contact_person" required>
                                   </div>
                               </div>
                               <div class="col-lg-4 col-md-6 col-sm-12">
                                   <div class="form-group">
                                       <label>Email<span class="required-class">*</span></label>
                                       <input type="email" class="form-control" name="email" required>
                                   </div>
                               </div>
                               <div class="col-lg-4 col-md-6 col-sm-12">
                                   <div class="form-group">
                                       <label>Mobile No.<span class="required-class">*</span></label>
                                       <input type="tel" class="form-control" name="mobile_num">
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-sm-12">
                                   <div class="form-group">
                                       <label>Message<span class="required-class">*</span></label>
                                       <textarea class="form-control" rows="4" name="message"></textarea>
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-sm-12">
                                   <div class="form-group">
                                       <label>Attach File</label>
                                       <!--custom-upload-box-->
                                       <div class="custom-upload-box">
                                           <label class="upload-button">
                                               <input type="file" multiple @change="uploadImage" name="attached_file"/>
                                               <div class="icon-container">
                                                   <i class="img-icon">
                                                       <img :src="uploadIcon" alt="upload-icon"/>
                                                   </i>
                                               </div>
                                               Drag and drop a file here or click
                                           </label>
                                           <div class="preview-box-wrapper">
                                               <div v-for="(image, key) in images" :key="key" class="preview-box" :id="`img_`+key">
                                                   <div class="preview-img">
                                                       <!--<img class="preview" :ref="'image'" alt="image preview" />-->
                                                       <img class="preview" :src="designIcon" alt="image preview" />
                                                       <div class="remove-btn-box">
                                                           <button type="button" class="remove-btn" @click="removeFile('img_'+key)" >
                                                               <i class="far fa-trash-alt"></i>
                                                           </button>
                                                       </div>
                                                       <div class="custom-note">{{ image.name }}</div>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                       <div class="custom-note">
                                           <h6>Note:</h6>
                                           <ul>
                                               <li>Supported File fromats are <strong>jpg,png,gif,tif,jpeg,tiff,bmp,tga,pdf</strong></li>
                                               <li>Average response time is <strong>One working</strong> day.</li>
                                           </ul>
                                       </div>
                                       <!--/custom-upload-box-->
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--/personal details-->

                       <div class="row justify-content-end align-items-center">
                           <div class="button-container">
                               <button type="button" class="btn btn-deep-orange">Send Request</button>
                           </div>
                       </div>
                   </form>
               </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return{
                images: [],
                uploadIcon:'images/icons/upload.png',
                designIcon:'images/icons/design1.png',
                imgTypeValue:'',
            }
        },
        methods: {
            uploadImage(e) {
                let vm = this;
                var selectedFiles = e.target.files;
                for (let i = 0; i < selectedFiles.length; i++) {
//                    this.imgTypeValue = selectedFiles[i].type;
                    this.imgTypeValue = selectedFiles[i].name.split('.').pop();
//                    alert(this.imgTypeValue);
                    this.images.push(selectedFiles[i]);
                }

                for (let i = 0; i < this.images.length; i++) {
                    let reader = new FileReader();
                    reader.onload = (e) => {
                        this.$refs.image[i].src = reader.result;

//                        console.log(this.$refs.image[i].src);
                    };

                    reader.readAsDataURL(this.images[i]);
                    console.log(this.images[i]);
                }
            },
            removeFile(removeId) {
//                console.log(removeId);
                $('#'+removeId).remove();
            },
        }
    }
</script>
