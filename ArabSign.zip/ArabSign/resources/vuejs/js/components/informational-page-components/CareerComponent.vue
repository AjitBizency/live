<template>
    <div class="wrapper info-page careers-page">
            <!--our values-->
            <div class="common-section-padding pt-0">
                <div class="container">
                    <h1 class="page-title">Careers</h1>
                    <div class="page-title-container">
                        <h2 class="blue-sub-head">Our Values</h2>
                        <p class="home-page-subhead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco</p>
                    </div>
                    <div class="row">
                    <div class="col-sm-3 step-box">
                        <div class="icon-container">
                            <img :src="innovationIcon" alt="our-values-icon-1" />
                        </div>
                        <h3>Innovation</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="col-sm-3 step-box">
                        <div class="icon-container">
                            <img :src="collaborationIcon" alt="our-values-icon-2" />
                        </div>
                        <h3>Collaboration</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="col-sm-3 step-box">
                        <div class="icon-container">
                            <img :src="highQualityIcon" alt="our-values-icon-3" />
                        </div>
                        <h3>High Quality</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="col-sm-3 step-box">
                        <div class="icon-container">
                            <img :src="transparencyIcon" alt="our-values-icon-4" />
                        </div>
                        <h3>Transparent</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididun.</p>
                    </div>
                </div>
                </div>
            </div>
            <!--/our values-->

        <!--our culture-->
        <div class="section-padding">
            <div class="container">
                <div class="page-title-container">
                    <h2 class="blue-sub-head">Our Culture</h2>
                    <p class="home-page-subhead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco</p>
                </div>
            </div>
            <div class="our-culture-slider container-fluid">
                <div id="carousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="d-lg-block">
                                <div class="slide-box">
                                    <div class="col-sm-4">
                                        <img :src="aboutSlide1" alt="First slide">
                                    </div>
                                    <div class="col-sm-4">
                                    <img :src="aboutSlide2" alt="Second slide">
                                    </div>
                                    <div class="col-sm-4">
                                    <img :src="aboutSlide3" alt="Third slide">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="d-lg-block">
                                <div class="slide-box">
                                    <div class="col-sm-4">
                                        <img :src="aboutSlide4" alt="Fourth slide">
                                    </div>
                                    <div class="col-sm-4">
                                        <img :src="aboutSlide3" alt="Fifth slide">
                                    </div>
                                    <div class="col-sm-4">
                                        <img :src="aboutSlide2" alt="Sixth slide">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!--/our culture-->

        <!--join our family-->
        <div class="section-padding">
            <h2 class="blue-sub-head">Join Our Family</h2>
            <div class="job-post-slider container-fluid">
                <div id="carousel1" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carousel1" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel1" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="d-lg-block">
                                <div class="slide-box">
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="d-lg-block">
                                <div class="slide-box">
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="job-post-box">
                                            <h4>Software Engineer</h4>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            <div class="job-location">
                                                <i class="fas fa-map-marker-alt"></i> Riyadh, Saudi Arabia
                                            </div>
                                            <div class="btn-container"><button type="button" class="btn btn-deep-orange">Apply Now!</button></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!--/join our family-->
    </div>
</template>

<script>
    export default {
        data(){
            return{
                aboutSlide1:'images/slider-images/about-slide-1.jpg',
                aboutSlide2:'images/slider-images/about-slide-2.jpg',
                aboutSlide3:'images/slider-images/about-slide-3.jpg',
                aboutSlide4:'images/slider-images/about-slide-4.jpg',
                innovationIcon:'images/icons/innovation.png',
                collaborationIcon:'images/icons/collaboration.png',
                highQualityIcon:'images/icons/high-quality.png',
                transparencyIcon:'images/icons/transparency.png',

            }
        },
    }
</script>