<template>
    <div class="wrapper info-page careers-page">

            <!--our values-->
            <div class="common-section-padding pt-0">
                <div class="container">
                    <h1 class="page-title">Track Order</h1>
                    <div class="row order-track">
                        <div class="col-lg-6 col-md-8 col-sm-12">
                            <div class="form-container">
                                <form class="form application-form">
                                <input type="text"  class="form-control" placeholder="Invoice No"  name="search_invoice_no" autocomplete="off" required>
                                <div class="button-container">
                                    <button class="btn btn-deep-orange" type="submit" name="track_order"> Track</button>
                                </div>

                            </form>
                            </div>
                        </div>
                    </div>
                    <!--/row-->
                    <div class="row">
                        <div class="table-responsive text-nowrap">
                            <!--Table-->
                            <table class="table data-box-table order-history-table">
                                <!--Table head-->
                                <thead>
                                <tr>
                                    <th width="35%"><h4>Products</h4></th>
                                    <th><h4>Order date</h4></th>
                                    <th><h4>Shipped to</h4></th>
                                    <th><h4>Order number</h4></th>
                                </tr>
                                </thead>
                                <!--Table head-->

                                <!--Table body-->
                                <tbody>
                                <tr>
                                    <td colspan="4">
                                        <div class="data-box">
                                            <table width="100%">
                                                <tr>
                                                    <td width="35%" class="right-border">
                                                        <div class="order-history-product">
                                                            <div class="product-img-box">
                                                                <img :src="product2" alt="Business Card" width="100px"/>
                                                            </div>
                                                            <div class="product-box">
                                                                <h4>Business card</h4>
                                                                <ul class="list-unstyled">
                                                                    <li>Double sided</li>
                                                                    <li>Lamination</li>
                                                                    <li>Digital print</li>
                                                                    <li>Ice gold paper</li>
                                                                </ul>
                                                                <div class="custom-note">
                                                                    <a href="#">
                                                                        <strong>Panda - Executive Team.psd</strong>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="order-history-product">
                                                            <div class="product-img-box">
                                                                <img :src="product1" alt="Business Card" width="100px"/>
                                                            </div>
                                                            <div class="product-box">
                                                                <h4>Business card</h4>
                                                                <ul class="list-unstyled">
                                                                    <li>Double sided</li>
                                                                    <li>Lamination</li>
                                                                    <li>Digital print</li>
                                                                    <li>Ice gold paper</li>
                                                                </ul>
                                                                <div class="custom-note">
                                                                    <a href="#">
                                                                        <strong>Panda - Executive Team.psd</strong>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>12/09/2018
                                                    </td>
                                                    <td width="10%">
                                                        <div class="shipping-address">
                                                            <p class="text-uppercase">Client Address</p>
                                                            <span class="address">AIHamra, Riyadh -</span>
                                                            <span class="address">Kingdom of Saudi Arabia 34873</span>
                                                            <span class="address"> 34873</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="custom-note">
                                                            <a href="#">
                                                                <strong>ZP-098765432123456</strong>
                                                            </a>
                                                        </div>
                                                        <span class="order-status under-process">Under preparation</span>
                                                    </td>
                                                </tr>
                                            </table>
                                            <div class="table-footer">
                                                <div class="data-content-box">
                                                    <p><a href="#">View order details</a></p>
                                                    <p><a href="#" class="btn btn-deep-orange">Contact us</a></p>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                                <!--Table body-->
                            </table>
                            <!--Table-->
                        </div>
                    </div>
                </div>
            </div>
            <!--/our values-->

    </div>
</template>

<script>
    import Datepicker from 'vuejs-datepicker';
    export default {

        components: {
            Datepicker
        },
        data(){
            return{
                product1:'images/products/business-card-1.png',
                product2:'images/products/t-shirt-printing.png',
            }
        },
    }
</script>