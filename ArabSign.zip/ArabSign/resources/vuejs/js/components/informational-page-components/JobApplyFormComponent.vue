<template>
    <div class="wrapper info-page careers-page">

            <!--our values-->
            <div class="common-section-padding pt-0">
                <div class="container">
                    <h1 class="page-title">Careers</h1>
                        <h2 class="home-page-subhead">Excited to work with us... please continue</h2>
                    <div class="form-container">
                        <form class="form application-form">
                            <!--personal details-->
                            <div class="personal-details">
                                <h3 class="clearfix">Personal Details</h3>
                                <div class="row">
                                    <div class="col-lg-4 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Full Name<span class="required-class">*</span></label>
                                            <input type="text" class="form-control" name="full_name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Email<span class="required-class">*</span></label>
                                            <input type="email" class="form-control" name="email" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Mobile Number<span class="required-class">*</span></label>
                                            <input type="tel" class="form-control" name="phone" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Nationality<span class="required-class">*</span></label>
                                            <select name="nationality"  class="form-control" required>
                                                <option value="">Select</option>
                                                <option value="China">China</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="United States">United States</option>
                                                <option value="India">India</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Republic of Korea">Republic of Korea</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Taiwan">Taiwan</option>
                                                <option value="Philippines">Philippines</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Vietnam">Vietnam</option>
                                                <option value="Russia">Russia</option>
                                                <option value="France">France</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Netherlands">Netherlands</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Austria">Austria</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Iran">Iran</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Syria">Syria</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Palestine">Palestine</option>
                                                <option value="Republic of Lithuania">Republic of Lithuania</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Finland">Finland</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="Republic of Moldova">Republic of Moldova</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Macedonia">Macedonia</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Jersey">Jersey</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Hashemite Kingdom of Jordan">Hashemite Kingdom of Jordan</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="RÃ©union">RÃ©union</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Libya">Libya</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="British Virgin Islands">British Virgin Islands</option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Kenya">Kenya</option>
                                                <option value="Chile">Chile</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="Guam">Guam</option>
                                                <option value="U.S. Virgin Islands">U.S. Virgin Islands</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Venezuela">Venezuela</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Brunei">Brunei</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Saint Lucia">Saint Lucia</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Macao">Macao</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Montenegro">Montenegro</option>
                                                <option value="North Korea">North Korea</option>
                                                <option value="Vatican City">Vatican City</option>
                                                <option value="Antarctica">Antarctica</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="CuraÃ§ao">CuraÃ§ao</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="Bolivia">Bolivia</option>
                                                <option value="Guernsey">Guernsey</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Tanzania">Tanzania</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Namibia">Namibia</option>
                                                <option value="Ivory Coast">Ivory Coast</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Chad">Chad</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="Republic of the Congo">Republic of the Congo</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Central African Republic">Central African Republic</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="South Sudan">South Sudan</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Kosovo">Kosovo</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="French Southern Territories">French Southern Territories</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Pitcairn Islands">Pitcairn Islands</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Ã…land">Ã…land</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                <option value="Cocos [Keeling] Islands">Cocos [Keeling] Islands</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                                <option value="U.S. Minor Outlying Islands">U.S. Minor Outlying Islands</option>
                                                <option value="Sint Maarten">Sint Maarten</option>
                                                <option value="Guinea-Bissau">Guinea-Bissau</option>
                                                <option value="Saint Martin">Saint Martin</option>
                                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                <option value="Saint-BarthÃ©lemy">Saint-BarthÃ©lemy</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="SÃ£o TomÃ© and PrÃ&shy;ncipe">SÃ£o TomÃ© and PrÃ&shy;ncipe</option>
                                                <option value="Falkland Islands">Falkland Islands</option>
                                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                <option value="East Timor">East Timor</option>
                                                <option value="Bonaire">Bonaire</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Federated States of Micronesia">Federated States of Micronesia</option>
                                                <option value="Palau">Palau</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Myanmar [Burma]">Myanmar [Burma]</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                <option value="Laos">Laos</option>
                                                <option value="Uruguay">Uruguay</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Saint Helena">Saint Helena</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Education</label>
                                            <select required="" name="academic_education" class="form-control">
                                                <option value="">Select</option>
                                                <option value="highschool">High School / Secondary</option>
                                                <option value="diploma">Diploma</option>
                                                <option value="degree">Bachelors Degree</option>
                                                <option value="master">Master Degree</option>
                                                <option value="phd">PhD</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <datepicker :value="state.date" name="dob" :input-class="state.className"></datepicker>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-3 col-sm-12">
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <select name="gender" class="form-control">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-3 col-sm-12">
                                        <div class="form-group">
                                            <label>Marital Status</label>
                                            <select required="" name="marital_status" class="form-control">
                                                <option value="" selected="">Select</option>
                                                <option value="single">Single/Unmarried</option>
                                                <option value="married">Married</option>
                                                <option value="widowed">Widowed</option>
                                                <option value="divorced">Divorced</option>
                                                <option value="separated">Separated</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/personal details-->
                            <hr>
                            <!--Professional details-->
                            <div class="professional-details">
                                <h3 class="clearfix">Professional Details</h3>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Current Job<span class="required-class">*</span></label>
                                            <input type="text" class="form-control" name="current_job" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Position<span class="required-class">*</span></label>
                                            <select name="job_title" class="form-control" required>
                                                <option value="">Select</option>
                                                <option value="4">Production Supervisor</option>
                                                <option value="5">Branch Admin (Saudi only)</option>
                                                <option value="6">Graphic Designer</option>
                                                <option value="7">Receptionist</option>
                                                <option value="8">Printing Technician</option>
                                                <option value="9">Finishing Technician</option>
                                                <option value="10">Delivery Boy</option>
                                                <option value="11">Sales Person</option>
                                                <option value="13">Managing Director</option>
                                                <option value="15">HR Officer</option>
                                                <option value="16">Account Manager</option>
                                                <option value="17">Accountant</option>
                                                <option value="18">Collection Officer</option>
                                                <option value="20">IT Support</option>
                                                <option value="21">Machines Technical Support</option>
                                                <option value="22">Interior Maintenance Support</option>
                                                <option value="23">Purchasing Officer</option>
                                                <option value="24">Coordinator</option>
                                                <option value="27">Photobook Technician</option>
                                                <option value="28">Office Boy</option>
                                                <option value="29">Web Developer</option>
                                                <option value="30">Web Designer</option>
                                                <option value="31">CRM Officer</option>
                                                <option value="32">Government relations officer</option>
                                                <option value="33">Government Relations Manager</option>
                                                <option value="34">Factory Services Officer</option>
                                                <option value="35">Production Manager</option>
                                                <option value="36">Interior Designer</option>
                                                <option value="37">Marketing Specialist</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Total Experience</label>
                                            <select name="total_experience" class="form-control">
                                                <option value="">Years</option>
                                                <option value="0-1">0-1</option>
                                                <option value="1-2">1-2</option>
                                                <option value="2-5">2-5</option>
                                                <option value="5-10">5-10</option>
                                                <option value="10-15">10-15</option>
                                                <option value="16-20">15+</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Expected Salary<span class="required-class">*</span></label>
                                            <select  name="expected_salary" class="form-control" required>
                                                <option value="">Select Salary in SAR</option>
                                                <option value="0-1999">0 - 1,999 </option>
                                                <option value="2000-3999">2,000 - 3,999 </option>
                                                <option value="4000-5999">4,000 - 5,999 </option>
                                                <option value="6000-7999">6,000 - 7,999 </option>
                                                <option value="8000-11999">8,000 - 11,999 </option>
                                                <option value="12000-19999">12,000 - 19,999 </option>
                                                <option value="20000-29999">20,000 - 29,999 </option>
                                                <option value="30000-49999">30,000 - 49,999 </option>
                                                <option value="50000">50,000+ </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Current Location<span class="required-class">*</span></label>
                                            <input type="text" class="form-control" name="current_location" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Visa Status<span class="required-class">*</span></label>
                                            <select  name="visa_status" class="form-control">
                                                <option value="">Select</option>
                                                <option value="Not Applicable">Not Applicable</option>
                                                <option value="Employment (Transferable)">Employment (Transferable)</option>
                                                <option value="Employment(Non Transferable)">Employment(Non Transferable)</option>
                                                <option value="Spouse">Spouse</option>
                                                <option value="Student">Student</option>
                                                <option value="Business">Business</option>
                                                <option value="Visit">Visit</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Attach CV<span class="required-class">*</span></label>
                                            <input type="file" class="form-control" name="resume_file" required>
                                            <span class="custom-note">File supported format: doc, docx, pdf.</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-8 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Cover Letter</label>
                                            <textarea row="3" name="cover_letter" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/Professional details-->
                            <div class="row justify-content-end align-items-center">
                                <div class="button-container">
                                    <button type="button" class="btn btn-deep-orange">Apply</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!--/our values-->

    </div>
</template>

<script>
    import Datepicker from 'vuejs-datepicker';
    export default {

        components: {
            Datepicker
        },
        data(){
            return{
                aboutSlide1:'images/slider-images/about-slide-1.jpg',
                aboutSlide2:'images/slider-images/about-slide-2.jpg',
                aboutSlide3:'images/slider-images/about-slide-3.jpg',
                aboutSlide4:'images/slider-images/about-slide-4.jpg',
                ourValuesIcon1:'images/icons/product-type.png',
                state:{
                    date: new Date(2019, 11,  18),
                    className:'form-control dob_class',
                },
            }
        },
    }
</script>