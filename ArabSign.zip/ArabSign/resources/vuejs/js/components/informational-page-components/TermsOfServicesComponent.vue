<template>
    <div class="wrapper info-page privacy-policy">
        <div class="container">
            <div class="page-title-container"><h1 class="page-title">Terms of Services</h1></div>
            <p><strong>1)</strong>  Orders will be printed according to the product specifications as detailed on the website. For any specific requirements, kindly drop a message to <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>. </p>
            <p><strong>Note:</strong>  Changes in specifications may cause to change in pricing and delivery time </p>
            <p><strong>2)</strong> Once the order is placed, changes are not allowed. If you have any last-minute change, please contact our customer service department. We will try to hold the job if not yet started. </p>
            <p><strong>3)</strong> Changes in specifications, a pick-up location or Shipping Addressmay cause to change in pricing and delivery time.</p>
            <p><strong>4)</strong> The job which contains a government or administration logo can be printed only with written permission from the concerned authorities.</p>
            <p><strong>5)</strong> To process the stamp orders, we require a copy of commercial registration, owner id and a permission letter to Zeejprint. You must provide the original of above documents at receiving.</p>
            <p><strong>6)</strong> To print a book or any other publication, we require a copy of copyrights certificate (Radmak) and a permission letter to Zeejprint. You must provide the original of above documents at receiving. </p>
            <p><strong>7)</strong> Only the orders which are received before 12 pm will be considered for that day. After 12 pm it will be considered for the next day jobs. Refund or request to get partial job is not allowed </p>
            <p><strong>8)</strong> We deliver the jobs by reliable shipping partners and the customer has the right to have the tracing number. </p>
            <p><strong>9)</strong> Turnaround times listed during the ordering procedure are estimated. Uncontrolled factors such as bad weather, malfunction of machinery, malfunction of vehicles, lack of required materials or delay by the shipping company is not subject to the legal liability.</p>
            <p><strong>10)</strong> All goods are sent by Zeejprint, packaged and in good order. It is the responsibility of the client to check any damage that may occur during the handling process of the couriers and note so on their waybill before signing</p>
            <p><strong>11)</strong> It is the customer responsibility to check the printed materials before receiving or leaving the counter. Zeejprint has rights to decide that if the job should be rectified, reprinted or refunded. In case of conflict, a third print specialist can be involved on the account of wrong party.</p>
            <p><strong>12)</strong> Zeejprint shall not be liable for indirect loss or third-party claims occasioned by delay in completing the work or for any loss to the customer arising from delay in transit. Where work is defective for any reason, including negligence Zeejprint’s liability (if any) shall be limited to rectifying such a defect.</p>
            <p><strong>13)</strong> It is the responsibility of a customer to check that all the information, colors and sizes are correct before uploading the file. Customer has no right to ask for refund, rectify or reprint the job.</p>
            <p><strong>14)</strong> We provide an online designing service for additional cost to be paid before starting the design.</p>
            <p><strong>15)</strong> Due to many technical reasons, Zeejprint doesn’t guarantee the colors would match. In case of sensibility, please contact us before placing your order. </p>
            <p><strong>16)</strong> We convert all artworks to the process colors (CMYK) except which are informed by customer in written. Zeejprint is not responsible for undesired results in case we didn’t agree with customer to print special colors.</p>
            <p><strong>Note:</strong> Changes in specifications may cause to change in pricing and delivery time.</p>
            <p><strong>17)</strong> Zeejprint is not responsible for the items left for more than 30 days from the order date. </p>
            <p><strong>18)</strong> Zeejprint provides online payment methods through visa, Paypal or Sadad. Which ensure full confidentiality for our customers.</p>
            <p><strong>19)</strong> Zeejprint has the right to change the prices without early warning however it won’t affect the already placed orders</p>
            <p><strong>20)</strong> The materials used for production like papers, are not included in Zeejprint discount percentage.</p>
            <p><strong>21)</strong> We reply to the inquiries on working days from 9 to 5pm. Inquires are sent beyond that will be answered on next working day.</p>
            <p><strong>22)</strong> In general, Zeejprint is concerned about confidentiality of the information except some cases. However, it is not a subject to direct or indirect claim or sue. </p>
            <p><strong>23)</strong> Please preview your designs carefully and correct any mistakes prior to placing your order. Zeejprint does not proof documents created by its customers prior to processing.</p>
            <p><strong>24)</strong> Please note that we cannot be responsible for: The defect is not notified to Zeejprint at the time of delivery or, if the defect would not be apparent on reasonable inspection, within 24hrs of the date of delivery, and damage to the products arising after delivery to the customer.</p>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                mapIcon:'images/map.png',
                aboutSlide1:'images/slider-images/about-slide-1.jpg',
                aboutSlide2:'images/slider-images/about-slide-2.jpg',
                aboutSlide3:'images/slider-images/about-slide-3.jpg',
                aboutSlide4:'images/slider-images/about-slide-4.jpg',

            }
        },
    }
</script>