<template>
    <div class="wrapper info-page careers-page">
        <div class="common-section-padding pt-0">
            <div class="container">
                <h1 class="page-title">Call Me</h1>
                <div class="form-container">
                    <h3 class="info-page-subhead">
                        Did you get our lines busy or no answers?<br/> Don't worry! Please provide your contact details and we will call you back.
                    </h3>
                    <form class="form application-form">
                    <!--personal details-->
                    <div class="personal-details">
                        <div class="row">
                            <div class="col-lg-4 col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control" name="contact_person" required>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Mobile No.</label>
                                    <input type="tel" class="form-control" name="mobile_num">
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label>Phone No. </label>
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <input type="tel" class="form-control" name="std_code" placeholder="eg: +111">
                                            </div>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <input type="tel" class="form-control" name="phone_num" placeholder="eg: 0012345">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group days-checkbox">
                                    <label class="checkbox-label">Call Me</label>
                                    <div class="clearfix"></div>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" id="sunday" name="sunday">
                                        <label class="custom-control-label" for="sunday">Sunday</label>
                                    </div>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" id="monday" name="monday">
                                        <label class="custom-control-label" for="monday">Monday</label>
                                    </div>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" id="tuesday" name="tuesday">
                                        <label class="custom-control-label" for="tuesday">Tuesday</label>
                                    </div>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" id="wednesday" name="wednesday">
                                        <label class="custom-control-label" for="wednesday">Wednesday</label>
                                    </div>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="checkbox" class="custom-control-input" id="thursday" name="thursday">
                                        <label class="custom-control-label" for="thursday">Thursday</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="checkbox-label">From</label>
                                    <div class="input-group date">
                                        <input type="time" class="form-control no-bottom-margin"  name="start_time" />
                                        <div class="input-group-append">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="checkbox-label">To</label>
                                    <div class="input-group date">
                                        <input type="time" class="form-control no-bottom-margin"  name="end_time" />
                                        <div class="input-group-append">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Message</label>
                                    <textarea class="form-control" rows="4" name="message"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/personal details-->

                    <div class="row justify-content-end align-items-center">
                        <div class="button-container">
                            <button type="button" class="btn btn-deep-orange">Submit</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {

    }
</script>