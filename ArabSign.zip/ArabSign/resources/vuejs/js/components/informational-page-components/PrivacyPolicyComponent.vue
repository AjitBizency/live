<template>
    <div class="wrapper info-page privacy-policy">
        <div class="container">
            <div class="page-title-container"><h1 class="page-title">Privacy Policy</h1></div>
            <p class="mb-3">
                <strong> Zeejprint</strong> ("we" or “our” or “us”) are committed to protecting and respecting your privacy. “You” or “your” means you as the user of our Website.
            </p>
            <p>
                This Privacy Policy (together with our Terms and Conditions, Disclaimer, our Cookies Policy, our Registration Form and any other documents referred to on it) sets out the basis on which any personal data we collect from you, or that you provide to us, will be processed by us. This Privacy Policy also sets out how you can instruct us if you prefer to limit the use of that personal data and the procedures that we have in place to safeguard your privacy.
            </p>
            <h4>
                Please read the following carefully to understand our views and practices regarding your personal data and how we will treat it:
            </h4>
            <h5>1. Information We May Collect From You (and Your Device)</h5>
            <h6>1.1. We may collect and process information about you when:</h6>
            <p><strong>a)</strong>  you contact us, whether through the Website or otherwise (for example, by post, fax, phone, text message) as we may keep a record of that correspondence. For example, if you submit a complaint, report a problem with our service or Website, or otherwise liaise with our customer service, technical support or any other department in our company;</p>
            <p><strong>b)</strong> you use and interact with our web pages, you fill in and submit information on our Website via your PC, a mobile device or otherwise, for example when you register a Customer Account, update your profile or place an Order;</p>
            <p><strong>c)</strong> you use our mobile application softwareor a mobile application software of any member of our Group to use our services <strong>(“App”);</strong> </p>
            <p><strong>d)</strong>  we ask you to complete surveys that we use for research purposes, although you do not have to respond to them; and</p>
            <p><strong>e)</strong> you enter any competition or promotion promoted by us or join any of our events, including photographs, audio and video recordings taken during the competition, promotion or event.</p>
            <h6>1.2. This information may include your:</h6>
            <p><strong>a)</strong> company’s name and field of business;</p>
            <p><strong>b)</strong> name, address, country, telephone number, e-mail and password;</p>
            <p><strong>c)</strong> type of mobile device, unique device identifier (for example, your device's IMEI number, the MAC address of the device's wireless network interface, or the mobile phone number used by the device), mobile network information, mobile operating system, type of mobile browser, time zone settings, and (providing your consent, see also clause 2.4) location data; and</p>
            <p><strong>d)</strong> browser type, operating system, mobile carrier and ISP. We may collect details of your visits to our Website including, but not limited to, traffic data, location data, web log files and other communication data.</p>
            <h6>1.3. Please note that we are working closely with third parties (including, but not limited to, business partners, sub-contractors in technical, payment and delivery services, advertising networks, analytics providers, search information providers, credit reference agencies) and may receive information about you from them.</h6>
            <h6>1.4. We use cookies and other technologies as described below.</h6>

            <h5>2. How We May Use The Information Collected From You</h5>
            <h6>2.1. We may process this information for the purposes of:</h6>
            <p><strong>a)</strong> providing you with the information, products and services requested and personalising our services to you, carrying out our obligations arising from any contracts entered into between you and us (including, but not limited to, the execution of sales orders, delivery of goods, provision of services, billing and monitoring of payment) and enforcing our terms and conditions;</p>
            <p><strong>b)</strong> providing you with information about goods or services offered by us if they are similar to those you have already purchased or enquired about;</p>
            <p><strong>c)</strong> administering our Website for registration and user accounts records and for internal operations, including troubleshooting, data analysis, testing, research, statistical and survey purposes;</p>
            <p><strong>d)</strong> improving our Website to ensure that content is presented in the most effective manner for you and for your computer and allowing you to participate in interactive features of our Website, when you choose to do so;</p>
            <p><strong>e)</strong> organising the competition, promotion or event;</p>
            <p><strong>f)</strong> adding information on competitions, promotions and events (such as names, photographs, audio and video recordings of participants and attendees) to our Website and our pages on social media platforms such as Facebook, and Twitter;</p>
            <p><strong>g)</strong> keeping our Website safe and secure, including to prevent, detect and investigate potentially prohibited or illegal activities;</p>
            <p><strong>h)</strong> measuring or understanding the effectiveness of advertising we serve to you and others, and delivering relevant advertising to you;</p>
            <p><strong>i)</strong> dealing with your inquiries and requests, contacting you where necessary and notifying you about changes to the Website or our services;</p>
            <p><strong>j)</strong> checking the information that you provide against third party database to confirm that is accurate;</p>
            <p><strong>k)</strong> ensuring that content from our Website is presented in the most effective manner for you and for your computer; and</p>
            <p><strong>l)</strong> complying with applicable laws and regulations.</p>
            <h6>2.2. If you are an existing customer we may use your information to contact you by SMS or e-mail (or send you our newsletter) to provide information about goods or services that are similar to those which were the subject of a previous sale or negotiations of a sale to you (independently or jointly with others), unless you opt out to be contacted for such purposes at any time. If you change your mind about being contacted in the future, please let us know at <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>.</h6>
            <h6>2.3. If you are a new customer, and where we permit selected third parties (as notified to you) to use your data, we (or they) will only contact you by SMS or e-mail (or send you our newsletter) if you have consented to this. If you do not want us to use your data in this way, or to pass your details on to selected third parties for marketing purposes, please <strong>do not</strong> tick the relevant box situated on the form on which we collect your data (the Registration Form).</h6>
            <h6>2.4. If you use our App, or an App of any member of our Group, on your mobile phone we may use GPS technology to determine your current location. Some of our location-enabled Services (e.g. search results, personalised services) require your personal data for the feature to work. If you wish to use the particular feature, you will be asked to consent to your data being used for this purpose. If you change your mind about using the particular feature in the future, please let us know at <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>.</h6>
            <h6>2.5. We may ask you to consent to the transfer of your data to Google in order to improve our services. If you change your mind, please let us know at <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>.</h6>
            <h6>2.6. We may also gather your information and statistics for the purposes of monitoring the usage of our Website and our services and provide such aggregate information to third parties. These statistics will not include information that can be used to identify you.
            </h6>
            <h6>2.7. You may ask us to provide you with information about our services or about services offered jointly with or on behalf of other organisations by sending us an e-mail to info@zeejprint.com or writing to us to the following address: Zeejprint, P.O. Box 94513, Riyadh 11614, Kingdom of Saudi Arabia (Attn: Customer Service).</h6>
            <h6>2.8. If you stop using the Website or our services or your permission to use the Website or our services is terminated, we may continue to use and disclose your personal information in accordance with this Privacy Policy (as amended from time to time) and as permitted by law. However, if you wish us to stop e-mailing you with information in connection with the Website or our services, please send your request to the contact details set out above.</h6>

            <h5>3. Contacts Information</h5>
            <h6>3.1. You can change your contact details at any time by updating your profile in your user account and update your contact preferences (if any) by changing your settings related to your notification choices.</h6>
            <h6>3.2. We use information you provide to us, or to third parties offering combined services with us, to customise the services we provide to you.                </h6>

            <h5>4. Information Security</h5>
            <h6>4.1. The Internet is not a secure medium. However, we have put in place a range of security procedures as set out in this Privacy Policy.</h6>
            <h6>4.2. Where relevant, all your credit card details will be passed from your browser to the company that processes the payment on our behalf using SSL encryption.</h6>
            <h6>4.3. Where you have been allocated an account, this area is protected by your user name and password, which you should never divulge to anyone else.</h6>
            <h6>4.4. Please be aware that communications over the Internet, such as e-mails/web-mails are not secure unless they have been encrypted. Your communications may route through a number of countries before being delivered. This is the nature of the World Wide Web/Internet. Although we will do our best to protect your personal data, we cannot guarantee the security of your data transmitted to our Website; any transmission is at your own risk.               </h6>
            <h6>4.5. We cannot accept responsibility for any unauthorised access or loss of personal information that is beyond our control.</h6>
            <h6>4.6. We will use reasonable endeavours to implement appropriate policies, rules, physical and technical measures to protect the personal data that we have under our control (having regard to the type and amount of that data) from unauthorised access, improper use or disclosure, unauthorised modification, unlawful destruction or accidental loss and regularly review these measures.</h6>

            <h5>5. To Whom Will Your Information Be Disclosed?</h5>
            <h6>5.1. Your information may, for the purposes set out in this Privacy Policy, be disclosed for processing to:</h6>
            <p><strong>a)</strong> any member of our group </p>
            <p><strong>b)</strong> our employees, affiliates and their employees, successors in title to our business, prospective sellers or buyers of our business or any of our third party consultants, contractors or other service providers who may access your personal information when providing services (including, but not limited to, IT support, delivery, advertisement and payment services) to us or to you;</p>
            <p><strong>c)</strong> government bodies, law enforcement agencies and other institutions if required by legal or regulatory requests;</p>
            <p><strong>d)</strong> auditors or contractors or other advisers auditing, assisting with or advising on any of our business purposes;</p>
            <p><strong>e)</strong> to any third party where such disclosure is required in order to enforce or apply our Consumer Customer Terms and Conditions / Business Customer Terms and Conditions or other relevant agreements;</p>
            <p><strong>f)</strong> to protect the rights, property, or safety of our company, our customers, or others. This includes exchanging information with other companies and organisations for the purposes of fraud protection and -in cases of justified interests only such as when the customer chose the payment method “purchase on account”- credit risk reduction; and</p>
            <p><strong>g)</strong> where you have consented to this, (i) to selected third parties that may contact you about products and services which may be of interest to you in any jurisdiction where we operate; (ii) to our co-operation partners (including jurors and event service providers), sponsors and the media in context of a competition, promotion or event; and/or (iii) to Google.</p>

            <h5>6. Your Rights In Relation To Your Information</h5>
            <h6>6.1. You can write to us at any time to obtain a copy of your information and to have any inaccuracies corrected. Where appropriate, you may have your personal information erased, rectified, amended or completed. Please write to Zeejprint LTD, P.O. Pox 94513, Riyadh 11614, Kingdom of Saudi Arabia (Attn: Customer Service) or send an e-mail to <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>.</h6>
            <h6>6.2. Please quote your name and address. We should be grateful if you would also provide brief details of the information of which you would like a copy or which you would like to be corrected (this helps us to more readily locate your data).</h6>

            <h5>7. Cookies</h5>
            <p>We use cookies to store and collect information about your use of our Website. Cookies are small text files stored by the browser on your equipment's hard drive. They send information stored on them back to our web server when you access our Website. These cookies enable us to put in place personal settings and load your personal preferences to improve your experience. You can find out more about cookies at http://www.allaboutcookies.org and more about the cookies we use on our Cookies Policy.</p>

            <h5>8. Where We Store And Process You Information </h5>
            <p>The data we collect from you may be transferred to, and stored at, a destination outside the European Economic Area ("EEA"). It may also be processed by staff operating outside the EEA who work for us or for one of our suppliers. Such staff may be engaged in, among other things, the fulfillment of your request and the provision of support services. By submitting your personal data, you agree to this transfer, storing or processing. We will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and the Act. </p>

            <h5>9. Your Consent And Changes To This Privacy Policy </h5>
            <h6>9.1. We reserve the right to amend or modify this Privacy Policy and if we do so we will post the changes on our Website. It is your responsibility to check the Privacy Policy every time you submit information to us.</h6>
            <h6>9.2. In the event that the purposes for processing personal information change, then we will contact you as soon as practicable and seek your consent where such notification relates to a new additional purpose for processing.</h6>

            <h5>10. Use Of Your Personal Information Submitted To Other Website</h5>
            <h6>10.1 Except as otherwise expressly included in this Privacy Policy, this document addresses only the use and disclosure of information we collect from you.</h6>
            <h6>10. 2 If you disclose your information to third parties, such as other websites throughout the Internet (including the ones we link to), different rules may apply to their use or disclosure of the information you disclose to them. We are not responsible for the privacy policies and practices of other website even if you accessed the third party website using links from our Website.</h6>
            <h6>10.3 We recommend that you check the policy of each website you visit and contact the owner or operator of such websites if you have concerns or questions.</h6>

            <h5>11. Further information</h5>
            <p>For further information from us on data protection and privacy or any requests concerning your personal information please write to Zeejprint, P.O. Box 94513, Riyadh 11614, Kingdom of Saudi Arabia (Attn: Customer Service) or e-mail us at <a href="mailto:info@zeejprint.com">info@zeejprint.com</a>.</p>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                mapIcon:'images/map.png',
                aboutSlide1:'images/slider-images/about-slide-1.jpg',
                aboutSlide2:'images/slider-images/about-slide-2.jpg',
                aboutSlide3:'images/slider-images/about-slide-3.jpg',
                aboutSlide4:'images/slider-images/about-slide-4.jpg',

            }
        },
    }
</script>