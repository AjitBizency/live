<template>
    <div class="wrapper info-page careers-page">
        <div class="common-section-padding pt-0">
            <div class="container">
                <h1 class="page-title">Contact Us</h1>
               <div class="form-container">
                   <form class="form application-form">
                       <!--personal details-->
                       <div class="personal-details">
                           <div class="row">
                               <div class="col-lg-4 col-md-12 col-sm-12">
                                   <div class="form-group">
                                       <label>Full Name<span class="required-class">*</span></label>
                                       <input type="text" class="form-control" name="contact_person" required>
                                   </div>
                               </div>
                               <div class="col-lg-4 col-md-6 col-sm-12">
                                   <div class="form-group">
                                       <label>Email<span class="required-class">*</span></label>
                                       <input type="email" class="form-control" name="email" required>
                                   </div>
                               </div>
                               <div class="col-lg-4 col-md-6 col-sm-12">
                                   <div class="form-group">
                                       <label>Mobile No.<span class="required-class">*</span></label>
                                       <input type="tel" class="form-control" name="mobile_num">
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-sm-12">
                                   <div class="form-group">
                                       <label>Message<span class="required-class">*</span></label>
                                       <textarea class="form-control" rows="4" name="message"></textarea>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--/personal details-->

                       <div class="row justify-content-end align-items-center">
                           <div class="button-container">
                               <button type="button" class="btn btn-deep-orange">Send Message</button>
                           </div>
                       </div>
                   </form>
               </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
    }
</script>
