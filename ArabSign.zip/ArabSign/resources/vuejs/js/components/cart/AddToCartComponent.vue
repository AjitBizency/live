<template>
    <div class="cart-total-box">
        <table>
            <tr>
                <th>Total Quantity</th>
                <td>500 Business Cards</td>
            </tr>
            <tr>
                <th>Production Days</th>
                <td>3 days</td>
            </tr>
            <tr>
                <th>Price</th>
                <td>
                    <div><span>Base price:</span> 85 SAR</div>
                    <div><span>Ice Gold Oyester:</span> +5 SAR</div>
                    <div class="total-amount-label"><strong class="ml-0">Total:</strong> 90 SAR</div>
                </td>
            </tr>
        </table>
        <p class="custom-note">Have it shipped to <a href="#">Riyadh - Saudi Arabia?</a></p>
        <button type="button" class="btn btn-deep-orange btn-block">Add to cart</button>
    </div>
</template>

<script>
    export default {
    }
</script>