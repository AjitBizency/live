<template>
    <div class="container cart-container">
            <form method="post" action="">
                <div class="table-responsive text-nowrap">
                    <!--Table-->
                    <table class="table data-box-table">
                        <!--Table head-->
                        <thead>
                        <tr>
                            <th>Order Information</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Notes</th>
                        </tr>
                        </thead>
                        <!--Table head-->
                        <!--Table body-->
                        <tbody>
                        <tr>
                            <td>
                                <div class="product-img-box">
                                    <img :src="productImgUrl" alt="Business Card"/>
                                </div>
                                <div class="product-box">
                                    <h3>Business Card</h3>
                                    <p><strong>Type</strong> Metallic</p>
                                    <p><strong>Material</strong> Ice Gold Oyster</p>
                                    <p><strong>Sides</strong> Two sided</p>
                                </div>
                            </td>
                            <td>200 Cards</td>
                            <td>90 SAR</td>
                            <td>
                                <p><strong>Add notes to the printer</strong></p>
                                <div class="notes-textarea">
                                    <textarea class="form-control" rows="4" name="notes_to_the_printer"></textarea>
                                </div>
                            </td>
                        </tr>
                        <!--<tr>-->
                            <!--<td colspan="4">-->
                                <!--<div class="data-box">-->
                                    <!--<table width="100%" class="table table-bordered">-->
                                        <!--<tr>-->
                                            <!--<td>-->
                                                <!--<div class="product-img-box">-->
                                                    <!--<img :src="productImgUrl" alt="Business Card" width="100px"/>-->
                                                <!--</div>-->
                                                <!--<div class="product-box">-->
                                                    <!--<h3>Business Card</h3>-->
                                                    <!--<h3>Business Card</h3>-->
                                                    <!--<p><strong>Type</strong> Metallic</p>-->
                                                    <!--<p><strong>Material</strong> Ice Gold Oyster</p>-->
                                                    <!--<p><strong>Sides</strong> Two sided</p>-->
                                                <!--</div>-->
                                            <!--</td>-->
                                            <!--<td>200 Cards</td>-->
                                            <!--<td>90 SAR</td>-->
                                            <!--<td>-->
                                                <!--<p><strong>Add notes to the printer</strong></p>-->
                                                <!--<div class="notes-textarea">-->
                                                    <!--<textarea class="form-control" rows="4" name="notes_to_the_printer"></textarea>-->
                                                <!--</div>-->

                                            <!--</td>-->
                                        <!--</tr>-->
                                    <!--</table>-->
                                <!--</div>-->
                            <!--</td>-->
                        <!--</tr>-->
                        </tbody>
                        <!--Table body-->
                    </table>
                    <!--Table-->

                </div>
                <div class="cart-table-footer">
                    <button type="button" class="z-depth-0 btn custom-btn-outline">Edit Order</button>
                    <button type="button" class="z-depth-0 btn custom-btn-outline outline-red">Remove</button>
                </div>
                <div class="cart-total">
                    <div class="payment-methods">
                        <strong>Payment Methods</strong>
                        <img :src="paymentIcon" alt="payment-methods-icon"/>
                    </div>
                    <div class="total-amount-box">
                        <strong class="total-head">Total</strong>
                        <strong class="total-amount">200 SAR</strong>
                    </div>
                </div>
                <!--our services-->
                <div class="service-box-container">
                    <h5>Our Services</h5>
                    <div class="row">
                        <div class="col-sm-3 service-box">
                            <div class="service-img-box">
                                <img :src="positiveIcon" alt="Positive Feedback" />
                                <div class="text-container">
                                    <span>Positive</span>
                                    <span>Feedback</span>
                                </div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                        <div class="col-sm-3 service-box">
                            <div class="service-img-box">
                                <img :src="guaranteeIcon" alt="Satisfaction Guarantee" />
                                <div class="text-container">
                                    <span>Satisfaction</span>
                                    <span>Guarantee</span>
                                </div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                        <div class="col-sm-3 service-box">
                            <div class="service-img-box">
                                <img :src="customerServiceIcon" alt="Instant Customer Service" />
                                <div class="text-container">
                                    <span>Instant</span>
                                    <span>Customer Service</span>
                                </div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                        <div class="col-sm-3 service-box">
                            <div class="service-img-box">
                                <img :src="oneTimeIcon" alt="On Time Delivery" />
                                <div class="text-container">
                                    <span>On Time</span>
                                    <span>Delivery</span>
                                </div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>
                <!--/our services-->

                <!--related products-->
                <div class="related-products">
                    <div class="product-list-box">
                        <h5>Related Products</h5>
                        <div class="row">
                            <div class="product-box" v-for="product in relatedProductList">
                                <a href="#" class="link-box">
                                    <div class="product-category-box">
                                        <img :src="`images/products/`+product.imgName" :alt="product.imgName"/>
                                        <div class="img-caption">
                                            <span class="product-name-span">{{ product.productName }}</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!--/row-->
                    </div>
                </div>
                <!--/related products-->

                <!--cart button container-->
                <div class="add-to-cart-box">
                    <div class="row cart-button-container">
                        <div class="cart-total-box col-sm-4">
                            <button type="button" class="btn btn-deep-orange btn-block">Continue Shopping</button>
                            <button type="button" class="btn btn-deep-orange btn-block"  @click.prevent="next()">Proceed to Checkout</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
</template>

<script>
    export default {
        data(){
            return{
                productImgUrl: 'images/products/business-card-1.png',
                paymentIcon: 'images/icons/payment_methods.png',
                positiveIcon: 'images/icons/postivfdbk_en.png',
                guaranteeIcon: 'images/icons/guarantee_satisf_en.png',
               customerServiceIcon: 'images/icons/livechat_en.png',
                oneTimeIcon: 'images/icons/ontimedel_en.png',
                relatedProductList:[
                    {id:1, productName:'Business cards', imgName:'business-card-1.png'},
                    {id:2, productName:'Letterheads', imgName:'t-shirt-printing.png'},
                    {id:3, productName:'Folders', imgName:'business-card-1.png'},
                    {id:4, productName:'Calendars', imgName:'t-shirt-printing.png'},
                ],
            }
        },
    }
</script>