<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-3">
                <h3>Corporate</h3>
                <ul class="list-unstyled">
                    <li>
                        <a href="#">About us</a>
                    </li>
                    <li>
                        <a href="#">Contact us</a>
                    </li>
                    <li>
                        <a href="#">Careers</a>
                    </li>
                    <li>
                        <a href="#">Terms & Conditions</a>
                    </li>
                    <li>
                        <a href="#">Privacy policy</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>International Presence</h3>
                <ul class="list-unstyled">
                    <li>
                        <a href="#">Saudi Arabia</a>
                    </li>
                    <li>
                        <a href="#">United Arab Emiates</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>Help Lines</h3>
                <ul class="list-unstyled">
                    <li>
                       <p>KSA 10 - 1 AM +0987654321</p>
                    </li>
                    <li>
                        <p>KSA 10 - 1 AM +0987654321</p>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>Follow us on</h3>
                <div class="social-links">
                    <a href="#"><i class="fab fa-twitter"></i> </a>
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>

            </div>
        </div>

        <div class="row copyright justify-content-center">
            <p>All Copyrights are reserved to ZeejPrint 2003-2022</p>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>