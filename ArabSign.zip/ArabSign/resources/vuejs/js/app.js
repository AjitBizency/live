/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');
window.axios = require('axios');

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))
import Vue from 'vue';
import VueRouter from 'vue-router';
import routes from './routes';
import '@fortawesome/fontawesome-free/css/all.css';
import '@fortawesome/fontawesome-free/js/all.js';


// import {Tabs, Tab} from 'vue-tabs-component';
//
// Vue.component('tabs', Tabs);
// Vue.component('tab', Tab);
Vue.use(VueRouter);
Vue.component('example-component', require('./components/ExampleComponent.vue').default);
import VModal from 'vue-js-modal';
Vue.use(VModal);
import ImageUploader from 'vue-image-upload-resize';
Vue.use(ImageUploader);
import Multiselect from 'vue-multiselect'
// register globally
Vue.component('multiselect', Multiselect)

//header components declaration
Vue.component('top-header-component', require('./components/header/TopHeaderComponent.vue').default);
Vue.component('header-component', require('./components/header/HeaderComponent.vue').default);
Vue.component('header-slider-component', require('./components/header/HeaderSliderComponent.vue').default);

//home page components declaration
Vue.component('home-page-component', require('./components/HomePageComponent.vue').default);


//profile page components declaration
Vue.component('profile-component', require('./components/profile/ProfileComponent.vue').default);

//product category components declaration
Vue.component('product-category-component', require('./components/product-category/ProductCategoryComponent.vue').default);

//sign-in and sign-up form components
Vue.component('sign-up', require('./components/login/SignupComponent.vue').default);
Vue.component('sign-in', require('./components/login/SignInComponent.vue').default);

//footer component
Vue.component('footer-component', require('./components/footer/FooterComponent.vue').default);

/*cart component*/
Vue.component('cart-component', require('./components/cart/CartComponent.vue').default);
Vue.component('upload-start-popup-component', require('./components/common/UploadStartPopupComponent.vue').default);
/*Order placement component*/
Vue.component('order-placement-component', require('./components/order-placement/OrderPlacementComponent.vue').default);

/*informational page components*/
//Vue.component('about-us-component', require('./components/informational-page-components/AboutUSComponent.vue').default);
//Vue.component('career-component', require('./components/informational-page-components/CareerComponent.vue').default);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */



const app = new Vue({
    el: '#app',

    router: new VueRouter(routes)
});
