$(document).ready(() => {

    const backToTop = $('#backToTop')
    const amountScrolled = 500

    $(window).scroll(() => {
        $(window).scrollTop() >= amountScrolled
            ? backToTop.fadeIn('fast')
            : backToTop.fadeOut('fast')
    })

    backToTop.click(() => {
        $('body, html').animate({
            scrollTop: 0
        }, 600)
        return false
    })
});

$(function () {
    // Owl Carousel
    var owl = $(".homeBanner .owl-carousel");
    owl.owlCarousel({
        items: 1,
        autoplay: true,
        margin: 0,
        loop: true,
        nav: true,
        dots: false,
    });
});

$(function () {
    // Owl Carousel
    var owl = $(".clients .owl-carousel");
    owl.owlCarousel({
        autoplay: true,
        margin: 30,
        loop: true,
        nav: false,
        dots: false,
        responsive: {
            0: {
                items: 2,
            },
            468: {
                items: 2,
            },
            768: {
                items: 5,
            }
        },
    });
});

$(function () {
    // Owl Carousel
    var owl = $(".designs .owl-carousel");
    owl.owlCarousel({
        autoplay: true,
        margin: 30,
        loop: true,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
            },
            468: {
                items: 1,
            },
            768: {
                items: 4,
            }
        },
    });
});

$(document).ready(function () {
    const burgAnimation = () => {
        var burger = document.querySelector('.svgburg')
        var path1 = document.querySelector('.path1')
        var path2 = document.querySelector('.path2')
        var mline = document.querySelector('.mline')
        burger.addEventListener('click', () => {
            path1.classList.toggle('cross');
            path2.classList.toggle('cross');
            mline.classList.toggle('hide');
        }
        )

    }
    burgAnimation();
});