<section class="clients">
    <div class="container">
        <h1 class="heading text-center">Our trusted clients</h1>
        <p class="content">We believe in not just providing a service of changing the way a space looks to our clients but also forming a relationship based on understanding their needs and then transforming the space to inspire and motivate them to work to their best abilities.</p>

        <div class="client-img">
            <div class="da-center">
                <img src="<?php echo e(secure_asset('includes/image/client/img1.png')); ?>" style=" width: 8vw; "/>
                <img src="<?php echo e(secure_asset('includes/image/client/img2.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img3.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img4.png')); ?>" style=" width: 7vw; "/>
                <img src="<?php echo e(secure_asset('includes/image/client/img7.png')); ?>" />                        
                <img src="<?php echo e(secure_asset('includes/image/client/img16.png')); ?>" />
                
                <img src="<?php echo e(secure_asset('includes/image/client/img5.png')); ?>" style=" width: 3.5vw; "/>
                    
                <img src="<?php echo e(secure_asset('includes/image/client/img9.png')); ?>" />              
                <img src="<?php echo e(secure_asset('includes/image/client/img10.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img11.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img12.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img13.png')); ?>" style=" width: 7vw; "/>
                <img src="<?php echo e(secure_asset('includes/image/client/img14.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img15.png')); ?>" style=" width: 7vw; "/>
                                  
                <img src="<?php echo e(secure_asset('includes/image/client/img18.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img29.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img19.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img21.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img22.png')); ?>" />                     
            
                <img src="<?php echo e(secure_asset('includes/image/client/img24.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img8.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img30.png')); ?>" />
                <img src="<?php echo e(secure_asset('includes/image/client/img31.png')); ?>" style=" width: 4vw; "/>
                                
            </div>  
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/component/clients.blade.php ENDPATH**/ ?>