    


    

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;display=swap" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=ZCOOL XiaoWei' rel='stylesheet'>

    <link href='https://fonts.googleapis.com/css?family=Teko' rel='stylesheet'>


    <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.3.1/swiper-bundle.min.css" rel="stylesheet"> -->
    <!-- <link href="<?php echo e(secure_asset('includes/swiper/7.3.1/swiper-bundle.min.css')); ?>" rel="stylesheet"> -->


    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/css/animate.css" rel="stylesheet" />

    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="<?php echo e(secure_asset('includes/bootstrap/bootstrap-5.1.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">






    

    

    <link href="<?php echo e(secure_asset('includes/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(secure_asset('includes/css/responsive.css')); ?>" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/includes/stylesheet.blade.php ENDPATH**/ ?>