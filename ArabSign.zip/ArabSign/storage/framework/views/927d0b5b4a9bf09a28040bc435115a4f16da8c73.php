﻿
<?php $__env->startSection('content'); ?>
	
	<div class="home-container">
        <section class="section homeBanner">
			<div class="owl-carousel owl-theme">
				<div class="item"><img src="<?php echo e(secure_asset('includes/image/home-banner-1.jpg')); ?>"></div>
				<div class="item"><img src="<?php echo e(secure_asset('includes/image/home-banner-2.jpg')); ?>"></div>
				<div class="item"><img src="<?php echo e(secure_asset('includes/image/home-banner-3.jpg')); ?>"></div>
				<div class="item"><img src="<?php echo e(secure_asset('includes/image/home-banner-4.jpg')); ?>"></div>
			</div>
		</section>
		
		<section class="section aboutUs">
			<div class="container">
				<h1 class="heading underline"><b>About </b>Us</h1>

				<div class="row align-items-center">
					<div class="col-md-8 col-sm-12 order-2 order-sm-1">
						<p>Arab Sign stands out as a premier player in the Sign and Graphics industry, boasting a strong presence in Dubai and an additional branch in Abu Dhabi, UAE. Our journey began back in 1998, and since then, we've consistently delivered top-notch internal and external signage solutions, encompassing a wide range of offerings such as 3D LED Signs, Neon Signs, and LED Display panels for digital signage, catering to clients throughout Dubai and the entire UAE.</p>

						<p>When it comes to Digital Signs and LED Display panels, Arab Sign has forged a strategic partnership with Dahua Technology, a globally renowned manufacturer of LED Display panels. This partnership ensures that we can provide you with the utmost quality and dependable LED Digital Display panel solutions, all conveniently accessible right at your doorstep.</p>
						
						<a href="javascript:void(0);" class="btn btn-primary mt-4">Read More</a>
					</div>

					<div class="col-md-4 col-sm-12 order-1 order-sm-2">
						<div class="img">
							<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>" style=" width: 70%; display: flex; margin: auto; ">
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section designs">
			<div class="container">
				<div class="row mb-5 pb-5">
					<div class="col-md-12 col-sm-12">						
						<div class="title-heading">
							<h3 class="heading">sign board</h3>
							<!-- <a href="javascript:void(0)" class="more">Show More <i class="fal fa-long-arrow-right"></i></a> -->
						</div>
						
						<div class="">
							<div class="owl-carousel owl-theme">
								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12 col-sm-12">						
						<div class="title-heading">
							<h3 class="heading">acrylic</h3>
							<!-- <a href="javascript:void(0)" class="more">Show More <i class="fal fa-long-arrow-right"></i></a> -->
						</div>

						<div class="">
							<div class="owl-carousel owl-theme">
								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>

								<div class="item">
									<a href="javascript:void(0)">
										<div class="card">
											<div class="img">
												<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
											</div>
											<p>Etihad Airways</p>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section clients">
			<div class="container">
				<div class="text-center">
					<h1 class="heading underline">Our <b>Clients</b></h1>				

					<div class="row">
						<div class="col-md-8 col-sm-12 mx-auto">
							<div class="owl-carousel owl-theme">
								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>
								
								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>

								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>

								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>

								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>

								<div class="item">
									<div class="client-logo">
										<img src="<?php echo e(secure_asset('includes/image/no-image.png')); ?>">
									</div>
								</div>
							</div>
						<div>
					</div>
				</div>
			</div>
		</section>

		<section class="section map">
			<iframe class="gmap_iframe" width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=406&amp;height=400&amp;hl=en&amp;q=Riyadh&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
		</section>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ArabSign\resources\views/welcome.blade.php ENDPATH**/ ?>