<section class="whatWeDo">
    <div class="img-bg">
        <img src="<?php echo e(secure_asset('includes/image/img12.jpg')); ?>" />
    </div>

    <div class="container">
        <h1 class="heading">WHAT WE DO</h1>

        <p>We offer a wide range of interior workspace solutions & services for offices.</p>

        <div class="owl-carousel owl-theme">
            <div class="item">
                <div class="card">
                    <div class="number">01</div>
                    <h4>Fit-Out Work</h4>
                    <p>We offer our clients the right solutions to create an inspiring thriving environment where people can increase well-being, productivity, and better outputs.</p>
                </div>
            </div>
            
            <div class="item">
                <div class="card">
                    <div class="number">02</div>
                    <h4>Furniture</h4>
                    <p>A range of partners that deliver outstanding solutions, supported our custom creation of furniture to suit our client’s needs and preferences, using high-quality materials and expert craftsmanship.</p>
                </div>
            </div>

            <div class="item">
                <div class="card">
                    <div class="number">03</div>
                    <h4>Interior Design and Planning</h4>
                    <p>We work with our clients to design and plan their spaces, taking into consideration their needs and preferences while delivering outstanding practical projects that are aesthetically pleasing.</p>
                </div>
            </div>

            <div class="item">
                <div class="card">
                    <div class="number">04</div>
                    <h4>Consultation</h4>
                    <p>Our inputs in the consultation are a data-driven process that equips you ready to create a workspace to support your people and your business to achieve its aims and ambitions. It helps your business guarantee that your people have every resource and every opportunity to bring their core skills for the best work results.</p>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\ArabSign\resources\views/layouts/component/what-we-do.blade.php ENDPATH**/ ?>