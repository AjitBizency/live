
<?php $__env->startSection('content'); ?>
    <div class="todayPartner-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">Your Today Partner</h1>
                    <ul class="breadcrumb"> 
                        <li>Home</li>
                        <li class="active">Your Today Partner</li>
                    </ul>
                </div>

                <div class="socialMedia">
                    <a href="javascript:void(0);" class="facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 155.139 155.139" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M89.584 155.139V84.378h23.742l3.562-27.585H89.584V39.184c0-7.984 2.208-13.425 13.67-13.425l14.595-.006V1.08C115.325.752 106.661 0 96.577 0 75.52 0 61.104 12.853 61.104 36.452v20.341H37.29v27.585h23.814v70.761h28.48z" style="" fill="#010002" data-original="#010002" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="twitter">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M512 97.248c-19.04 8.352-39.328 13.888-60.48 16.576 21.76-12.992 38.368-33.408 46.176-58.016-20.288 12.096-42.688 20.64-66.56 25.408C411.872 60.704 384.416 48 354.464 48c-58.112 0-104.896 47.168-104.896 104.992 0 8.32.704 16.32 2.432 23.936-87.264-4.256-164.48-46.08-216.352-109.792-9.056 15.712-14.368 33.696-14.368 53.056 0 36.352 18.72 68.576 46.624 87.232-16.864-.32-33.408-5.216-47.424-12.928v1.152c0 51.008 36.384 93.376 84.096 103.136-8.544 2.336-17.856 3.456-27.52 3.456-6.72 0-13.504-.384-19.872-1.792 13.6 41.568 52.192 72.128 98.08 73.12-35.712 27.936-81.056 44.768-130.144 44.768-8.608 0-16.864-.384-25.12-1.44C46.496 446.88 101.6 464 161.024 464c193.152 0 298.752-160 298.752-298.688 0-4.64-.16-9.12-.384-13.568 20.832-14.784 38.336-33.248 52.608-54.496z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="linkedin">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 100 100" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M90 90V60.7c0-14.4-3.1-25.4-19.9-25.4-8.1 0-13.5 4.4-15.7 8.6h-.2v-7.3H38.3V90h16.6V63.5c0-7 1.3-13.7 9.9-13.7 8.5 0 8.6 7.9 8.6 14.1v26H90zM11.3 36.6h16.6V90H11.3zM19.6 10c-5.3 0-9.6 4.3-9.6 9.6s4.3 9.7 9.6 9.7 9.6-4.4 9.6-9.7-4.3-9.6-9.6-9.6z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>
                </div>
            </div>     
        </div>  

        <div class="section section2">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12">
                        <h1 class="heading">Your Today Partner</h1>
                        <p>Our long and deep expertise, relevant knowledge, and customer need comprehension enhanced our competitive positioning for why you should choose <?php echo e(env('APP_NAME')); ?> for your project.</p>

                        <div class="card-box">
                            <svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117.62 23.75">
                                <defs>
                                    <style>
                                    .cls-1 {
                                        fill: #3d3d3d;
                                    }

                                    .cls-1, .cls-2 {
                                        stroke-width: 0px;
                                    }

                                    .cls-2 {
                                        fill: #1ebec4;
                                    }
                                    </style>
                                </defs>
                                <g id="BACKGROUND">
                                    <g>
                                    <polygon class="cls-2" points="18.2 11.88 9.1 17.13 0 22.38 0 11.88 0 1.37 9.1 6.62 18.2 11.88"/>
                                    <path class="cls-1" d="m18.46,23.75V0l20.57,11.88-20.57,11.88Zm1.58-21.01v18.27l15.82-9.14L20.04,2.74Z"/>
                                    <polygon class="cls-2" points="57.49 11.88 48.39 17.13 39.29 22.38 39.29 11.88 39.29 1.37 48.39 6.62 57.49 11.88"/>
                                    <path class="cls-1" d="m57.75,23.75V0l20.57,11.88-20.57,11.88Zm1.58-21.01v18.27l15.82-9.14-15.82-9.14Z"/>
                                    <polygon class="cls-2" points="96.79 11.88 87.69 17.13 78.59 22.38 78.59 11.88 78.59 1.37 87.69 6.62 96.79 11.88"/>
                                    <path class="cls-1" d="m97.05,23.75V0l20.57,11.88-20.57,11.88Zm1.58-21.01v18.27l15.82-9.14-15.82-9.14Z"/>
                                    </g>
                                </g>
                            </svg>
                            <h3>Try our solutions </h3>
                            <p>We are keen on adapting to your needs whilst sustaining the creative work.</p>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="card">
                                    <div class="img">
                                        <img src="<?php echo e(secure_asset('includes/image/standards.jpg')); ?>" />
                                    </div>
                                    
                                    <div class="content">
                                        <h4>High-Quality Standards</h4>
                                        <p>We maintain high-quality standards throughout the entire value chain – from raw materials to finished solutions for the workspace. We carefully choose suppliers and manufacturers who meet our standards for quality and environmental impact, ensuring that our clients receive the best possible products and services.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="card">
                                    <div class="img">
                                        <img src="<?php echo e(secure_asset('includes/image/sustainable.jpg')); ?>" />
                                    </div>
                                    
                                    <div class="content">
                                        <h4>Sustainable Solutions</h4>
                                        <p>We are committed to reducing environmental impact and promoting sustainability practices in all areas of our business. We prioritize the use of sustainable materials and design practices that promote energy efficiency and minimize waste. This helps our clients to reduce their carbon footprint and create a more sustainable future.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="card">
                                    <div class="img">
                                        <img src="<?php echo e(secure_asset('includes/image/turnkey.jpg')); ?>" />
                                    </div>
                                    
                                    <div class="content">
                                        <h4>Turnkey Solutions</h4>
                                        <p>We offer turnkey solutions for all interior fit-out works, including design, planning, installation, and ongoing support. Our experienced professionals are committed to delivering the highest level of customer service, ensuring that our client's needs are met, and their expectations exceeded.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="card">
                                    <div class="img">
                                        <img src="<?php echo e(secure_asset('includes/image/dealerships.jpg')); ?>" />
                                    </div>
                                    
                                    <div class="content">
                                        <h4>Exclusive Dealerships</h4>
                                        <p><?php echo e(env('APP_NAME')); ?> is the exclusive dealer of many leading furniture and material brands, offering our clients access to the most innovative and high-quality solutions available.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="card">
                                    <div class="img">
                                        <img src="<?php echo e(secure_asset('includes/image/flexibility.jpg')); ?>" />
                                    </div>
                                    
                                    <div class="content">
                                        <h4>Flexibility</h4>
                                        <p><?php echo e(env('APP_NAME')); ?> understands that every workspace is unique, and we work closely with our clients to understand their specific needs and preferences. We offer flexible solutions that can be customized to meet the unique requirements of each client.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.component.working-process', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.component.our-projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.component.contact-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/yourTodayPartner.blade.php ENDPATH**/ ?>