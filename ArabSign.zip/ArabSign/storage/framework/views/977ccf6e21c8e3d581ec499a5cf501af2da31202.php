<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title><?php echo e(env('APP_NAME')); ?></title>
        <meta charset="UTF-8">
        <meta name="viewport"
            content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <meta name="description" content="">
        <link rel="icon" type="image/x-icon" href="<?php echo e(secure_asset(\Config::get('resources.favicon_path'))); ?>">
        <?php echo $__env->make('layouts.includes.stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body>

    <a href="javascript:void(0)" id="backToTop" class="back-to-top" style="display:none;">
        <svg class="icon__arrow-up" viewBox="0 0 24 24">
            <title>Back to top</title>
            <path d="M18.71,11.71a1,1,0,0,1-1.42,0L13,7.41V19a1,1,0,0,1-2,0V7.41l-4.29,4.3a1,1,0,0,1-1.42-1.42l6-6a1,1,0,0,1,1.42,0l6,6A1,1,0,0,1,18.71,11.71Z"/>
        </svg>
    </a>
    

        <main id="app">
            <section class="header-wrap">
                <?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>

            <section class="content-wrap">
                <?php echo $__env->yieldContent('content'); ?>
            </section>

            <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </main>
        <?php echo $__env->make('layouts.includes.scriptFile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		


	</body>
</html><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/default.blade.php ENDPATH**/ ?>