
<?php $__env->startSection('content'); ?>
    <div class="contact-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">Contact Us</h1>
                    <ul class="breadcrumb">
                        <li>Home</li>
                        <li class="active">Contact Us</li>
                    </ul>
                </div>

                <div class="socialMedia">
                    <a href="javascript:void(0);" class="facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 155.139 155.139" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M89.584 155.139V84.378h23.742l3.562-27.585H89.584V39.184c0-7.984 2.208-13.425 13.67-13.425l14.595-.006V1.08C115.325.752 106.661 0 96.577 0 75.52 0 61.104 12.853 61.104 36.452v20.341H37.29v27.585h23.814v70.761h28.48z" style="" fill="#010002" data-original="#010002" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="twitter">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M512 97.248c-19.04 8.352-39.328 13.888-60.48 16.576 21.76-12.992 38.368-33.408 46.176-58.016-20.288 12.096-42.688 20.64-66.56 25.408C411.872 60.704 384.416 48 354.464 48c-58.112 0-104.896 47.168-104.896 104.992 0 8.32.704 16.32 2.432 23.936-87.264-4.256-164.48-46.08-216.352-109.792-9.056 15.712-14.368 33.696-14.368 53.056 0 36.352 18.72 68.576 46.624 87.232-16.864-.32-33.408-5.216-47.424-12.928v1.152c0 51.008 36.384 93.376 84.096 103.136-8.544 2.336-17.856 3.456-27.52 3.456-6.72 0-13.504-.384-19.872-1.792 13.6 41.568 52.192 72.128 98.08 73.12-35.712 27.936-81.056 44.768-130.144 44.768-8.608 0-16.864-.384-25.12-1.44C46.496 446.88 101.6 464 161.024 464c193.152 0 298.752-160 298.752-298.688 0-4.64-.16-9.12-.384-13.568 20.832-14.784 38.336-33.248 52.608-54.496z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="linkedin">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 100 100" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M90 90V60.7c0-14.4-3.1-25.4-19.9-25.4-8.1 0-13.5 4.4-15.7 8.6h-.2v-7.3H38.3V90h16.6V63.5c0-7 1.3-13.7 9.9-13.7 8.5 0 8.6 7.9 8.6 14.1v26H90zM11.3 36.6h16.6V90H11.3zM19.6 10c-5.3 0-9.6 4.3-9.6 9.6s4.3 9.7 9.6 9.7 9.6-4.4 9.6-9.7-4.3-9.6-9.6-9.6z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>
                </div>
            </div>     
        </div>   
        
        <div class="section1">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
                        <div class="bg-img">
                            <img src="<?php echo e(secure_asset('includes/image/contactUs.jpg')); ?>" />
                        </div>
                    </div>

                    <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
                        <div class="right">
                            <h1 class="heading">Get in touch</h1>

                            <p class="content">Have an inquiry or some feedback for us?</p>
                            <p class="content">Fill out the form below to contact our team.</p>

                            <form>
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">First name *</label>                            
                                            <input type="text" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Last name *</label>                            
                                            <input type="text" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Email address *</label>                            
                                            <input type="email" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label">Message</label>                            
                                            <textarea class="form-control" rows="5"></textarea>
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <button type="submit" class="btn btn-dark">
                                            Get in touch
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.component.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section3 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-xl-11 col-lg-11 col-md-12 col-sm-12 mx-auto">
                        <div class="row">
                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 border-right">
                                <div class="box">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="42.173" height="47.983" viewBox="0 0 42.173 47.983">
                                    <g id="Group_71" data-name="Group 71" transform="translate(-31)">
                                        <path id="Path_12" data-name="Path 12" d="M60.1,31.7c5.106-8.012,4.464-7.013,4.611-7.221a15.348,15.348,0,0,0,2.842-8.925,15.463,15.463,0,1,0-28,9.039l4.53,7.108C39.233,32.448,31,34.665,31,39.549c0,1.78,1.162,4.317,6.7,6.294a44.37,44.37,0,0,0,14.389,2.141c10.124,0,21.086-2.856,21.086-8.435C73.173,34.664,64.95,32.449,60.1,31.7Zm-18.2-8.654q-.023-.036-.048-.071a12.652,12.652,0,1,1,20.582-.142c-.135.179.571-.919-10.342,16.205ZM52.086,45.172c-11.058,0-18.275-3.25-18.275-5.623,0-1.595,3.708-4.217,11.925-5.239l5.164,8.1a1.406,1.406,0,0,0,2.371,0l5.164-8.1c8.217,1.022,11.926,3.644,11.926,5.239C70.361,41.9,63.209,45.172,52.086,45.172Z" fill="#fff"/>
                                        <path id="Path_13" data-name="Path 13" d="M188.029,91a7.029,7.029,0,1,0,7.029,7.029A7.037,7.037,0,0,0,188.029,91Zm0,11.246a4.217,4.217,0,1,1,4.217-4.217A4.222,4.222,0,0,1,188.029,102.246Z" transform="translate(-135.942 -82.472)" fill="#fff"/>
                                    </g>
                                    </svg>

                                    <h4>Address</h4>
                                    <p><?php echo e(\Config::get('resources.compnay_name')); ?></p>
                                    <p><?php echo e(\Config::get('resources.company_address')); ?></p>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 border-right">
                                <div class="box">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="44.576" height="45.854" viewBox="0 0 44.576 45.854">
                                    <g id="Group_73" data-name="Group 73" transform="translate(-2.949)">
                                        <path id="Path_14" data-name="Path 14" d="M122.645,6.007A20.375,20.375,0,0,0,108.142,0a1.625,1.625,0,1,0,0,3.25A17.259,17.259,0,0,1,125.4,20.51a1.625,1.625,0,1,0,3.25,0A20.374,20.374,0,0,0,122.645,6.007Z" transform="translate(-81.127)" fill="#fff"/>
                                        <path id="Path_15" data-name="Path 15" d="M34.833,45.448a1.625,1.625,0,0,0,3.25,0A11.082,11.082,0,0,0,27.015,34.38h0a1.625,1.625,0,1,0,0,3.25A7.828,7.828,0,0,1,34.833,45.448Zm-3.6,8.286a4.906,4.906,0,0,0-4.344,2.6,1.625,1.625,0,1,0,2.683,1.835c.715-1.045,1.039-1.21,1.478-1.189,1.406.165,6.946,4.225,7.5,5.494a1.682,1.682,0,0,1-.015,1.186,5.608,5.608,0,0,1-2.785,3.508,5.214,5.214,0,0,1-4.177-.141,45.929,45.929,0,0,1-15.066-9.809l0,0A45.922,45.922,0,0,1,6.716,42.164a5.217,5.217,0,0,1-.141-4.178A5.606,5.606,0,0,1,10.081,35.2a1.678,1.678,0,0,1,1.183-.017c1.274.557,5.333,6.1,5.5,7.487.023.456-.142.78-1.187,1.493a1.625,1.625,0,1,0,1.833,2.684,4.9,4.9,0,0,0,2.6-4.349c-.141-2.6-5.191-9.472-7.6-10.359a4.913,4.913,0,0,0-3.357-.02,8.746,8.746,0,0,0-5.425,4.51,8.365,8.365,0,0,0,.086,6.758A49.154,49.154,0,0,0,14.213,59.513l.033.033A49.166,49.166,0,0,0,30.352,70.035a9.641,9.641,0,0,0,3.629.757,7.449,7.449,0,0,0,3.128-.671,8.746,8.746,0,0,0,4.511-5.427,4.915,4.915,0,0,0-.017-3.349C40.713,58.925,33.837,53.875,31.237,53.734Z" transform="translate(0 -24.938)" fill="#fff"/>
                                    </g>
                                    </svg>

                                    <h4>Contact</h4>
                                    <p><b>Mobile:</b><?php echo e(\Config::get('resources.contact_number')); ?></p>
                                    <p><b>Fax:</b> <?php echo e(\Config::get('resources.contact_number')); ?></p>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                                <div class="box">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="44" height="42" viewBox="0 0 44 42">
                                    <g id="Group_74" data-name="Group 74" transform="translate(-10 -12)">
                                        <g id="Layer_34" data-name="Layer 34">
                                        <path id="Path_16" data-name="Path 16" d="M54,25a1,1,0,0,0-.052-.314c0-.014-.014-.024-.019-.037a.807.807,0,0,0-.055-.1,1.059,1.059,0,0,0-.132-.2,1.19,1.19,0,0,0-.088-.086.992.992,0,0,0-.2-.134c-.034-.017-.064-.037-.1-.051A1,1,0,0,0,53,24H47V13a1,1,0,0,0-1-1H18a1,1,0,0,0-1,1V24H11a1,1,0,0,0-.354.071c-.036.014-.066.034-.1.051a.974.974,0,0,0-.287.221,1.02,1.02,0,0,0-.132.2.806.806,0,0,0-.055.1c0,.013-.015.023-.019.037A1,1,0,0,0,10,25V53.016a.983.983,0,0,0,.057.324c0,.009.01.017.014.026a.737.737,0,0,0,.048.087.953.953,0,0,0,.141.21,1.1,1.1,0,0,0,.085.082,1.055,1.055,0,0,0,.2.135,1.012,1.012,0,0,0,.1.049A.991.991,0,0,0,11,54H53a.991.991,0,0,0,.352-.071,1.013,1.013,0,0,0,.1-.049,1.055,1.055,0,0,0,.2-.135,1.1,1.1,0,0,0,.085-.082.953.953,0,0,0,.141-.21.737.737,0,0,0,.048-.087c0-.009.011-.017.014-.026a.983.983,0,0,0,.06-.324V25ZM26.986,38.437,12,50.871V27.019ZM52,27.019V50.871L37.012,38.439ZM50.038,26,47,28.314V26ZM19,14H45V29.836L34.812,37.6l-.016.008L32,39.739l-2.775-2.146a1.032,1.032,0,0,0-.167-.089L19,29.837ZM17,26v2.314L13.962,26ZM13.771,52,28.619,39.681,31.394,41.8a.983.983,0,0,0,.184.1q.049.03.1.055L32,42a.949.949,0,0,0,.117-.019,1.033,1.033,0,0,0,.2-.032,1,1,0,0,0,.29-.153l2.773-2.113L50.228,52Z" fill="#fff"/>
                                        <path id="Path_17" data-name="Path 17" d="M24,20H40a1,1,0,0,0,0-2H24a1,1,0,0,0,0,2Zm0,5H40a1,1,0,0,0,0-2H24a1,1,0,0,0,0,2Zm0,5H40a1,1,0,0,0,0-2H24a1,1,0,0,0,0,2Z" fill="#fff"/>
                                        </g>
                                    </g>
                                    </svg>

                                    <h4>Email</h4>
                                    <p><?php echo e(\Config::get('resources.email')); ?></p>
                                    <p><?php echo e(\Config::get('resources.email_2')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/contact.blade.php ENDPATH**/ ?>