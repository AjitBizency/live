
<?php $__env->startSection('content'); ?>
    <div class="whatWeDo-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">What We Do</h1>
                    <ul class="breadcrumb"> 
                        <li>Home</li>
                        <li class="active">What We Do</li>
                    </ul>
                </div>

                <div class="socialMedia">
                    <a href="javascript:void(0);" class="facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 155.139 155.139" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M89.584 155.139V84.378h23.742l3.562-27.585H89.584V39.184c0-7.984 2.208-13.425 13.67-13.425l14.595-.006V1.08C115.325.752 106.661 0 96.577 0 75.52 0 61.104 12.853 61.104 36.452v20.341H37.29v27.585h23.814v70.761h28.48z" style="" fill="#010002" data-original="#010002" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="twitter">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M512 97.248c-19.04 8.352-39.328 13.888-60.48 16.576 21.76-12.992 38.368-33.408 46.176-58.016-20.288 12.096-42.688 20.64-66.56 25.408C411.872 60.704 384.416 48 354.464 48c-58.112 0-104.896 47.168-104.896 104.992 0 8.32.704 16.32 2.432 23.936-87.264-4.256-164.48-46.08-216.352-109.792-9.056 15.712-14.368 33.696-14.368 53.056 0 36.352 18.72 68.576 46.624 87.232-16.864-.32-33.408-5.216-47.424-12.928v1.152c0 51.008 36.384 93.376 84.096 103.136-8.544 2.336-17.856 3.456-27.52 3.456-6.72 0-13.504-.384-19.872-1.792 13.6 41.568 52.192 72.128 98.08 73.12-35.712 27.936-81.056 44.768-130.144 44.768-8.608 0-16.864-.384-25.12-1.44C46.496 446.88 101.6 464 161.024 464c193.152 0 298.752-160 298.752-298.688 0-4.64-.16-9.12-.384-13.568 20.832-14.784 38.336-33.248 52.608-54.496z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="linkedin">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 100 100" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M90 90V60.7c0-14.4-3.1-25.4-19.9-25.4-8.1 0-13.5 4.4-15.7 8.6h-.2v-7.3H38.3V90h16.6V63.5c0-7 1.3-13.7 9.9-13.7 8.5 0 8.6 7.9 8.6 14.1v26H90zM11.3 36.6h16.6V90H11.3zM19.6 10c-5.3 0-9.6 4.3-9.6 9.6s4.3 9.7 9.6 9.7 9.6-4.4 9.6-9.7-4.3-9.6-9.6-9.6z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>
                </div>
            </div>     
        </div>  

        <section class="whatWeDo">
            <div class="img-bg">
                <img src="<?php echo e(secure_asset('includes/image/img12.jpg')); ?>" />
            </div>

            <div class="container">

                <p>We offer a wide range of interior workspace solutions & services for offices and public environments starting from planning & interior design process, furnishing to product selection, joinery, installation, and delivery, along with our high skills in outstanding project management, project reconfiguration, inventory, move management, and product purchasing.</p>

                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="card">
                            <div class="number">01</div>
                            <h4>Fit-Out Work</h4>
                            <p>We offer our clients the right solutions to create an inspiring thriving environment where people can increase well-being, productivity, and better outputs.</p>
                        </div>
                    </div>
                    
                    <div class="item">
                        <div class="card">
                            <div class="number">02</div>
                            <h4>Furniture</h4>
                            <p>A range of partners that deliver outstanding solutions, supported our custom creation of furniture to suit our client’s needs and preferences, using high-quality materials and expert craftsmanship.</p>
                        </div>
                    </div>

                    <div class="item">
                        <div class="card">
                            <div class="number">03</div>
                            <h4>Interior Design and Planning</h4>
                            <p>We work with our clients to design and plan their spaces, taking into consideration their needs and preferences while delivering outstanding practical projects that are aesthetically pleasing.</p>
                        </div>
                    </div>

                    <div class="item">
                        <div class="card">
                            <div class="number">04</div>
                            <h4>Consultation</h4>
                            <p>Our inputs in the consultation are a data-driven process that equips you ready to create a workspace to support your people and your business to achieve its aims and ambitions. It helps your business guarantee that your people have every resource and every opportunity to bring their core skills for the best work results.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="section section3">
            <div class="container">
                <h1 class="heading mb-5">We serve a wide market sector including new offices, retail outlets, restaurants, clinics, hospitality, education, and public environments.</h1>

                <div class="card-box">
                    <h4 class="title pt-5 mb-5">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="40" height="40" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" fill-rule="evenodd" class=""><g><path d="M15 18a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zm11 0a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zm0-11a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zM15 7a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                        Interior Fit-Out Works
                    </h4>

                    <h6 class="mb-4">1. Partitions:</h6>
                    <p class="mb-4">Depending on the scope size, seeking an open work environment while preserving the privacy of your employees at the same time; we are experts in providing appropriate solutions for designing, implementing, and installing partitions with multiple options and high efficiency.</p>

                    <ul class="mb-5">
                        <li>
                            <p>Demountable Partitions</p>
                        </li>

                        <li>                            
                            <p>Movable Partitions</p>
                        </li>

                        <li>
                            <p>POD System & Phone Booth</p>
                        </li>

                        <li>
                            <p>Gypsum Partitions</p>
                        </li>

                        <li>
                            <p>Joinery Works</p>
                        </li>
                    </ul>

                    <h6 class="mb-4">2. Coating Solution:</h6>
                    <p class="mb-4">We are in continuous search for satisfaction, always updating our solutions of the finest product options that serve projects with ideal specifications that suit the design of the place. Our partners brands have implemented the ISO 9000 standard, which will keep us on the path of excellence in service and quality. Our partnering brand is the leading company in the production and application of coatings. It's an entirely new covering technology with no scratches, stains, marks, or burns.</p>

                    <ul class="mb-5">
                        <li>
                            <p>Interiors & Exteriors</p>
                        </li>

                        <li>                            
                            <p>Walls, Floors, Ceiling & Stairs</p>
                        </li>

                        <li>
                            <p>Furniture, Bathroom & Kitchen</p>
                        </li>

                        <li>
                            <p>Swimming Pools-Out</p>
                        </li>
                    </ul>

                    <h6 class="mb-4">3. Flooring & Ceiling Works:</h6>
                    <p class="mb-4">We have significant experience and skills in providing the finest materials and the best options for projects with ideal specifications that suit the design of the place with a group of great wall and floor coating solutions characterized by high quality, diverse colors, and modern designs</p>

                    <ul class="mb-5">
                        <li>
                            <p>Modular Flooring-Carpet</p>
                        </li>

                        <li>                            
                            <p>Ceramic, Marble, Flooring Works</p>
                        </li>

                        <li>
                            <p>Decorative Gypsum Ceiling Works</p>
                        </li>
                    </ul>
                </div> 

                <hr class="my-100">

                <div class="card-box">
                    <h4 class="title mb-5">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="40" height="40" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" fill-rule="evenodd" class=""><g><path d="M15 18a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zm11 0a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zm0-11a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1zM15 7a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                        Furniture Trading
                    </h4>

                    <h6 class="mb-4">1. Desk Solutions:</h6>
                    <ul class="mb-5">
                        <li>
                            <h6>Executive & Conference</h6>
                            <p>An executive solution with stunning appeal that is sure to raise the bar for private offices and conference rooms.</p>
                        </li>

                        <li>
                            <h6>Mid Management & Operative</h6>
                            <p>Modern and concise design style caters to aesthetic taste of modern people.</p>
                        </li>

                        <li>
                            <h6>Workstations</h6>
                            <p>We provide modern single or multi-seater office workstations of a wide range of colors and styles for your employees, a great way to create an exclusive place for them while saving space and fitting your workplace design.</p>
                        </li>

                        <li>
                            <h6>Training Tables</h6>
                            <p>Training space, while existing for sharing, it is to seek and to adapt to various meeting, training, communication, negotiation, and to create a comprehensive system.</p>
                        </li>
                    </ul>

                    <h6 class="mb-4">2. Seating Solutions:</h6>
                    <ul class="mb-5">
                        <li>
                            <h6>Executive & Armchairs</h6>
                            <p>We offer you a wide range of the finest designs, colors, and styles, simple or sophisticated, chairs that fit all our customer's needs and choices.</p>
                        </li>

                        <li>
                            <h6>Collaborative Workspaces</h6>
                            <p>Available in various materials such as mesh, fabric, and leather, could meet the different needs of different spaces.</p>
                        </li>

                        <li>
                            <h6>Training & Café Area</h6>
                            <p>The wide range of finishes and new trendy colors of chairs make the furniture ideal for presentations in offices, café, and interiors.</p>
                        </li>
                    </ul>

                    <h6 class="mb-4">3. Sofa Seating Solutions:</h6>
                    <ul class="mb-5">
                        <li>
                            <h6>Modular Seating System</h6>
                            <p>Whereas ordinary sofas are usually rectangular and fit to accurate size and design, we offer the design freedom to either challenge or adhere to all types of spaces.</p>
                        </li>

                        <li>
                            <h6>Lounge Seating</h6>
                            <p>It’s a carrier of our peaceful mind. During a short break, read, listen to music or just lying on it to relax.</p>
                        </li>

                        <li>
                            <h6>Pouffes & Stools</h6>
                            <p>For giant or small, we have a choice for every workplace. So put your feet up in style and get comfortable.</p>
                        </li>
                    </ul>
                </div> 
            </div>
        </div>

        <?php echo $__env->make('layouts.component.contact-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/whatWeDo.blade.php ENDPATH**/ ?>