    <header>
        <div class="header-top">
            <nav class="navbar navbar-expand-md">
                <div class="container-fluid">
                    <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(secure_asset(\Config::get('resources.logo_path'))); ?>" />
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <svg class="svgburg" width="95" height="93" viewBox="0 0 45 43" fill="none" xmlns="http://www.w3.org/2000/svg">
  
                            <path class="path1" d="M1.5 7L27.5 33C27.5 33 30.5 36 36.5 40.5C42.5 45 48 33.5 41.5 33C35 32.5 2 33 2 33" stroke="black" stroke-width="2"/>
                            
                            <path class="path2" d="M2 33L28 7C28 7 33.5 1 37 1C40.5 1 43 6.20692 40 7C37 7.79308 1 7 1 7" stroke="black" stroke-width="2"/>
                            
                            <path class="mline" d="M1.5 20H28.5" stroke="black" stroke-width="2"/>
                        </svg>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">

                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">
                                    <span>Home</span>
                                </a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <span>About Us</span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(url('/about')); ?>">About Us</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/what-we-do')); ?>">What We Do</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/your-today-partner')); ?>">Your Today Partner</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/our-vision-mission-and-values')); ?>">Our Vision, Mission, Values</a></li>                                    
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/partners')); ?>">
                                    <span>Our Partners</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/clients')); ?>">
                                    <span>Our Clients</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/projects')); ?>">
                                    <span>Our Projects</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="javascript:void(0);">
                                    <span>Testimonial & Accreditation</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/contact')); ?>">
                                    <span>Contact Us</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>