<section class="section8 contactUs">
    <div class="container">

        <h1 class="heading">Get started today</h1>

        <p class="content"><?php echo e(env('APP_NAME')); ?> and partners are the trusted providers in delivering high-quality, sustainable, and innovative solutions for your needs.</p>

        <div class="row">
            <div class="col-xl-8 col-lg-10 col-md-10 col-sm-12 mx-auto">
                <form>
                    <div class="row form-group">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-4">
                            <input type="text" class="form-control" placeholder="Your email address" />
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-4">
                            <input type="tel" class="form-control" placeholder="Your phone number" />
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12">
                            <button type="submit" class="btn btn-dark">
                                Callback
                                
                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/component/contact-us.blade.php ENDPATH**/ ?>