<section class="section4 our-projects">
    <img src="<?php echo e(secure_asset('includes/image/design1.png')); ?>" class="design1"/>
    <img src="<?php echo e(secure_asset('includes/image/design2.png')); ?>" class="design2"/>

    <div class="container">
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 mx-auto">
                <h4 class="subheading line">Our Projects</h4>
                <h1 class="heading">Experts in innovative workplace planning for education, healthcare, and banking.</h1>

                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('project/king-abdullah-financial-district')); ?>">
                                    <div class="number">01</div>
                                    <img src="<?php echo e(secure_asset('includes/image/project/kafd1.png')); ?>" />
                                </a>
                            </div>
                            
                            <div class="content">
                                <a href="<?php echo e(url('project/king-abdullah-financial-district')); ?>"><h4>KING ABDULLAH FINANCIAL DISTRICT (KAFD)</h4></a>
                                <a href="<?php echo e(url('project/king-abdullah-financial-district')); ?>">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="item">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('project/procter-and-gamble-headquarter')); ?>">
                                    <div class="number">02</div>
                                    <img src="<?php echo e(secure_asset('includes/image/project/p&g1.png')); ?>" />
                                </a>
                            </div>
                            
                            <div class="content">
                                <a href="<?php echo e(url('project/procter-and-gamble-headquarter')); ?>"><h4>Procter & Gamble (P&G) Headquarter</h4></a>
                                <a href="<?php echo e(url('project/procter-and-gamble-headquarter')); ?>">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('project/fintech-saudi')); ?>">
                                    <div class="number">03</div>
                                    <img src="<?php echo e(secure_asset('includes/image/project/fintech1.png')); ?>" />
                                </a>
                            </div>
                            
                            <div class="content">
                                <a href="<?php echo e(url('project/fintech-saudi')); ?>"><h4>FINTECH SAUDI</h4></a>
                                <a href="<?php echo e(url('project/fintech-saudi')); ?>">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('project/saudi-industrial-development-fund')); ?>">
                                    <div class="number">04</div>
                                    <img src="<?php echo e(secure_asset('includes/image/project/industrial_development1.png')); ?>" />
                                </a>
                            </div>
                            
                            <div class="content">
                                <a href="<?php echo e(url('project/saudi-industrial-development-fund')); ?>"><h4>SAUDI INDUSTRIAL DEVELOMENT FUND</h4></a>
                                <a href="<?php echo e(url('project/saudi-industrial-development-fund')); ?>">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('')); ?>">
                                    <div class="number">05</div>
                                    <img src="<?php echo e(secure_asset('includes/image/project/p&g3.png')); ?>" />
                                </a>
                            </div>
                            
                            <div class="content">
                                <a href="<?php echo e(url('project/procter-and-gamble-headquarter')); ?>"><h4>Procter & Gamble (P&G) Headquarter</h4></a>
                                <a href="<?php echo e(url('project/procter-and-gamble-headquarter')); ?>">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/component/our-projects.blade.php ENDPATH**/ ?>