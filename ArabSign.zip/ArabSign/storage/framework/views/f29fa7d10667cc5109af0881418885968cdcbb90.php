
<?php $__env->startSection('content'); ?>
    <div class="partners-container">
        <div class="banner-section">
            <div class="container">
                <div>
                    <h1 class="banner-heading">Our Partners</h1>
                    <ul class="breadcrumb">
                        <li>Home</li>
                        <li class="active">Our Partners</li>
                    </ul>
                </div>

                <div class="socialMedia">
                    <a href="javascript:void(0);" class="facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 155.139 155.139" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M89.584 155.139V84.378h23.742l3.562-27.585H89.584V39.184c0-7.984 2.208-13.425 13.67-13.425l14.595-.006V1.08C115.325.752 106.661 0 96.577 0 75.52 0 61.104 12.853 61.104 36.452v20.341H37.29v27.585h23.814v70.761h28.48z" style="" fill="#010002" data-original="#010002" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="twitter">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M512 97.248c-19.04 8.352-39.328 13.888-60.48 16.576 21.76-12.992 38.368-33.408 46.176-58.016-20.288 12.096-42.688 20.64-66.56 25.408C411.872 60.704 384.416 48 354.464 48c-58.112 0-104.896 47.168-104.896 104.992 0 8.32.704 16.32 2.432 23.936-87.264-4.256-164.48-46.08-216.352-109.792-9.056 15.712-14.368 33.696-14.368 53.056 0 36.352 18.72 68.576 46.624 87.232-16.864-.32-33.408-5.216-47.424-12.928v1.152c0 51.008 36.384 93.376 84.096 103.136-8.544 2.336-17.856 3.456-27.52 3.456-6.72 0-13.504-.384-19.872-1.792 13.6 41.568 52.192 72.128 98.08 73.12-35.712 27.936-81.056 44.768-130.144 44.768-8.608 0-16.864-.384-25.12-1.44C46.496 446.88 101.6 464 161.024 464c193.152 0 298.752-160 298.752-298.688 0-4.64-.16-9.12-.384-13.568 20.832-14.784 38.336-33.248 52.608-54.496z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>

                    <a href="javascript:void(0);" class="linkedin">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 100 100" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M90 90V60.7c0-14.4-3.1-25.4-19.9-25.4-8.1 0-13.5 4.4-15.7 8.6h-.2v-7.3H38.3V90h16.6V63.5c0-7 1.3-13.7 9.9-13.7 8.5 0 8.6 7.9 8.6 14.1v26H90zM11.3 36.6h16.6V90H11.3zM19.6 10c-5.3 0-9.6 4.3-9.6 9.6s4.3 9.7 9.6 9.7 9.6-4.4 9.6-9.7-4.3-9.6-9.6-9.6z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                    </a>
                </div>
            </div>     
        </div>   

        <div class="section2">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 mx-auto">
                        <h1 class="heading">Authorized Dealers</h1>
                        <p>In line with our ambitious business strategy, we are working to diversify our resources by building many strategic partnerships with the finest international brands in fit-out solutions and manufacturing materials sector to provide our customers with the best options that meet all their growing needs, according to the highest standards of quality and efficiency, and the best prices.</p>

                        <div class="partner-info">
                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/bulo.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Bulo</h4>
                                        
                                        <p>Bulo is a furniture design and manufacturing company based in Belgium. The company was founded in 1867 and has been creating high-quality furniture ever since. Bulo has a reputation for creating innovative and timeless pieces that are both functional and beautiful.</p>
                                        
                                        <p>Today, Bulo is a leading name in the furniture industry, known for its innovative designs and commitment to quality. The company continues to create beautiful and functional furniture pieces that are enjoyed by customers around the world.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/inclass.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Inclass</h4>
                                        
                                        <p>Inclass is a contemporary furniture company based in Valencia, Spain. The company was founded in 1997 and has since become known for its high-quality and innovative designs.</p>
                                        
                                        <p>Inclass produces furniture for a range of settings, including residential, commercial, and hospitality spaces. Their product line includes chairs, stools, tables, and other pieces of furniture, all designed with a modern aesthetic in mind. The company works with a variety of materials, including metal, wood, plastic, and upholstery, to create pieces that are both functional and visually striking.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/baxter.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Baxter</h4>
                                        
                                        <p>Baxter is a luxury Italian furniture company that was founded in 1990. The company specializes in creating high-end, handcrafted furniture pieces that combine traditional craftsmanship with modern design.</p>
                                        
                                        <p>Baxter's product line includes a range of furniture pieces, including sofas, chairs, tables, lighting, and accessories. The company is known for its use of high-quality materials, including leather, marble, and metal, and for its attention to detail in the manufacturing process.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/desalto.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Desalto</h4>
                                        
                                        <p>Desalto is an Italian furniture company that was founded in 1990. The company is known for its sleek, modern designs that combine functionality with a minimalist aesthetic. Desalto's product line includes furniture for both residential and commercial spaces, including chairs, tables, storage solutions, and accessories</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/pedrali.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Pedrali</h4>
                                        
                                        <p>Pedrali is an Italian furniture company that was founded in 1963. The company specializes in creating contemporary furniture pieces that combine high-quality materials, functionality, and aesthetic appeal.</p>
                                        
                                        <p>Pedrali's product line includes a wide range of furniture pieces, including chairs, tables, sofas, armchairs, and stools, as well as lighting and accessories. The company uses a variety of materials, such as wood, metal, plastic, and upholstery, to create its products, and places a strong emphasis on design and innovation.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/frag.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Frag</h4>
                                        
                                        <p>Frag is a design company that specializes in the creation of high-end furniture and home accessories. The company was founded in 1921 and is based in Forlì, Italy.</p>
                                        
                                        <p>Frag is also committed to sustainability and environmental responsibility. The company has implemented several eco-friendly initiatives, such as using recycled materials and reducing waste.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/topcraft.png')); ?>"/>
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>TOPCRET Micro Cemento</h4>
                                        
                                        <p>Micro Cemento-Topcret is a Spanish brand that specializes in the production and installation of micro cement, a material used for decorative flooring, walls, and surfaces. The company was founded in 2003 and is headquartered in Castelldefels, Spain. Micro Cemento-Topcret's products are known for their versatility, durability, and aesthetic appeal. The brand offers a wide range of colors and finishes, allowing for customization to suit any style or design. And a popular choice for architects, interior designers, and homeowners alike.</p>
                                        
                                        <p>Micro Cemento-Topcret's micro cement is also known for its eco-friendliness, as it is made with natural materials and requires minimal energy to produce. Overall, Micro Cemento-Topcret is a respected brand in the decorative flooring market, known for its quality products, innovative designs, and commitment.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row box">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                                    <div class="img">
                                        <img src="<?php echo e(asset('includes/image/partner/jnf.png')); ?>" />
                                    </div>
                                </div>

                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                                    <div class="right">
                                        <h4>Demountable Partition - Line System</h4>
                                        
                                        <p>Since 1965, our main activity has been the production of hardware for furniture and construction, with a path of continuous evolution and adaptation to the economy and the challenges of the market, devoting special attention to the development of solutions that meet the trends of contemporary architecture.</p>

                                        <p>Several sectors have been created within the JNF, namely research and development of products that play a fundamental role in the company's dynamics. We also have collaborations with organizations that provide us with information and guidance in the development of projects, some of them linked to Portuguese universities in the areas of engineering and design.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php echo $__env->make('layouts.component.contact-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/partners.blade.php ENDPATH**/ ?>