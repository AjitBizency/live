<header>
    <div class="container">
        <nav class="top-bar">
            <div class="centred-logo-info">
                <ul class="title-area">
                    <li class="name">
                        <h1>
                            <a href="javascript:void(0)" rel="home" title="" class="active">
                                <img src="<?php echo e(secure_asset('includes/image/main-logo.png')); ?>" alt="">
                            </a>
                        </h1>
                    </li>

                    <li class="toggle-topbar menu-icon">
                        <a href="javascript:void(0)"><span>Menu</span></a>
                    </li>
                </ul>
                
                <div class="address-bar-left">
                    <div class="address_bar">
                        <div class="address_icon">
                            <img src="<?php echo e(secure_asset('includes/image/phone.png')); ?>" alt="icon">
                        </div>
                        
                        <ul class="bar">
                            <li class="address">Call Us Today</li>
                            <li class="text_add">458-362-1258</li>
                        </ul>

                    </div>

                    <div class="address_bar">
                        <div class="address_icon">
                            <img src="<?php echo e(secure_asset('includes/image/email.png')); ?>" alt="icon">
                        </div>

                        <ul class="bar">
                            <li class="address">Email</li>
                            <li class="text_add">ourmail@gmail.com</li>
                        </ul>
                    </div>
                </div>

                <div class="address-bar-right">
                    <div class="address_bar">
                        <div class="address_icon">
                            <img src="<?php echo e(secure_asset('includes/image/map-marker.png')); ?>" alt="icon">
                        </div>
                        <ul class="bar">
                            <li class="address">Work Time</li>
                            <li class="text_add">09:00-17:00</li>
                        </ul>
                    </div>
                    
                    <div class="address_bar">
                        <div class="address_icon">
                            <img src="<?php echo e(secure_asset('includes/image/clock.png')); ?>" alt="icon">
                        </div>
                        <ul class="bar">
                            <li class="address">Address</li>
                            <li class="text_add">547, San Diego</li>
                        </ul>
                    </div>
                </div>                    
            </div>
          
            <section class="top-bar-section">
                <div class="menu-menu-container">
                    <nav class="navbar navbar-expand-lg">

                        <div class="container-fluid">
                            <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(secure_asset('includes/image/main-logo.png')); ?>" alt="">
                            </a>

                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <svg class="svgburg" width="95" height="93" viewBox="0 0 45 43" fill="none" xmlns="http://www.w3.org/2000/svg">
        
                                    <path class="path1" d="M1.5 7L27.5 33C27.5 33 30.5 36 36.5 40.5C42.5 45 48 33.5 41.5 33C35 32.5 2 33 2 33" stroke="black" stroke-width="2"/>
                                    
                                    <path class="path2" d="M2 33L28 7C28 7 33.5 1 37 1C40.5 1 43 6.20692 40 7C37 7.79308 1 7 1 7" stroke="black" stroke-width="2"/>
                                    
                                    <path class="mline" d="M1.5 20H28.5" stroke="black" stroke-width="2"/>
                                </svg>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                                <ul class="navbar-nav menu">
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(Request::segment(1) === null ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(url('/')); ?>">
                                            <span>Home</span>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(Request::segment(1) === 'about' ? 'active' : ''); ?>" href="<?php echo e(url('/about')); ?>">
                                            <span>About Us</span>
                                        </a>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <span>Services</span>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="javascript:void(0)">Sign Board</a></li>
                                            <li><a class="dropdown-item" href="javascript:void(0)">Acrylic</a></li>                                   
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(Request::segment(1) === 'contact' ? 'active' : ''); ?>" href="<?php echo e(url('/contact')); ?>">
                                            <span>Contact Us</span>
                                        </a>
                                    </li>
                                </ul>

                                <div class="request-quote right">
                                    <a href="<?php echo e(url('/contact')); ?>" class="has-icon">Request a Quote</a>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
                
            </section>
        </nav>


    </div>
      <!--/.top-Menu -->
</header><?php /**PATH C:\xampp\htdocs\ArabSign\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>