<section class="section3 working-process">
    <div class="container">
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 mx-auto">
                <h4 class="subheading-2 bar text-center"> WORKING PROCESS</h4>
                <h1 class="heading text-center mb-5">Maintainance & After Sale Service</h1>

                <div class="row g-5 justify-content-center">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                        <div class="card card-box">
                            <div class="dot"></div>
                            <div class="position-relative">
                                <div class="number">01</div>
                                <h4>Good Planning</h4>
                                <p>Strategic planning to ensure efficient upkeep, enhancing longevity and functionality of your space.</p>

                                <a href="javascript:void(0);" class="arrow">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                        <div class="card card-box card-white">
                            <div class="dot"></div>
                            <div class="position-relative">
                                <div class="number">02</div>
                                <h4>Quick Operations</h4>
                                <p>Swift and responsive operations for timely maintenance, minimizing disruptions and maximizing satisfaction.</p>

                                <a href="javascript:void(0);" class="arrow">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                        <div class="card card-box">
                            <div class="dot"></div>
                            <div class="position-relative">
                                <div class="number">03</div>
                                <h4>Professionals</h4>
                                <p>Dedicated professionals delivering expert care, assuring optimal performance and appearance of your interiors.</p>

                                <a href="javascript:void(0);" class="arrow">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                        <div class="card card-box">
                            <div class="dot"></div>
                            <div class="position-relative">
                                <div class="number">04</div>
                                <h4>Safe Work</h4>
                                <p>Prioritizing safety during all maintenance tasks, safeguarding both your environment and our team's well-being.</p>

                                <a href="javascript:void(0);" class="arrow">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                        <div class="card card-box">
                            <div class="dot"></div>
                            <div class="position-relative">
                                <div class="number">05</div>
                                <h4>Brilliant Ideas</h4>
                                <p>Innovative ideas to continually enhance your space, reflecting creativity and purpose in every aspect of maintenance and support.</p>

                                <a href="javascript:void(0);" class="arrow">
                                    <span>Read More </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="24" height="24" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m303.616 64.034-19.869 22.477L458.514 241H0v30h458.514L283.747 425.489l19.869 22.477L512 263.761v-15.522z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/component/working-process.blade.php ENDPATH**/ ?>