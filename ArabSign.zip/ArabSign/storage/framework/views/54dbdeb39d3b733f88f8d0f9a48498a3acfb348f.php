



<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
<script src="<?php echo e(secure_asset('includes/bootstrap/bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script> -->
<script src="<?php echo e(secure_asset('includes/jquery/js/jquery-3.4.1.min.js')); ?>"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.3.1/swiper-bundle.min.js"></script> -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>


<script src="<?php echo e(secure_asset('includes/js/style.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\bizency-osf\resources\views/layouts/includes/scriptFile.blade.php ENDPATH**/ ?>